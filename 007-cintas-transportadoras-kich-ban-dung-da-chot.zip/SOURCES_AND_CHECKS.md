# Nguồn và điểm cần xác minh

Tập dùng một tuyến băng chuyền công nghiệp tổng hợp để giải thích cơ chế. Mọi cảnh mô tả một công trường, công nhân, thông số điều khiển hoặc tình huống cụ thể trong tuyến tổng hợp đều là tái hiện. Với ảnh tư liệu, xác nhận địa điểm, thiết bị, quyền sử dụng và thời điểm ghi hình trước khi gắn nhãn. Một cảnh trên cao thật có thể mở tập sau khi nguồn được duyệt.

| ID | Tài liệu tham chiếu để đối chiếu | Phạm vi |
| --- | --- | --- |
| S1 | CEMA, *Belt Conveyors for Bulk Materials*, 7th ed. https://cemanet.org/ | Vòng kín, sức chứa, máng nạp, con lăn lòng máng, độ võng, lực kéo, tang chủ động, bộ căng và thiết kế tuyến. Kiểm tra mục liên quan trong bản sách có quyền truy cập. |
| S2 | NIOSH, *Dust Control Handbook for Industrial Minerals Mining and Processing*, second edition, DHHS (NIOSH) Publication No. 2019-124. https://doi.org/10.26616/NIOSHPUB2019124 | Bụi, điểm chuyển tải, vật liệu bám theo nhánh hồi, bao che và làm sạch. |
| S3 | OSHA, 29 CFR 1910.147, *The control of hazardous energy*. https://www.osha.gov/laws-regs/regulations/standardnumber/1910/1910.147 | Nguyên tắc cách ly và kiểm tra năng lượng trước bảo trì, dùng làm tài liệu kỹ thuật tham khảo. Với cảnh quay ở Tây Ban Nha, đối chiếu quy trình tại cơ sở và quy định áp dụng. |
| S4 | NIST Handbook 44, §2.21 *Belt-Conveyor Scale Systems*. https://www.nist.gov/pml/owm/nist-handbook-44-current-edition | Cân băng và đo lưu lượng. Công thức minh họa trong lời đọc là khối lượng trên mét nhân với vận tốc. |
| S5 | BEUMER Group, *Overland Conveyors*. https://www.beumergroup.com/products-systems/conveyors-technology/overland-belt-conveyors/ | Ví dụ công nghệ tuyến dài, đường cong và tái sinh năng lượng khi xuống dốc. Đối chiếu khả năng cụ thể với tài liệu của từng công trình. |
| S6 | Minh họa do biên tập tính | 50 kg/m × 4 m/s = 200 kg/s = 720 t/h. Đồ họa hiện “Ejemplo de cálculo”; đây là giả định được nêu ngay trong lời đọc. |

Đã kiểm tra trang BEUMER và xác nhận hãng mô tả đường cong ngang, truyền động tái sinh ở đoạn xuống dốc và điều kiện phụ thuộc tải. Trang OSHA và NIST truy cập được. S2 dùng DOI của tài liệu NIOSH. Các thông số và quy trình riêng vẫn cần đối chiếu với công trình nếu dùng cảnh thật. Danh mục `100_chu_de_sieu_may_moc_Tay_Ban_Nha_Viet_Nam.txt` do bạn gửi xác nhận mục 007 tại dòng 31–32, gồm tên tiếng Tây Ban Nha và tiếng Việt. Mục này là nguồn chủ đề. Các dữ kiện kỹ thuật được đối chiếu riêng với tài liệu S1–S6.

## Kiểm chứng trước khi khóa lời

- **Chương 2–3:** đối chiếu cấu hình con lăn, cấu tạo băng, độ võng và che chắn với tài liệu nhà sản xuất hoặc hiện trường được chọn. Vẽ rõ nhánh tải và nhánh hồi.
- **Chương 4–5:** xác minh hệ truyền động, xe căng, độ dốc và cấu hình tái sinh trước khi gắn những đặc điểm ấy cho một tuyến thật. Số động cơ và thông số dốc chưa được xác định.
- **Chương 6:** trình tự liên động trong lời đọc là ví dụ. Xác minh trình tự thực tế nếu dùng màn hình hoặc sơ đồ một cơ sở có thật. Không quay thông tin truy cập hoặc dữ liệu vận hành riêng.
- **Chương 7:** ảnh nhiệt chỉ là dấu hiệu để kiểm tra. Xác minh điều kiện quan sát, che chắn và quy trình dừng/cách ly với đội bảo trì nếu quay thực địa.
