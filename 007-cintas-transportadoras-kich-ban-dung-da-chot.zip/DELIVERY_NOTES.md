# Tập 007 — Bản giọng theo danh sách đã chốt

Master es-ES dùng Álvaro ở tempo 0,92×, giữ cao độ gốc, tổng thời lượng 21:00. Andrew, Henri, Duarte và Harri cũng ở 0,92×. Khoảng thời gian còn lại dành cho hình hiện trường và âm thanh trong bước dựng. Các bản khác căn theo 40 đoạn của master và tám mốc chương.

Dùng mã nguồn backend đúng bản Melo 1.3.1 trên Linux. Các model Piper và Supertonic được kiểm tra checksum theo catalog đi kèm bản này. Hồ sơ chính xác nằm trong VOICE_PRESETS.txt và VOICE_PRESETS.json. Bảng người dùng chốt ở lượt sau thay thế mọi hồ sơ giọng trước đó.

Mỗi ngôn ngữ có WAV PCM 24 kHz, mono, 16 bit và SRT cùng tên. Với Edge, phụ đề dựa trên ranh giới từ từ lần thu. Với Piper và Supertonic, từng cụm lời được tổng hợp thành audio riêng, đo thời lượng thực sau chỉnh tốc độ rồi ghép để định mốc phụ đề. Nội dung phụ đề được đối chiếu toàn văn với kịch bản.

AUDIO_QA.json ghi kiểm tra kỹ thuật. Chưa nghe duyệt toàn bộ phát âm của 17 bản. Cần nghe duyệt trước phát hành. Hình phim và âm hiện trường chưa được tạo hoặc dựng thành video cuối.

VIDEO_PROMPTS có 126 clip nguồn mười giây, chia thành 13 TXT. EDIT_TIMELINE.tsv và CHAPTER_TIMING_es-ES.tsv theo master mới ở tempo 0,92×. Đồ họa và chữ được thêm trong bước dựng. Những cảnh tạo là tái hiện công nghiệp. Nguồn kỹ thuật và điểm cần xác minh có trong SOURCES_AND_CHECKS.md.
