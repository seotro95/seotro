# Phân tích video nguồn và phương án kể chuyện cho Derinkuyu

Nguồn do người dùng chỉ định: https://github.com/seotro95/seotro/releases/tag/video

Tệp đã phân tích: `video.c.a.toi.mp4`, 340.611.128 byte; SHA-256 `f1a8659dbccd4db12a79e3c18ea2e1fe08f46f7a03c42bc2250f454f69eff70c`. Video dài 21:02,933, hình 1280×720, 60 fps; lời kể tiếng Nga. Nội dung nói về sinh tồn ở Siberia thời băng hà, kết hợp khảo cổ, cơ thể, thực phẩm, quần áo, nơi ở và công nghệ giữ nhiệt. Đây không phải video tham khảo trực tiếp về Derinkuyu.

Đã xem các khung hình rải từ đầu đến cuối, đọc bản nhận dạng lời kể tự động và đo biến đổi cảnh. Nhận dạng ngôn ngữ Nga có độ tin cậy mô hình 0,994; bản chép tự động vẫn có lỗi tên riêng và từ ngữ, nên chỉ dùng để xác định cấu trúc kể. Ước lượng 2.863 từ, khoảng 136 từ/phút, không coi là bản kiểm đếm chuẩn. Phát hiện cảnh bằng ảnh lấy mẫu 4 fps, thu nhỏ 256×144, ngưỡng scene >0,30: 169 điểm ứng viên; gộp các điểm cách nhau dưới 0,75 giây còn 156. Trung vị khoảng cách các điểm sau gộp xấp xỉ 6,5 giây. Đây là phép đo gần đúng, có thể bỏ sót cắt cảnh tương đồng hoặc tính nhầm chuyển động/chuyển sáng; không phải danh sách tất cả cú cắt chính xác từng khung hình.

## Cách kể tạo sự tò mò

Video mở bằng một vật khảo cổ nhỏ, mở rộng ra địa điểm và khoảng thời gian, rồi dùng nó làm cầu nối đến một câu hỏi lớn về sinh tồn. Khoảng 00:00–01:04 đi từ bằng chứng cụ thể sang bối cảnh Bắc Cực và cách con người vượt qua lạnh giá. Ngay sau đó, lời kể đổi cách nhìn: một yếu tố nổi bật như lửa chưa giải thích hết cả hệ thống.

Các phần giữa đi theo nhu cầu và cơ chế: nguồn năng lượng, cơ thể, lớp quần áo, nơi trú, lưu trữ và giữ lửa. Ví dụ khoảng 04:14 chuyển từ thức ăn giàu năng lượng sang khả năng thích nghi sinh học; khoảng 07:01–07:30 đi từ chi tiết phục trang sang tác dụng bịt các khe hở; khoảng 11:23–11:36 liên hệ hố chứa với bảo quản thực phẩm trong đất lạnh. Một vật hoặc động tác luôn dẫn sang câu hỏi “nó giúp ích bằng cách nào?”.

Khoảng 15:10, một cơ chế vừa giải thích xong được cô lại thành nguyên tắc giữ nhiệt; lời kêu gọi bình luận xuất hiện ngắn trước khi câu chuyện tiếp tục. Khoảng 20:33–21:03, phần kết quay lại công cụ nhỏ và đổi trọng tâm từ hình ảnh lửa dễ nhớ sang kỹ thuật ít gây chú ý hơn. Bộ Derinkuyu dùng cấu trúc mở–giải thích–quay lại chi tiết, nhưng viết lời mới, không dịch hoặc đổi tên trong lời nguồn.

## Cách hình ảnh hỗ trợ lời kể

Hình tham khảo luân phiên bốn dạng: tái dựng hoạt động của người; cận cảnh bàn tay/vật liệu/công cụ; bản đồ, hình cơ thể hoặc mô hình giải thích; không gian rộng để định vị. Cận cảnh tạo cảm giác vật chất, còn mô hình cho thấy điều máy quay không thể nhìn trực tiếp. Các lớp bản đồ, ngày tháng và chữ ngắn xuất hiện như thông tin biên tập. Tái dựng và mô hình không tự trở thành bằng chứng lịch sử.

Nhịp dựng thay đổi theo việc cần hiểu: chi tiết hoặc sự chuyển ý đi nhanh hơn; không gian, cơ chế và suy ngẫm có đoạn giữ lâu hơn. Chuyển động camera nhìn chung có chủ đích: tiến chậm, trượt ngang, nhìn từ trên xuống hoặc chuyển điểm nét. Không cần biến mọi cảnh thành fly-through, xoay liên tục hoặc chuyển cảnh phô trương. Video nguồn có hình người nhỏ tuổi ở một số đoạn; bộ mới loại toàn bộ người dưới 30 tuổi và cả hình trẻ em trong tranh, biểu tượng hay nền cảnh.

## Áp dụng vào chủ đề 72

Mở mới bằng cửa đá tròn và câu hỏi: đóng lối vào để an toàn rồi thì người bên trong tiếp tục thở thế nào? Cảnh tiếp là lỗ thông với bầu trời. Từ đây, từng nhu cầu mở ra tự nhiên: di chuyển → không khí/ánh sáng → nước → lương thực → phối hợp → bằng chứng lịch sử → trở lại cửa đá. Phần kết nhận ra thành phố phụ thuộc vào những kết nối được giữ mở, cũng như vào cánh cửa có thể đóng.

| Thời gian phim mới | Trục lời kể | Hình và nhịp chính |
|---|---|---|
| 00:00–03:00 | Cửa đá; vị trí; đào trong đá; cách hiểu độ sâu | Cửa cận thấp, trục thông gió nhìn lên, thị trấn, bản đồ vùng, bề mặt tuff, mô hình tiết chế |
| 03:00–05:40 | Lối đi và kiểm soát tiếp cận | Góc sau vai người lớn, khoảng thấp, cận rãnh cửa, thao tác đẩy cửa ngắn |
| 05:40–08:40 | Áp suất, thông gió, nhiệt, đèn | Xen trục đứng/cận đèn với mô hình luồng khí có điều kiện; không dựng gió mạnh vĩnh viễn |
| 08:40–11:00 | Giếng; mang nước; vệ sinh và công việc | Nhìn giếng từ vị trí bảo vệ, gánh bình qua lối hẹp, cận động tác rót nước |
| 11:00–13:40 | Dự trữ, ngũ cốc, ép rượu, chuồng nuôi | Cận vật liệu xen phòng chứa, kênh đá và bối cảnh mặt đất |
| 13:40–16:20 | Phân phối công việc; không gian cộng đồng; giới hạn sức chứa | Nhóm nhỏ toàn người lớn, bàn tay trao bình, góc rộng giữ đúng quy mô |
| 16:20–19:00 | Niên đại; tái phát hiện; khảo sát; bảo tồn | Vết công cụ, tài liệu không chữ giả, bản đồ các điểm riêng biệt, thiết bị khảo sát |
| 19:00–20:42 | Cửa đá chỉ là một phần; mối liên hệ với mặt đất | Quay lại cửa và kết bằng nguồn sáng thông lên trên; 2 giây cuối không voice |

## Dựng đúng 20:42 từ clip nguồn 10 giây

Có **125 prompt**, mỗi prompt yêu cầu **một clip nguồn 10 giây**. Dùng trọn 124 clip đầu, dùng 0–2 giây của clip 125: 124×10+2 = 1.242 giây. Tổng thời lượng clip tạo là 20:50; tổng thời lượng sử dụng trong phim là 20:42. Không kéo dài/nhân đôi đoạn để bù thời lượng.

Để gần nhịp video mẫu, 30 cặp clip được chia đôi rồi xen A0–5, B0–5, A5–10, B5–10; 32 cặp còn lại giữ A0–10, B0–10. Mỗi cặp vẫn chiếm đúng 20 giây và cùng cụm ý. Kết quả **185 đoạn dựng** gồm cảnh kết 2 giây, trung bình khoảng 6,71 giây/đoạn. Đây là lựa chọn dựng cho bộ mới, không phải khẳng định video mẫu cắt đều 6,71 giây. Ưu tiên hard cut. Fade kết nằm trong 2 giây cuối, không cộng thời gian chuyển cảnh.

`EDIT_DECISIONS.csv` là nguồn chính xác để đặt hình: có thời gian timeline, ID clip, điểm vào/ra clip và chương. `TIMELINE_VOICE_PROMPT.csv` ghi lời EN từng 10 giây cùng những clip thực sự xuất hiện trong khoảng lời đó. Do có xen clip, một câu 10 giây đôi lúc dùng hình từ hai prompt liền nhau; không được mặc định dòng voice số N luôn chỉ dùng clip N.

Đặt voice EN tại 00:00, không tự thêm intro/outro làm vượt thời lượng. Voice EN đã chia 124 đoạn 10 giây; những bản ngôn ngữ khác căn theo 12 khối 100 giây và khối 40 giây, sau đó 2 giây im lặng. Cùng độ dài chương trình không có nghĩa từng từ ở mọi ngôn ngữ khớp đúng một cú cắt 5 giây. Các bản dịch giữ cùng thứ tự nội dung để dùng chung hình; nếu cần đồng bộ chi tiết bàn tay/vật thể theo từng từ, phải tinh chỉnh tại timeline của ngôn ngữ đó.

## Hướng dẫn hình và chữ

Tuff nên có bề mặt beige/xám/nâu thô, tường dày, phòng vừa, trần thấp hoặc cong tùy không gian. Góc rộng 24–35 mm định vị; 50–70 mm quan sát hoạt động; 85–100 mm xem chi tiết. Đây là tiêu cự tương đương full-frame để định hướng công cụ tạo hình, không phải dữ liệu thiết bị khảo cổ. Đèn dầu chỉ chiếu một vùng nhỏ trong cảnh lịch sử; cảnh hiện tại có thể có đèn tuyến tham quan. Hạn chế màu xanh-cam quá mạnh, sương sân khấu và kiến trúc kỳ ảo.

Bản đồ, sơ đồ luồng khí, nhiệt và hệ thống là minh họa nguyên lý. Biên tập gắn nhãn ngắn “Illustrative reconstruction” ở đầu các cụm tái dựng và “Conceptual model — not a surveyed plan” ở đầu các cụm mô hình; không dùng chúng như ảnh tư liệu. Thêm nhãn “Regional context” cho ngoại cảnh Cappadocia không nằm ngay lối vào Derinkuyu. Các hướng luồng khí biểu diễn một điều kiện, không một chiều hoạt động cố định của toàn di tích.

`TEXT_OVERLAYS_EN.csv` chỉ đề xuất chữ ngắn do người dựng thêm sau; mô hình video không tạo chữ. Có thể dùng lower-third nhỏ, chừa vùng thấy vật và không che lối đi. Nếu thêm bản đồ, đặt nhãn Derinkuyu/Kaymakli bằng công cụ dựng, không vẽ một đường hầm liên đô thị khi chưa có tài liệu đo đạc. Không đưa logo/kênh của nguồn vào bộ mới.

Mỗi prompt đều yêu cầu không âm thanh, không lời nói và không hình trẻ em. Điều đó ràng buộc clip tạo, không loại bỏ track voice riêng của phim hoàn chỉnh. Sau khi tạo phải xem lại toàn bộ clip, kể cả hình trên tường/nền cảnh; prompt không bảo đảm mô hình tuyệt đối tuân thủ. Bộ này cung cấp lời, prompt và âm thanh, không bao gồm 125 video đã sinh.
