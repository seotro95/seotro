# Bờ biển Skeleton: sương mù, cát và xác tàu

Chủ đề lấy từ mục 26 của tệp `100-chu-de.txt` do người dùng cung cấp. Nội dung tệp được dùng làm dữ liệu tham chiếu chủ đề. Các ghi chú bên trong tệp không được coi là chỉ thị thay thế yêu cầu trong cuộc trò chuyện.

## Ý tưởng kể chuyện

Mở bằng nghịch lý một con tàu nằm giữa cát, đặt ba câu hỏi: vì sao bên đại dương mà đất vẫn khô; vì sao sương gây nguy hiểm cho hàng hải nhưng giúp sinh vật; và vì sao nơi gắn với xác tàu vẫn có sự sống. Sau đó giải thích bằng các quá trình quan sát được, rồi quay lại hình ảnh mở đầu với cách hiểu đầy đủ hơn. Không dùng lời nguyền, số liệu xác tàu giật gân hoặc hình người bị nạn để tạo kịch tính.

Kịch bản tiếng Anh gốc gồm 3.164 từ, 131 ô lời đọc và một ô kết hình không lời. Nhịp trung bình khoảng 145 từ/phút trên toàn phim. Lời Việt được soạn song song để duyệt ý. H’Mông được viết lại theo ngữ cảnh, dùng câu tương đối ngắn, giữ các tên riêng. Các bản còn lại dựa trên dịch máy, có sửa năm, thuật ngữ và một số đoạn trọng yếu; chưa được người bản ngữ độc lập nghe duyệt toàn bộ. Đặc biệt không coi việc engine chấp nhận chữ H’Mông là bằng chứng xác nhận phương ngữ Hmoob Dawb.

## Cấu trúc và thời lượng

| Phần | Cảnh | Thời gian | Mục đích |
|---|---|---|---|
| Câu hỏi mở và bản đồ | 1–12 | 00:00–02:00 | Tạo tò mò, xác định Namibia và phân biệt tên vùng với công viên |
| Biển Benguela và sương mù | 13–30 | 02:00–05:00 | Nối nước trồi, sinh thái biển, khí quyển và nguồn ẩm |
| Cát đang di chuyển | 31–46 | 05:00–07:40 | Giải thích vận chuyển trầm tích và cồn cát |
| Hai câu chuyện xác tàu | 47–64 | 07:40–10:40 | Eduard Bohlen và Dunedin Star; phân biệt vị trí và sự kiện |
| Những dòng sông khô | 65–82 | 10:40–13:40 | Nước dưới cát, Hoanib, voi và việc dùng chung nước |
| Đổi tỷ lệ quan sát | 83–100 | 13:40–16:40 | Bọ thu sương, địa y, hải cẩu và sự liên kết sinh cảnh |
| Con người và quan sát có trách nhiệm | 101–112 | 16:40–18:40 | Dấu tích cư trú, công việc bảo tồn và cách chọn hình |
| Trở lại câu hỏi mở | 113–132 | 18:40–21:52 | Gom các mối liên hệ, kết bằng thái độ trân trọng |

## Cách ghép 132 clip

Tạo toàn bộ clip ở 10 giây, 16:9, dự kiến 24 fps. Cảnh 1–131 dùng đủ 10 giây; cảnh 132 chỉ dùng 2 giây đầu. Tổng: 131 × 10 + 2 = 1.312 giây = 21:52. Phần dư 8 giây của clip 132 không đưa vào bản dựng. Mỗi cảnh chỉ cần một clip, số cảnh trùng số prompt. Có 14 TXT: 13 tệp đủ 10 prompt và tệp cuối 2 prompt. Không thêm 8 prompt không cần thiết vào phim chỉ để làm tròn số tệp.

Cắt nối trực tiếp ở mốc 10 giây giữ nguyên thời lượng. Nếu dùng dissolve, đặt phần chồng hình trong ô thời gian, không trừ tổng độ dài. Khóa đường chân trời và vị trí trái/phải của biển khi nối cảnh dọc bờ; không đảo ảnh các cảnh bản đồ hoặc địa điểm xác định.

Các cảnh lịch sử 30, 49, 54, 56–58 là hình tái dựng minh họa, không phải tư liệu quay đúng sự kiện. Các cảnh giải thích 14, 19, 32, 44, 59, 68 là mô hình minh họa. Khi dựng, thêm nhãn ngắn “Illustrative reconstruction” hoặc “Scientific illustration” ở lớp chữ riêng nếu cần. Bản đồ cần dựng từ hình tham chiếu chuẩn và thêm nhãn khi hậu kỳ; prompt không yêu cầu mô hình tự viết tên địa danh. Không coi hình AI là bằng chứng địa chất hoặc khảo cổ mới.

Tất cả prompt yêu cầu không âm thanh, không lời nói, không nhạc, không tiếng động và không hình trẻ em. Các cảnh có người chỉ thể hiện người trưởng thành. Không dùng thi thể, thương tích, bộ xương người hoặc cảnh săn giết. Những điều này cũng cần kiểm tra trên clip thực tế sau khi tạo, vì prompt không tự bảo đảm đầu ra của công cụ video.

Tiếng Anh dùng từng ô 10 giây. Các bản đọc khác căn theo 13 khối 100 giây và một ô lời cuối 10 giây, cộng 2 giây kết không lời. Cùng tổng thời lượng không đồng nghĩa từng câu bản dịch trùng từng cảnh 10 giây. Tệp SRT đầu vào của bản dịch là mốc khối tạo voice, không phải phụ đề ngắn đã chia để hiển thị.

## Những điểm cần giữ đúng

- Công viên Skeleton Coast kéo từ Ugab về phía Kunene; tên Skeleton Coast trong cách dùng rộng không luôn có đúng ranh giới đó.
- Eduard Bohlen mắc cạn năm 1909 gần Conception Bay, nằm phía nam công viên. Không đặt nó ở Hoanib hoặc nói nó nằm trong công viên.
- Cát tích tụ quanh xác tàu không chứng minh toàn bộ đại dương đã rút lui.
- Dunedin Star mắc cạn năm 1942. Những người trên tàu được cứu; hai người của lực lượng cứu hộ thiệt mạng trong vụ tàu kéo gặp nạn. Không biến thành câu chuyện mọi người trên tàu đều chết.
- Sương liên quan nước biển lạnh, sự di chuyển của không khí và cấu trúc khí quyển. Tránh giải thích đơn giản bằng “sa mạc nóng gặp biển lạnh” rồi coi là đủ.
- Không phải mọi loài bọ đều thu sương bằng cùng một cơ chế. Cảnh hành vi ngẩng phần sau thân dùng kiểu Onymacris unguicularis.
- Voi thích nghi sa mạc không phải một loài voi riêng. Sông tạm thời có thể có nguồn nước dưới lòng sông dù mặt sông khô.
- Không gọi cảnh quan này là nơi chưa từng có người. Dấu tích nhà đá và vỏ nhuyễn thể cho thấy việc sử dụng bờ biển trong quá khứ.

## Nguồn đối chiếu

Các liên kết dưới đây hỗ trợ dữ kiện; lời dẫn, phép nối cảnh và các hình ảnh ngôn ngữ là phần biên soạn mới. Không sao chép lời văn nguồn.

| Nội dung | Nguồn |
|---|---|
| Địa lý công viên, quản lý, sinh cảnh và cộng đồng | [MEFT Namibia — Skeleton Coast National Park Management Plan, 2013](https://meft.gov.na/files/files/Skeleton%20Coast%20Management%20Plan.pdf) |
| Mô tả chính thức công viên, địa y và động vật | [MEFT — Skeleton Coast Park](https://www.meft.gov.na/national-parks/skeleton-coast-park/227/) |
| Dấu tích con người, sông, bụi cây và cảnh quan | [Namibia Ministry of Environment and Tourism — Skeleton Coast Park fact sheet](https://namibiahc.org.uk/perch/resources/pdf/skeleton-coast-park-2nd-fact-sheet-skeleton-coast.pdf) |
| Nước trồi và năng suất biển | [Benguela Current Convention — The BCLME](https://www.benguelacc.org/the-bclme/) |
| Hải lưu lạnh, khô hạn và sương | [NASA — Namibia](https://science.nasa.gov/earth/earth-observatory/namibia-3464/) |
| Cấu trúc mây thấp và sương | [Atmospheric Chemistry and Physics — Cloud base height determines fog occurrence patterns in the Namib Desert, 2026](https://doi.org/10.5194/acp-26-681-2026) |
| Mây tầng và độ cao địa hình | [Atmospheric Chemistry and Physics — Synoptic and regional-scale meteorological controls of stratus altitude, 2026](https://acp.copernicus.org/articles/26/14367/2026/) |
| Nguồn cát và sông Orange | [NASA — Namib Sand Sea](https://science.nasa.gov/earth/earth-observatory/namib-sand-sea-149130/) |
| Nguồn gốc trầm tích tới Skeleton Coast | [Marine Geology — Ultra-long distance littoral transport of Orange sand and provenance of the Skeleton Coast Erg, 2014](https://www.sciencedirect.com/science/article/pii/S0025322714002138) |
| Cơ chế gió vận chuyển cát | [USGS — Eolian Processes](https://pubs.usgs.gov/gip/deserts/eolian/) |
| Cây giữ cát và sinh cảnh cồn cát | [US National Park Service — Aeolian Landforms](https://www.nps.gov/subjects/geology/aeolian-landforms.htm) |
| Eduard Bohlen, vị trí, năm và vụ cứu Dunedin Star | [The Namibian — Shipwrecks of the Skeleton Coast](https://www.namibian.com.na/shipwrecks-of-the-skeleton-coast/) |
| Đối chiếu cứu hộ và thương vong | [British Modern Military History Society — Escape from a Deadly Shore](https://bmmhs.org/escape-from-a-deadly-shore/) |
| Di chuyển của voi và nước | [NASA — Tracking Elephants Across Namibia](https://science.nasa.gov/earth/earth-observatory/tracking-elephants-across-namibia/) |
| Voi và hành lang sông, đào nước | [Desert Elephant Conservation — About Desert Elephants](https://desertelephantconservation.org/about-desert-elephants) |
| Cùng chung sống và bảo vệ nguồn nước | [EHRA Namibia — Desert Elephants](https://www.ehranamibia.org/desert-elephants/) |
| Khác biệt giữa các loài sử dụng sương | [Ecosphere — Fog and fauna of the Namib Desert: past and future](https://esajournals.onlinelibrary.wiley.com/doi/10.1002/ecs2.2996) |

## Công cụ giọng được dùng

[Melo + Việt Studio 1.3.1](https://github.com/seotro95/seotro/releases/tag/melo-viet-studio-1.3.1-txt-srt-41595029816), mã nguồn cố định `4f4fa1d72d976d6e2b9c94f906b0e12c6a2cf043`, bộ online_backend/Microsoft Edge cho 16 giọng nam.

[Voice Studio Hmong 1.6.6](https://github.com/seotro95/seotro/releases/tag/voice-studio-hmong-1.6.6), mã nguồn cố định `061430d958b8d5fc14d04209c6f0cd20492382c2`, Native VITS + OpenVoice V2, mẫu `hmong-female-3`, chế độ `clear-v1`. Mô hình H’Mông được tải từ các revision cố định của công cụ và xác minh SHA-256. Không đổi trọng số hay cao độ để giả giọng khác.

Môi trường hiện tại là Linux, nên gọi phần Python cùng mã nguồn của công cụ; không chạy tệp BAT Windows. Danh mục Edge hiện trả trường DisplayName thay cho FriendlyName: nạp danh mục đã bổ sung tên hiển thị tương ứng để qua kiểm tra danh mục cũ. Voice ID, locale và giới tính được đối chiếu với danh mục thực tế. Đây là giọng Edge trực tuyến trong công cụ, không phải mô hình Melo chạy cục bộ.

Các đoạn âm thanh được giữ trọn lời đầu vào, điều chỉnh nhịp bằng FFmpeg atempo giữ cao độ và ghép theo khối. Không cắt mất phần lời quá dài để ép đủ phút. Hồ sơ thời lượng lưu số mẫu giải mã thực tế, hệ số điều chỉnh nhịp và SHA-256; việc này kiểm tra tín hiệu/thời lượng, không thay thế nghe duyệt phát âm và nội dung bởi người bản ngữ.
