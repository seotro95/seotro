# Derinkuyu — căn cứ nội dung và giới hạn minh họa

Chủ đề 72 trong danh sách người dùng: **Derinkuyu: một thành phố hoạt động dưới đất / Derinkuyu: How a City Worked Underground**. Kịch bản tập trung vào cách các nhu cầu liên kết với nhau, không dựng một cuộc vây hãm có tên hoặc kể một gia đình không có nguồn chứng thực.

## Những điểm đã xử lý trong lời kể

**Vị trí và vật liệu.** Derinkuyu nằm dưới thị trấn cùng tên ở Cappadocia, miền trung Türkiye. Ngoại cảnh tháp đá đặc trưng của vùng là bối cảnh địa chất khu vực, không phải mô tả ngay cửa di tích. Tuff là đá tạo từ vật liệu phun trào đã gắn kết, không phải một đống tro bở. Độ bền thay đổi theo vật liệu, khe nứt, độ ẩm và hình dạng khoảng rỗng. Kịch bản không nói mọi đá núi lửa đều mềm hoặc đào đâu cũng an toàn.

**Tám tầng và con số khoảng 85 m.** Trang bảo tàng mô tả tám tầng; không dùng mô hình 18 tầng chồng đều. Brochure chính thức giải thích độ sâu khoảng 40 m theo trục gần cửa và khoảng 85 m khi tính cả giếng ở tầng bảy. Vì vậy, đoạn 13–15 và 53–54 tách đáy giếng khỏi sàn phòng. Con số 85 m không biến thành khẳng định toàn bộ khu ở sâu đến mức ấy; sơ đồ trong prompt không phải mặt cắt đo đạc.

**Không khí và nhiệt.** Trục thông gió là một phần của mạng lỗ mở, đường đi và phòng. Chênh áp do gió và chênh mật độ do nhiệt có thể tạo thông gió tự nhiên; cường độ và chiều phụ thuộc điều kiện. Đá có quán tính nhiệt, không có nghĩa nhiệt độ mọi phòng luôn bằng một con số. Nghiên cứu đo nhiệt độ, ẩm và áp suất hỗ trợ việc đặt câu hỏi có thể kiểm tra, không cho phép tuyên bố chất lượng không khí hoàn hảo với mọi số người.

**Nước, kho và sinh hoạt.** Mô tả chính thức nêu giếng, phòng chứa, không gian ép rượu, chuồng, nơi sinh hoạt và các tiện ích. Mỗi tính năng được đọc cùng nhu cầu vận chuyển, chuẩn bị và bảo quản. Sơ đồ nước–chất thải là cách giải thích yêu cầu chung, không phải bản thiết kế cống đã xác nhận tại Derinkuyu. Cảnh dịch vụ vệ sinh là minh họa kín đáo, không tái dựng quy trình cổ khi chưa có đủ chứng cứ.

**Sức chứa không phải dân số kiểm kê.** Một con số sức chứa được lặp lại phổ biến không cho biết bao nhiêu người sống ở đây trong một thời điểm hay bao lâu. Không dựng 20.000 người, không tuyên bố thành phố tự cung tự cấp hoặc có thể đóng kín mãi. Nguồn lực, lưu thông, tình trạng không khí và thời gian sử dụng phải xét cùng nhau.

**Niên đại nhiều giai đoạn.** Các giới thiệu gán khởi đầu vào nhiều thời kỳ khác nhau; có nguồn chính thức nhấn thời Byzantine, nguồn khác nói các tiền kỳ. Lời kể giữ điểm chắc hơn: di tích được sử dụng, sửa đổi và mở rộng trong một lịch sử dài; không gán toàn mạng cho một dân tộc hoặc một năm sáng lập. Bối cảnh Byzantine cho cảnh tái dựng là lựa chọn minh họa, không chứng minh mọi phòng có cùng niên đại.

**Tái phát hiện và các đô thị lân cận.** Năm 1963 thường xuất hiện trong giới thiệu hiện đại. Cảnh hầm nhà thập niên 1960 chỉ minh họa việc thấy một lỗ mở; không dựng chủ nhà, trẻ em hay cú búa cụ thể như sự kiện đã kiểm chứng. Kaymakli được dùng làm điểm so sánh khu vực. Bộ mới không khẳng định một đường hầm 9 km hoặc một siêu mạng đã khảo sát nối mọi nơi.

**Bảo tồn.** Nghiên cứu địa cơ học đã xem xét ổn định lâu dài và theo dõi các biến số. Cảnh chuyên gia kiểm tra không báo trước sụp đổ, không gắn màn hình số liệu giả. Cảnh hiện tại ở tuyến tham quan được phép; không dẫn người xem vào lối hạn chế hoặc sát mép giếng.

## Nguồn ưu tiên và cách dùng

Các đường dẫn được đối chiếu trong quá trình chuẩn bị ngày 13/11/2026. Website có thể đổi cấu trúc hoặc giới hạn truy cập. Dưới đây là liên kết nguồn, không phải giấy phép tái sử dụng ảnh/video.

| Nguồn | Dùng cho phần nào | Liên kết |
|---|---|---|
| Bảo tàng/Bộ Văn hóa và Du lịch Türkiye — Derinkuyu | Mô tả di tích, tầng, các loại không gian, tuyến tham quan | https://muze.gov.tr/muze-detay?DistId=DKY&SectionId=DKY01 |
| Cổng văn hóa Türkiye | Tổng quan địa điểm, chức năng và giới thiệu lịch sử | https://www.kulturportali.gov.tr/turkiye/nevsehir/gezilecekyer/derinkuyu-yeralti-sehri |
| Bộ Văn hóa và Du lịch, giới thiệu tiếng Anh | Đối chiếu cách giới thiệu niên đại và tiện ích | https://www.ktb.gov.tr/EN-113738/derinkuyu-underground-city.html |
| Brochure Derinkuyu chính thức, Turkish Museums | Cách giải thích độ sâu 40 m/85 m gồm giếng; các loại không gian | https://turkishmuseums.com/Uploads/M%C3%BCze/Dosya/57dbff8e-157e-442d-a48f-aa4a62d4dfc6.pdf |
| UNESCO — Göreme National Park and the Rock Sites of Cappadocia | Bối cảnh rock-cut settlement và nơi trú trong lịch sử vùng | https://whc.unesco.org/en/list/357/ |
| UNESCO — bản đồ khu di sản | Kiểm tra quan hệ vị trí, không suy ra đường hầm kết nối | https://whc.unesco.org/en/list/357/maps/ |
| Ö. Aydan & R. Ulusay, 2013, *Geomechanical Evaluation of Derinkuyu Antique Underground City and Its Implications in Geoengineering* | Địa cơ học; điều kiện trong đá; theo dõi môi trường và ổn định | https://doi.org/10.1007/s00603-012-0301-7 |
| Hồ sơ nghiên cứu tại Hacettepe University | Tóm tắt công trình Aydan–Ulusay | https://avesis.hacettepe.edu.tr/yayin/434d6101-1a8f-4c31-802a-dd929830cef4/geomechanical-evaluation-of-derinkuyu-antique-underground-city-and-its-implications-in-geoengineering |
| USGS — Tuff / Volcanic ash | Giải thích vật liệu núi lửa, phân biệt tro và đá đã gắn kết | https://volcanoes.usgs.gov/volcanic_ash/glossary/tuff.html ; https://volcanoes.usgs.gov/volcanic_ash/ash.html |
| WHO — Natural Ventilation for Infection Control in Health-Care Settings, nguyên lý vật lý | Chênh áp, gió và lực nổi của thông gió tự nhiên; chỉ lấy nguyên lý chung, không suy diễn chỉ số cho Derinkuyu | https://www.ncbi.nlm.nih.gov/books/NBK143285/ |
| FAO — Grain storage principles | Ẩm, nhiệt, sâu hại và điều kiện bảo quản; nguyên lý chung, không xác nhận kỹ thuật cụ thể của di tích | https://www.fao.org/4/x5065e/x5065e04.htm |

Không dùng chuyện người ngoài hành tinh, nền văn minh siêu nhiên, cửa chống mọi chất độc, số dân hoặc niên đại tuyệt đối như sự kiện. Không sử dụng bản chép lời của video nguồn như một nguồn khảo cổ cho Derinkuyu. Phần phân tích nguồn chỉ giải thích kỹ thuật kể chuyện và dựng.
