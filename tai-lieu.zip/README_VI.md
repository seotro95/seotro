# Skeleton Coast — chủ đề 26 — 21:52

Kịch bản tiếng Anh gốc: 3.164 từ. Lời Việt và các bản đọc quốc tế được chuẩn bị riêng. Có 132 prompt, số liên tục; 13 TXT đủ 10 prompt và TXT cuối gồm 2 prompt. Tạo mỗi clip 10 giây; dùng đủ 131 clip đầu và 2 giây đầu clip cuối.

Các voice đã được đưa vào các khối âm thanh có nhãn quốc gia trong cuộc trò chuyện. Mỗi bản gốc là MP3 mono 192 kbps, 48 kHz, giải mã đúng 62.976.000 mẫu = 1.312 giây = 21:52. Bản tiếng Anh cuối cùng gửi trong chat là bản gốc 192 kbps. Các khối âm thanh được gửi trực tiếp, không phải tệp đính kèm GitHub release.

Tiếng Anh: Andrew; Việt: Nam Minh; H’Mông Trắng: nữ female-3. Các giọng còn lại là nam. Giữ VOICE_PROFILES_LOCKED.json, NARRATION_STYLE_LOCKED.json và bản tham chiếu H’Mông khi tái sử dụng. Hồ sơ ghi URL mẫu tham chiếu tại commit cố định và SHA-256. Danh tính giọng online vẫn có thể được nhà cung cấp cập nhật trong tương lai.

Tiếng Anh khớp các cảnh 10 giây; bản dịch khớp khối 100 giây và tổng độ dài. Đây không phải căn từng từ cho mọi ngôn ngữ. Các SRT trong timed_voice_inputs là mốc tạo voice, không phải phụ đề ngắn đã dàn để hiển thị trên phim.

Các bản quốc tế có hỗ trợ dịch máy và biên tập. H’Mông được viết lại theo ngữ cảnh, toàn bộ lời vượt kiểm tra ký tự thực tế của engine. Chưa có người bản ngữ độc lập nghe duyệt toàn bộ, nhất là xác nhận phương ngữ Hmoob Dawb. Báo cáo thời lượng và SHA-256 không thay thế nghe duyệt phát âm.

Chưa tạo footage hoặc MP4. Mọi prompt video đều yêu cầu không âm thanh, không lời nói và không hình trẻ em. Vẫn cần kiểm tra các clip thực tế khi tạo.

Gói tài liệu chính gồm kịch bản Anh–Việt, lời H’Mông, timeline, 14 TXT prompt, 5 tiêu đề/5 prompt thumbnail, phân tích nguồn và hồ sơ giọng. Bộ tài liệu đầy đủ còn giữ tất cả 17 bản lời và báo cáo âm thanh. Hồ sơ giọng và bản đọc đã hoàn tất; vấn đề GitHub chỉ nằm ở tải tệp đính kèm, bị trả HTTP 401 trong phiên hiện tại.
