﻿# Chủ đề 72 — Derinkuyu: How a City Worked Underground

Thời lượng chương trình: **20:42**. Voice tiếng Anh có lời từ 00:00 đến 20:40; 20:40–20:42 là khoảng kết im lặng.

Bản tiếng Việt dưới đây dùng để đọc và kiểm tra ý. File voice VI được căn theo khối 100 giây, không hứa khớp từng câu 10 giây. Cột prompt dựng lấy từ EDIT_DECISIONS.csv.

## 01 — Cửa đá và câu hỏi sống còn

### 001 | 00:00:00–00:00:10

**EN:** A round stone closes a narrow passage. Behind it, people may be safer from an enemy. But safety creates another question: how do they keep breathing?

**VI:** Một tảng đá tròn bịt lối đi hẹp. Người phía sau có thể tránh được kẻ thù. Nhưng an toàn lại đặt ra câu hỏi khác: họ tiếp tục thở bằng cách nào?

**Dựng hình:** P001 [0–5s]; P002 [5–10s]

**Clip tạo P001:** Illustrative Byzantine-period Derinkuyu reconstruction, heavy circular stone door beside narrow rock-cut passage; 35mm low slow dolly toward its recessed groove, one clearly adult attendant, tiny oil lamp.
### 002 | 00:00:10–00:00:20

**EN:** Above their heads, a small opening still connects the darkness to the sky. This city depends as much on what stays open as on what closes.

**VI:** Trên đầu họ, một lỗ mở nhỏ vẫn nối bóng tối với bầu trời. Thành phố này phụ thuộc vào những chỗ để mở cũng như những nơi đóng kín.

**Dựng hình:** P001 [10–15s]; P002 [15–20s]

**Clip tạo P002:** Reference-informed present-day Derinkuyu ventilation shaft, 24mm camera at protected floor level slowly tilts upward toward a small daylight opening, textured beige-gray tuff walls, no people leaning over edges.
### 003 | 00:00:20–00:00:30

**EN:** Derinkuyu lies beneath an ordinary town in central Türkiye. At street level, the entrance gives little warning of the rooms and routes below your feet.

**VI:** Derinkuyu nằm dưới một thị trấn bình thường ở miền trung Thổ Nhĩ Kỳ. Nhìn từ đường phố, lối vào khó cho biết bên dưới chân có bao nhiêu phòng và đường đi.

**Dựng hình:** P003 [20–25s]; P004 [25–30s]

**Clip tạo P003:** Present-day Derinkuyu town, modest low buildings above the visitor entrance; 35mm elevated gentle push toward the entrance, adults only if distant pedestrians appear, ordinary Anatolian setting.
### 004 | 00:00:30–00:00:40

**EN:** We are in Cappadocia, a landscape shaped by volcanic deposits and erosion. Here, people could build a place by taking the ground away.

**VI:** Chúng ta đang ở Cappadocia, miền đất được trầm tích núi lửa và xói mòn tạo hình. Tại đây, người ta có thể xây dựng bằng cách lấy đất đá ra.

**Dựng hình:** P003 [30–35s]; P004 [35–40s]

**Clip tạo P004:** Accurate reference-based central Türkiye map centered on Cappadocia and Derinkuyu, restrained top-down camera zoom from regional scale to town, no generated labels or disputed borders.
### 005 | 00:00:40–00:00:50

**EN:** The region's familiar rock towers rise into daylight. Underground, the same broad geological story offered another possibility: a material that hands and tools could excavate.

**VI:** Những tháp đá quen thuộc của vùng vươn lên ánh sáng. Dưới đất, lịch sử địa chất ấy mở ra khả năng khác: loại đá bàn tay và công cụ có thể đào khoét.

**Dựng hình:** P005 [40–45s]; P006 [45–50s]

**Clip tạo P005:** Cappadocian volcanic-tuff landscape at dawn, 24mm smooth lateral aerial past eroded pale rock forms, geographically plausible central Anatolia, no balloons required.
### 006 | 00:00:50–00:01:00

**EN:** That material includes tuff, formed from consolidated volcanic debris. It is rock, not loose fireplace ash, and its properties vary from layer to layer.

**VI:** Vật liệu ấy có đá tuf, hình thành từ vật chất núi lửa đã gắn kết. Đó là đá, không phải tro bếp rời, và tính chất thay đổi giữa các lớp.

**Dựng hình:** P005 [50–55s]; P006 [55–60s]

**Clip tạo P006:** Macro 100mm tuff surface showing fine ash matrix, small embedded fragments and tool marks; slow sideways slider, neutral daylight, adult geologist's gloved hand for scale only.
### 007 | 00:01:00–00:01:10

**EN:** Long before the city, eruptions laid down material across this region. Later weathering and erosion reshaped the surface that visitors recognize as Cappadocia today.

**VI:** Rất lâu trước khi có thành phố, núi lửa đã phủ vật chất lên vùng này. Phong hóa và xói mòn về sau tạo lại bề mặt Cappadocia mà du khách thấy hôm nay.

**Dựng hình:** P007 [60–70s]

**Clip tạo P007:** Restrained scientific geological illustration of successive volcanic deposits becoming layered terrain, 50mm side cutaway, slow reveal through strata, no modern town destroyed by an eruption.
### 008 | 00:01:10–00:01:20

**EN:** The builders worked within those inherited layers. A change in hardness, a natural crack, or a weak zone could influence where a room could safely expand.

**VI:** Người đào phải làm việc trong những lớp đá có sẵn. Độ cứng thay đổi, khe nứt tự nhiên hay vùng yếu đều ảnh hưởng nơi một căn phòng có thể mở rộng.

**Dựng hình:** P008 [70–80s]

**Clip tạo P008:** Reference-informed underground tuff wall with visible natural joints beside carved surface, 85mm close slow tilt following a crack, modest modern inspection light, no collapse.
### 009 | 00:01:20–00:01:30

**EN:** Imagine the labor at the cutting face: repeated blows, falling chips, and baskets carried back through the opening. Every new room first existed as rock.

**VI:** Hãy hình dung công việc ở mặt đào: những nhát đục lặp lại, vụn đá rơi, giỏ đá được đưa ra qua cửa. Mỗi căn phòng mới ban đầu đều là đá đặc.

**Dựng hình:** P009 [80–90s]

**Clip tạo P009:** Historically inspired adult Anatolian worker aged over 35 using a simple iron chisel and small hammer on tuff, 85mm hand close-up, controlled chips, period-neutral wool and linen, illustrative reconstruction.
### 010 | 00:01:30–00:01:40

**EN:** Removing the material created space, but leaving enough behind created support. Walls, pillars, roof shape, and the rock above had to remain part of the design.

**VI:** Lấy vật liệu đi tạo ra không gian; giữ lại đủ đá tạo phần chịu lực. Tường, trụ, hình mái và khối đá bên trên đều là một phần thiết kế.

**Dựng hình:** P010 [90–100s]

**Clip tạo P010:** Wide 24mm present-day Derinkuyu chamber with thick retained rock pillars and curved low ceiling, slow eye-level dolly around a pillar, realistic modest dimensions, no cathedral-scale hall.
### 011 | 00:01:40–00:01:50

**EN:** This is architecture by subtraction. Unlike a house assembled from separate blocks, much of the structure remains continuous with the ground surrounding it.

**VI:** Đây là kiến trúc bằng cách bớt đi. Khác ngôi nhà ghép từ từng khối riêng, phần lớn kết cấu vẫn liền với nền đá bao quanh.

**Dựng hình:** P011 [100–105s]; P012 [105–110s]

**Clip tạo P011:** Conceptual 3D solid tuff block with a modest chamber gradually revealed through a moving section plane; 50mm oblique slow orbit, no instant real excavation or exact surveyed plan claim.
### 012 | 00:01:50–00:02:00

**EN:** That continuity can be useful, but it does not make every cavity automatically stable. Rock quality, moisture, fractures, and the size of openings still matter.

**VI:** Sự liền khối có ích, nhưng không khiến mọi khoảng rỗng tự động bền vững. Chất lượng đá, độ ẩm, khe nứt và kích thước lỗ mở vẫn quan trọng.

**Dựng hình:** P011 [110–115s]; P012 [115–120s]

**Clip tạo P012:** Adult rock-mechanics researcher examining a chamber junction from an established visitor route, 50mm medium-wide slow pan toward intact roof, unobtrusive inspection device, no invented danger alarm.
### 013 | 00:02:00–00:02:10

**EN:** Derinkuyu is often described as reaching about eighty-five meters deep. Yet a depth figure needs a starting point, an ending point, and a clear definition.

**VI:** Derinkuyu thường được mô tả sâu khoảng tám mươi lăm mét. Nhưng một con số độ sâu cần điểm đầu, điểm cuối và định nghĩa rõ ràng.

**Dựng hình:** P013 [120–130s]

**Clip tạo P013:** Simplified scientific section of underground rooms and a deeper narrow well, 35mm oblique camera descends gently, room depths deliberately not numbered, diagram explicitly illustrative rather than exact site model.
### 014 | 00:02:10–00:02:20

**EN:** An official visitor brochure includes the deep well when explaining that figure. A room floor and the bottom of a well are different measurements.

**VI:** Một tờ giới thiệu chính thức tính cả giếng sâu khi giải thích con số ấy. Sàn phòng và đáy giếng là hai mốc đo khác nhau.

**Dựng hình:** P014 [130–140s]

**Clip tạo P014:** Reference-informed deep well viewed safely from behind a low barrier, 50mm slow downward tilt, upper chamber floor visible beside shaft, no person descending or exaggerated endless abyss.
### 015 | 00:02:20–00:02:30

**EN:** The museum describes a city of eight levels, but this is no simple stack of identical floors. Routes bend, spaces differ, and functions overlap.

**VI:** Bảo tàng mô tả thành phố có tám tầng, nhưng đó không phải chồng sàn giống hệt nhau. Lối đi uốn, không gian khác nhau và chức năng đan xen.

**Dựng hình:** P015 [140–150s]

**Clip tạo P015:** Reference-informed multi-level spatial illustration with irregular modest rooms and staggered connecting passages, 35mm controlled side orbit, no uniform skyscraper floors, no eighteen-level fantasy.
### 016 | 00:02:30–00:02:40

**EN:** A useful way to explore it is therefore to follow its needs. Protection, air, water, food, and cooperation turn connected holes into a working settlement.

**VI:** Vì vậy, có thể khám phá nơi này qua các nhu cầu: che chở, không khí, nước, thức ăn và hợp tác. Chúng biến những hốc nối nhau thành nơi cư trú hoạt động.

**Dựng hình:** P016 [150–160s]

**Clip tạo P016:** Conceptual cutaway of three neighboring rock-cut spaces linked to a shaft and a storage chamber, 35mm slow reveal, a few clearly adult scale figures only, no glowing magical infrastructure.
### 017 | 00:02:40–00:02:50

**EN:** The underground spaces served as places of refuge and storage within a wider inhabited landscape. The life above ground did not suddenly become irrelevant.

**VI:** Không gian ngầm là nơi trú và dự trữ trong một vùng đã có người sống. Cuộc sống trên mặt đất không bỗng trở nên không còn quan trọng.

**Dựng hình:** P017 [160–165s]; P018 [165–170s]

**Clip tạo P017:** Historically inspired adult villagers carrying modest baskets toward a discreet rock-cut entrance in an Anatolian settlement, 50mm eye-level slow lateral track, no battle or panic.
### 018 | 00:02:50–00:03:00

**EN:** To understand why people entered, begin with the route itself. The descent is narrow, controlled, and very different from a broad street open to the sky.

**VI:** Muốn hiểu vì sao người ta xuống đây, hãy nhìn chính con đường. Lối xuống hẹp, có thể kiểm soát, khác hẳn đường phố rộng mở dưới trời.

**Dựng hình:** P017 [170–175s]; P018 [175–180s]

**Clip tạo P018:** Present-day narrow Derinkuyu descending passage with worn irregular steps, 24mm slow forward camera at adult eye level, modest existing visitor lighting, empty corridor.

## 02 — Lối đi, cửa chắn và di chuyển

### 019 | 00:03:00–00:03:10

**EN:** A passage wide enough for one person changes the movement of a group. People must follow one another, and carrying a bulky object becomes a task.

**VI:** Lối chỉ đủ một người làm thay đổi chuyển động của cả nhóm. Mọi người phải nối nhau, và mang vật cồng kềnh trở thành việc không đơn giản.

**Dựng hình:** P019 [180–185s]; P020 [185–190s]

**Clip tạo P019:** Adult visitor aged over 40 moving carefully through a single-person rock-cut corridor, 50mm rear three-quarter slow follow, plain contemporary clothing, realistic restricted height.
### 020 | 00:03:10–00:03:20

**EN:** For a defender, restricted access could be an advantage. The same restriction, however, also shaped how residents moved supplies and reached the spaces they needed.

**VI:** Với người phòng thủ, lối vào hạn chế là lợi thế. Nhưng chính sự hạn chế ấy cũng chi phối việc đưa đồ tiếp tế và đi lại của người cư trú.

**Dựng hình:** P019 [190–195s]; P020 [195–200s]

**Clip tạo P020:** Illustrative adult worker carrying a small grain sack through a low passage, 50mm side view from a chamber entrance, unhurried single-file movement, plausible load and body scale.
### 021 | 00:03:20–00:03:30

**EN:** A turn in the route hides what comes next. Light from one chamber may not reach the next doorway, making local knowledge valuable in the dark.

**VI:** Một khúc ngoặt che điều phía trước. Ánh sáng từ phòng này có thể không tới cửa tiếp theo, khiến việc thuộc đường rất có giá trị trong bóng tối.

**Dựng hình:** P021 [200–210s]

**Clip tạo P021:** 24mm slow dolly toward a right-angle bend in a tuff tunnel, warm light disappears around corner while foreground remains dim, stable camera, no horror creature.
### 022 | 00:03:30–00:03:40

**EN:** These spaces ask the body to adapt: lower the head, turn the shoulders, choose where to place a foot. The architecture controls the pace.

**VI:** Không gian bắt cơ thể thích ứng: cúi đầu, xoay vai, chọn nơi đặt chân. Chính kiến trúc quyết định nhịp di chuyển.

**Dựng hình:** P022 [210–220s]

**Clip tạo P022:** Clearly adult researcher crouches slightly beneath a low lintel, 85mm medium close side view showing shoulders and rock clearance, realistic passage scale, no child-sized figure.
### 023 | 00:03:40–00:03:50

**EN:** Then comes the circular stone door. Set across a restricted opening, a heavy slab could turn an accessible passage into a substantial physical barrier.

**VI:** Rồi tới cửa đá tròn. Đặt ngang một lỗ mở hẹp, phiến đá nặng có thể biến lối đi thành một rào cản đáng kể.

**Dựng hình:** P023 [220–225s]; P024 [225–230s]

**Clip tạo P023:** Reference-informed circular rolling stone door in its actual-looking tuff alcove, 35mm low slow lateral move showing door, opening and recess together, no giant fantasy gate.
### 024 | 00:03:50–00:04:00

**EN:** Its surrounding recess matters as much as the stone. A door needs somewhere to move, an edge to meet, and a way to be controlled.

**VI:** Hốc quanh cửa cũng quan trọng như chính tảng đá. Cửa cần chỗ di chuyển, mép để khép và cách vận hành.

**Dựng hình:** P023 [230–235s]; P024 [235–240s]

**Clip tạo P024:** 85mm close inspection of the circular stone slab edge, central aperture and rock-cut side recess, slow slider across contact surfaces, no invented metal hinges.
### 025 | 00:04:00–00:04:10

**EN:** From the occupied side, people could guide the stone into position. Moving a heavy barrier required effort and coordination, rather than a weightless automatic mechanism.

**VI:** Từ phía bên trong, người ta có thể đưa đá vào vị trí. Chuyển rào nặng cần sức và phối hợp, không phải một cơ cấu tự động nhẹ bẫng.

**Dựng hình:** P025 [240–245s]; P026 [245–250s]

**Clip tạo P025:** Illustrative Byzantine-inspired reconstruction, two clearly adult workers brace and slowly move a heavy circular slab a short distance along its recess, 50mm fixed side camera, believable effort.
### 026 | 00:04:10–00:04:20

**EN:** The visible arrangement explains the principle, even when we cannot recover every detail of an ancient operation. Geometry can tell us something without inventing a specific siege.

**VI:** Bố trí còn thấy giải thích được nguyên lý, dù không khôi phục hết chi tiết vận hành xưa. Hình học kể được một phần mà không cần bịa ra cuộc vây hãm cụ thể.

**Dựng hình:** P025 [250–255s]; P026 [255–260s]

**Clip tạo P026:** Restrained scientific 3D close model of a circular stone moving across a narrow passage opening, 50mm fixed oblique view, rock-based mechanism only, no motors or invented engineering blueprint.
### 027 | 00:04:20–00:04:30

**EN:** Once the opening closes, the corridor on the far side becomes harder to cross. Yet the people inside still need everything that keeps a community alive.

**VI:** Khi lỗ mở khép lại, người bên ngoài khó vượt qua hơn. Nhưng người bên trong vẫn cần mọi thứ giúp một cộng đồng sống được.

**Dựng hình:** P027 [260–265s]; P028 [265–270s]

**Clip tạo P027:** Wide 35mm chamber-side view of closed stone doorway with one small oil lamp and a few empty ceramic containers, slow pullback, no attack reenactment.
### 028 | 00:04:30–00:04:40

**EN:** A sealed route is therefore only one part of protection. The settlement also depends on connections that cannot simply be shut down with the entrance.

**VI:** Vì thế, đóng lối vào chỉ là một phần che chở. Nơi cư trú còn phụ thuộc những kết nối không thể cùng lúc đóng lại.

**Dựng hình:** P027 [270–275s]; P028 [275–280s]

**Clip tạo P028:** 35mm slow tilt from closed doorway toward a separate small ventilation opening high in the rock wall, physically plausible modest chamber, no impossible bright beam through solid rock.
### 029 | 00:04:40–00:04:50

**EN:** Refuge did not mean perfect invisibility. People still interacted with the surface, and any occupied place leaves practical needs beyond its walls.

**VI:** Trú ẩn không có nghĩa là hoàn toàn vô hình. Con người vẫn tương tác với mặt đất, và nơi có người ở luôn phát sinh nhu cầu vượt ra ngoài tường.

**Dựng hình:** P029 [280–290s]

**Clip tạo P029:** Historically inspired exterior of modest Cappadocian village entrance with adult workers bringing water vessels, 70mm distant observational pan, subdued daylight, no concealed modern military bunker.
### 030 | 00:04:50–00:05:00

**EN:** The entrance belongs to that relationship. It marks a boundary between ordinary activity above and a more controlled arrangement of space below.

**VI:** Lối vào thuộc mối quan hệ ấy. Nó đánh dấu ranh giới giữa sinh hoạt trên mặt đất và cách tổ chức không gian được kiểm soát chặt hơn phía dưới.

**Dựng hình:** P030 [290–300s]

**Clip tạo P030:** Present-day Derinkuyu entrance threshold, 35mm camera gently moves from sunlit exterior toward shadowed stair, natural exposure adjustment, no dramatic trapdoor spectacle.
### 031 | 00:05:00–00:05:10

**EN:** Nor should every passage become a scene of battle in our imagination. Much of the work here was carrying, maintaining, storing, waiting, and finding a route.

**VI:** Cũng không nên hình dung mọi đường hầm là chiến trường. Nhiều công việc ở đây là chuyên chở, bảo trì, cất giữ, chờ đợi và tìm đường.

**Dựng hình:** P031 [300–305s]; P032 [305–310s]

**Clip tạo P031:** Two clearly adult residents in an illustrative historical reconstruction move a covered pottery vessel within an ordinary rock-cut room, 50mm eye-level slow track, quiet routine, no weapons.
### 032 | 00:05:10–00:05:20

**EN:** That quieter activity gives the city its scale. A tunnel measured against one person's shoulders becomes part of a wider organization of daily effort.

**VI:** Những việc lặng lẽ ấy cho thấy quy mô thành phố. Đường hầm vừa vai một người lại thuộc một hệ thống phân chia công việc lớn hơn.

**Dựng hình:** P031 [310–315s]; P032 [315–320s]

**Clip tạo P032:** Adult hands resting briefly on a carried basket at the doorway of a modest chamber, 85mm close-to-medium slow pullback showing narrow access, no touching fragile decorated surfaces.
### 033 | 00:05:20–00:05:30

**EN:** Imagine several groups sharing these routes. Decisions about who moves first, where supplies wait, and which passage remains clear would have practical consequences.

**VI:** Hãy hình dung nhiều nhóm cùng dùng đường đi này. Ai đi trước, đồ tiếp tế chờ ở đâu, lối nào phải thông đều là quyết định có hệ quả thực tế.

**Dựng hình:** P033 [320–330s]

**Clip tạo P033:** Conceptual overhead spatial model with a few adult silhouettes moving in single file between waiting alcoves and a corridor, slow 35mm top-down glide, no real recovered traffic plan claim.
### 034 | 00:05:30–00:05:40

**EN:** So the door is our starting point, not the whole explanation. Follow the spaces beyond it, and the first invisible requirement becomes impossible to ignore: air.

**VI:** Cửa đá là điểm bắt đầu, chưa phải toàn bộ lời giải. Theo những khoảng phía sau, nhu cầu vô hình đầu tiên hiện rõ: không khí.

**Dựng hình:** P034 [330–340s]

**Clip tạo P034:** 24mm slow forward move from a stone-door alcove into a chamber aligned with a vertical shaft, dim warm foreground and cool daylight above, no on-screen text.

## 03 — Không khí, ánh sáng và nhiệt

### 035 | 00:05:40–00:05:50

**EN:** Stand beneath a ventilation shaft and look upward. A small patch of sky can make the connection between an underground room and the open world visible.

**VI:** Đứng dưới giếng thông khí và ngước lên. Một mảnh trời nhỏ khiến mối nối giữa căn phòng ngầm với thế giới bên ngoài trở nên nhìn thấy được.

**Dựng hình:** P035 [340–350s]

**Clip tạo P035:** Reference-informed Derinkuyu ventilation shaft, 24mm protected low-angle view, slow upward tilt revealing irregular rock walls and a small blue daylight opening, no person climbing.
### 036 | 00:05:50–00:06:00

**EN:** But seeing an opening is not the same as measuring an airflow. What passes through it depends on the wider arrangement of openings and passages.

**VI:** Thấy lỗ mở không đồng nghĩa đã đo được luồng khí. Không khí đi qua bao nhiêu phụ thuộc bố trí các lỗ và đường đi trong toàn hệ thống.

**Dựng hình:** P036 [350–360s]

**Clip tạo P036:** 85mm close view of a small dark lateral opening into a larger shaft, very slow slider, realistic stone surfaces, no visible gale, no fabricated sensor readings.
### 037 | 00:06:00–00:06:10

**EN:** Natural ventilation works through pressure differences. Wind outside and differences in air density can help drive movement through a connected space.

**VI:** Thông gió tự nhiên dựa vào chênh lệch áp suất. Gió bên ngoài và khác biệt mật độ không khí có thể tạo chuyển động qua không gian liên thông.

**Dựng hình:** P037 [360–365s]; P038 [365–370s]

**Clip tạo P037:** Scientific cutaway of a simple underground chamber with two surface connections, sparse blue particles show gentle pressure-driven circulation, 50mm side view, explicitly conceptual, no exact Derinkuyu airflow map.
### 038 | 00:06:10–00:06:20

**EN:** Temperature can contribute to those density differences. Air in a shaft does not need an electric fan to move, but it does need suitable conditions.

**VI:** Nhiệt độ có thể tạo chênh lệch mật độ ấy. Không khí trong giếng không nhất thiết cần quạt điện để di chuyển, nhưng cần điều kiện phù hợp.

**Dựng hình:** P037 [370–375s]; P038 [375–380s]

**Clip tạo P038:** Restrained scientific shaft model with warmer and cooler air represented by subtle red and blue particles, 50mm slow orbit, no fan or magical self-powered apparatus.
### 039 | 00:06:20–00:06:30

**EN:** Under some conditions, warmer air rises and cooler air replaces it. Under others, the direction or strength of movement can change with the weather.

**VI:** Trong một số điều kiện, khí ấm đi lên và khí mát thay vào. Trong điều kiện khác, hướng hoặc cường độ chuyển động thay đổi theo thời tiết.

**Dựng hình:** P039 [380–385s]; P040 [385–390s]

**Clip tạo P039:** Conceptual vertical shaft section with one gentle buoyancy-driven circulation pattern, 50mm static side view, restrained particles, no universal or permanent-direction claim.
### 040 | 00:06:30–00:06:40

**EN:** That is why a simple arrow cannot describe every room in every season. The actual network, the surface conditions, and the number of occupants all matter.

**VI:** Vì thế, một mũi tên đơn giản không mô tả được mọi phòng trong mọi mùa. Mạng đường thực tế, điều kiện trên mặt đất và số người đều quan trọng.

**Dựng hình:** P039 [390–395s]; P040 [395–400s]

**Clip tạo P040:** Adult environmental researcher checks a small handheld airflow instrument near a shaft without displaying a fabricated value, 70mm medium view, soft modern practical light, no tourists crowding.
### 041 | 00:06:40–00:06:50

**EN:** Air must find a usable route through the system. A shaft, a connecting passage, and a chamber work together; an isolated opening explains only a fragment.

**VI:** Không khí phải tìm được đường đi qua hệ thống. Giếng, đường nối và căn phòng cùng hoạt động; một lỗ riêng lẻ chỉ giải thích được một phần.

**Dựng hình:** P041 [400–405s]; P042 [405–410s]

**Clip tạo P041:** Conceptual 3D chamber-and-shaft model, sparse neutral particles pass through connected spaces, 35mm slow tracking from surface opening toward chamber, realistic small passages, no exact surveyed layout claim.
### 042 | 00:06:50–00:07:00

**EN:** Imagine closing an internal door or filling a passage with people and supplies. Even without modern equipment, the relationship between space and circulation would remain important.

**VI:** Hãy hình dung một cửa bên trong đóng lại, hay lối đi đầy người và đồ tiếp tế. Dù chưa có thiết bị hiện đại, quan hệ giữa không gian và lưu thông vẫn quan trọng.

**Dựng hình:** P041 [410–415s]; P042 [415–420s]

**Clip tạo P042:** Illustrative historical room with three clearly adult residents and a few storage vessels kept beside rather than across a corridor, 50mm slow side dolly, no crowd crush or blocked airway disaster.
### 043 | 00:07:00–00:07:10

**EN:** Every person changes an occupied room. Breathing uses oxygen and releases carbon dioxide, while activity adds heat and moisture to the surrounding air.

**VI:** Mỗi người làm thay đổi căn phòng có người ở. Hô hấp dùng ôxy và thải khí cacbon điôxít; hoạt động còn đưa nhiệt và hơi ẩm vào không khí.

**Dựng hình:** P043 [420–425s]; P044 [425–430s]

**Clip tạo P043:** Respectful adult human silhouette within a simple room model, subtle particles and muted thermal haze indicate respiration and body heat, 50mm fixed side view, no medical diagnosis or invented measurements.
### 044 | 00:07:10–00:07:20

**EN:** Lighting adds another demand. A small flame makes work possible, but combustion also changes the air. More light is not automatically a better living environment.

**VI:** Chiếu sáng tạo thêm nhu cầu. Ngọn lửa nhỏ giúp làm việc, nhưng sự cháy cũng đổi không khí. Nhiều ánh sáng hơn không tự động khiến môi trường sống tốt hơn.

**Dựng hình:** P043 [430–435s]; P044 [435–440s]

**Clip tạo P044:** Macro 85mm modest historically plausible ceramic oil lamp with one small steady flame inside a rock-cut room, slow focus pull toward surrounding darkness, no smoky bonfire.
### 045 | 00:07:20–00:07:30

**EN:** A few well-placed lamps could make a small working area usable. Beyond it, darkness remained, and keeping that light alive required fuel and attention.

**VI:** Vài ngọn đèn đặt hợp lý có thể làm một khoảng nhỏ dùng được. Ngoài quầng sáng vẫn là bóng tối; duy trì ánh đèn cần nhiên liệu và chăm sóc.

**Dựng hình:** P045 [440–445s]; P046 [445–450s]

**Clip tạo P045:** Historically inspired adult artisan works beside one small ceramic lamp on a low surface, 50mm medium side view, localized warm light, surrounding chamber remains genuinely dim, no electric fittings.
### 046 | 00:07:30–00:07:40

**EN:** The darkness between pools of light matters too. An underground life depends partly on knowing a room through habit, touch, and the location of familiar objects.

**VI:** Bóng tối giữa những quầng sáng cũng quan trọng. Sống dưới đất phần nào dựa vào việc thuộc căn phòng qua thói quen, cảm nhận và vị trí đồ vật quen thuộc.

**Dựng hình:** P045 [450–455s]; P046 [455–460s]

**Clip tạo P046:** 85mm close view of clearly adult hands finding the handle of a ceramic vessel beside a small lamp, gentle side slider, no person touching sacred or fragile original artifacts.
### 047 | 00:07:40–00:07:50

**EN:** Modern researchers have monitored temperature, moisture, and air pressure here. Their work replaces the vague impression of a comfortable cave with questions that can be measured.

**VI:** Các nhà nghiên cứu hiện đại đã theo dõi nhiệt độ, độ ẩm và áp suất tại đây. Công việc ấy biến cảm giác hang mát dễ chịu thành những câu hỏi có thể đo.

**Dựng hình:** P047 [460–470s]

**Clip tạo P047:** Present-day adult field researcher checking compact environmental instruments in an undecorated chamber, 70mm observational slow pan, screen angled away so no fabricated data are legible.
### 048 | 00:07:50–00:08:00

**EN:** That does not mean one measurement describes the whole city. Different spaces, seasons, visitor numbers, and openings can produce different conditions within the same site.

**VI:** Một phép đo không mô tả được toàn thành phố. Không gian, mùa, lượng khách và các lỗ mở khác nhau có thể tạo điều kiện khác nhau trong cùng di tích.

**Dựng hình:** P048 [470–480s]

**Clip tạo P048:** Reference-informed empty corridor leading toward two differently lit chambers, 35mm slow steady push, subtle natural light variation, no invented temperature labels or gauges.
### 049 | 00:08:00–00:08:10

**EN:** The surrounding rock also moderates temperature changes. Heat travels through a large mass more slowly than a sudden change in the air outside might suggest.

**VI:** Đá bao quanh còn điều hòa biến đổi nhiệt. Nhiệt truyền qua khối vật chất lớn chậm hơn điều ta cảm nhận từ thay đổi đột ngột ngoài trời.

**Dựng hình:** P049 [480–485s]; P050 [485–490s]

**Clip tạo P049:** Scientific cross-section of tuff surrounding a modest chamber, slow moving muted heat gradient remains near exterior before progressing inward, 50mm static side view, no numerical temperature claim.
### 050 | 00:08:10–00:08:20

**EN:** So an underground room can feel cooler in hot weather and relatively sheltered in cold weather. Stable does not mean identical everywhere, or unchanging forever.

**VI:** Vì vậy, phòng ngầm có thể mát hơn khi trời nóng và bớt chịu lạnh khi trời rét. Ổn định không có nghĩa mọi nơi giống nhau hay mãi không đổi.

**Dựng hình:** P049 [490–495s]; P050 [495–500s]

**Clip tạo P050:** Simplified comparative surface-and-underground thermal illustration within one continuous section, subtle external sunlight changes while interior stays more muted, 35mm slow pan, no split screen of false seasons.
### 051 | 00:08:20–00:08:30

**EN:** The city was using the behavior of air and rock together. A wall could provide shelter, while an opening made that shelter possible to occupy.

**VI:** Thành phố tận dụng đồng thời đặc tính không khí và đá. Bức vách che chở, còn lỗ mở giúp con người ở được trong nơi che chở ấy.

**Dựng hình:** P051 [500–510s]

**Clip tạo P051:** 35mm eye-level slow move from thick tuff wall to a separate shaft opening in the same chamber, warm lamp light below and cool daylight above, restrained physical realism.
### 052 | 00:08:30–00:08:40

**EN:** Air may be invisible, but it is never optional. Once we notice its routes, the next requirement becomes clearer: something much heavier to carry, water.

**VI:** Không khí có thể vô hình nhưng không thể thiếu. Khi đã nhận ra đường của nó, nhu cầu tiếp theo hiện rõ: thứ nặng hơn nhiều khi chuyên chở, đó là nước.

**Dựng hình:** P052 [510–520s]

**Clip tạo P052:** Clearly adult resident lifts an empty ceramic water jug beside a shaft alcove in an illustrative reconstruction, 70mm medium-close shot, slow downward tilt toward jug, no children.

## 04 — Nước và việc thường ngày

### 053 | 00:08:40–00:08:50

**EN:** A deep well links the settlement to water beneath the surface. It also reminds us that the underground city sits within a larger natural system.

**VI:** Giếng sâu nối khu cư trú với nước dưới mặt đất. Nó cũng nhắc rằng thành phố ngầm nằm trong một hệ thống tự nhiên lớn hơn.

**Dựng hình:** P053 [520–530s]

**Clip tạo P053:** Reference-informed Derinkuyu well opening in an upper chamber, protected 35mm oblique view with visible stone lip and deep shaft, slow cautious camera move, no staged unsafe descent.
### 054 | 00:08:50–00:09:00

**EN:** The well and the occupied rooms are not the same thing. Including a well's bottom in a depth figure changes how we picture the city.

**VI:** Giếng và các phòng có người ở không phải cùng một thứ. Tính cả đáy giếng vào độ sâu sẽ làm thay đổi cách hình dung thành phố.

**Dựng hình:** P054 [530–540s]

**Clip tạo P054:** Conceptual geological cutaway contrasts chamber-floor depth with a deeper well bottom, 50mm side-on slow reveal, two unlabelled measurement guides reserved for editor captions, no invented exact floor plan.
### 055 | 00:09:00–00:09:10

**EN:** Water was a resource, not an endless guarantee. Its usefulness depended on access, conditions underground, and the work needed to bring it where people lived.

**VI:** Nước là tài nguyên, không phải bảo đảm vô tận. Giá trị của nó phụ thuộc lối tiếp cận, điều kiện dưới đất và công đưa tới nơi mọi người sống.

**Dựng hình:** P055 [540–545s]; P056 [545–550s]

**Clip tạo P055:** Adult worker in an illustrative historical setting slowly raises a small water container using a simple rope at a well lip, 70mm side view, plausible load, no modern pump.
### 056 | 00:09:10–00:09:20

**EN:** Think of the journey after drawing it. A vessel still has to pass through narrow routes, reach a room, and be shared without spilling a precious supply.

**VI:** Hãy nghĩ tới hành trình sau lúc lấy nước: bình vẫn phải qua lối hẹp, tới căn phòng rồi được chia dùng mà không làm đổ nguồn quý giá.

**Dựng hình:** P055 [550–555s]; P056 [555–560s]

**Clip tạo P056:** Adult resident carries a modest covered water jug through a low tuff passage, 50mm rear-side slow follow, gentle deliberate movement, believable vessel weight.
### 057 | 00:09:20–00:09:30

**EN:** A few containers make the task look simple. Repeated for a larger group, the same movement becomes part of the settlement's daily organization.

**VI:** Vài chiếc bình khiến công việc trông đơn giản. Lặp lại cho nhóm đông hơn, cùng một chuyển động trở thành phần việc tổ chức hằng ngày của khu cư trú.

**Dựng hình:** P057 [560–565s]; P058 [565–570s]

**Clip tạo P057:** Three plain ceramic water containers arranged along a chamber edge while one adult moves another into place, 85mm low lateral slider, no decorative luxury pottery.
### 058 | 00:09:30–00:09:40

**EN:** This is one reason to study routes alongside rooms. A useful space needs more than enough floor area; it needs a way to receive necessities.

**VI:** Đó là lý do phải nghiên cứu đường đi cùng căn phòng. Không gian hữu ích không chỉ cần diện tích sàn mà còn cần cách nhận những thứ thiết yếu.

**Dựng hình:** P057 [570–575s]; P058 [575–580s]

**Clip tạo P058:** Conceptual overhead model of a well, narrow route and small receiving chamber, slow 35mm top-down glide follows one adult scale figure with a vessel, no asserted exact ancient plan.
### 059 | 00:09:40–00:09:50

**EN:** Water quality matters as well as quantity. A source used by people must be considered in relation to waste, handling, and activity around it.

**VI:** Chất lượng nước cũng quan trọng như số lượng. Nguồn người dùng cần được xét cùng chất thải, cách vận chuyển và hoạt động quanh nó.

**Dựng hình:** P059 [580–585s]; P060 [585–590s]

**Clip tạo P059:** Scientific planning illustration separates a water-drawing point from a hypothetical waste-handling corner, restrained 50mm oblique section, explicitly conceptual, no fabricated Derinkuyu sewage network.
### 060 | 00:09:50–00:10:00

**EN:** Stories sometimes turn these practical arrangements into perfect defenses against every threat. The surviving infrastructure is valuable enough without making it evidence for an unrecorded event.

**VI:** Đôi khi câu chuyện biến bố trí thực tế thành hệ phòng thủ hoàn hảo trước mọi nguy cơ. Hạ tầng còn lại đủ giá trị, không cần gán cho sự kiện chưa được ghi nhận.

**Dựng hình:** P059 [590–595s]; P060 [595–600s]

**Clip tạo P060:** Present-day close view of a plain well rim, rope wear and adjacent carved recess, 85mm slow focus pull, no poison illustration, no battle, no invented archaeological discovery.
### 061 | 00:10:00–00:10:10

**EN:** Official descriptions also include toilets among the facilities of the underground settlements. Sanitation belongs inside the story, even when it lacks the drama of a great stone door.

**VI:** Mô tả chính thức còn nhắc nhà vệ sinh trong các tiện ích ngầm. Vệ sinh phải có trong câu chuyện, dù không gây ấn tượng như cửa đá lớn.

**Dựng hình:** P061 [600–610s]

**Clip tạo P061:** Empty, undecorated rock-cut service alcove shown conservatively as an illustrative sanitation-related space, 50mm static eye-level camera, no exposed people, waste or invented modern plumbing.
### 062 | 00:10:10–00:10:20

**EN:** We should distinguish the listed function from a complete reconstruction of its operation. Exactly how every task was performed cannot be read from an empty chamber alone.

**VI:** Cần phân biệt chức năng được ghi nhận với việc khôi phục đầy đủ cách hoạt động. Không thể chỉ nhìn phòng trống mà biết chính xác mọi công việc đã diễn ra ra sao.

**Dựng hình:** P062 [610–620s]

**Clip tạo P062:** Adult archaeological researcher documents an empty service chamber with a notebook and camera, 70mm side observational shot, no legible fabricated labels, no touching historic surfaces.
### 063 | 00:10:20–00:10:30

**EN:** The ordinary demands keep accumulating: drinking, preparing food, cleaning, moving containers, and dealing with what people leave behind. Refuge is an ongoing workload.

**VI:** Những nhu cầu thường ngày tiếp tục cộng lại: uống, chuẩn bị thức ăn, làm sạch, chuyển bình và xử lý thứ con người để lại. Trú ẩn là công việc liên tục.

**Dựng hình:** P063 [620–625s]; P064 [625–630s]

**Clip tạo P063:** Illustrative adult residents perform restrained domestic tasks in a modest chamber, one fills a small cup while another arranges covered vessels, 35mm eye-level slow lateral move, no children.
### 064 | 00:10:30–00:10:40

**EN:** A single act, pouring a little water, reveals that workload more clearly than a grand aerial diagram. Much of survival happens at the scale of a hand.

**VI:** Một động tác rót ít nước có thể cho thấy khối việc ấy rõ hơn sơ đồ lớn. Nhiều việc sinh tồn diễn ra trong tầm một bàn tay.

**Dựng hình:** P063 [630–635s]; P064 [635–640s]

**Clip tạo P064:** 100mm macro of adult hands carefully pouring a little water from a plain jug into a shallow bowl, warm localized lamp light, slow slider, no modern tap or wasteful splashing.
### 065 | 00:10:40–00:10:50

**EN:** Air can arrive through a connection. Water can be drawn and carried. Food presents a different challenge: enough must already be available when the entrance closes.

**VI:** Không khí đến qua kết nối. Nước được lấy rồi mang đi. Thức ăn đặt ra thách thức khác: phải có đủ sẵn khi lối vào đóng lại.

**Dựng hình:** P065 [640–650s]

**Clip tạo P065:** Historically inspired adult resident sets a water jug beside a covered grain vessel in a dim storeroom, 70mm slow pan between containers, no invented written inventory.
### 066 | 00:10:50–00:11:00

**EN:** Follow the passage toward the storerooms, and the city begins to look less like a hidden monument and more like a plan for managing time.

**VI:** Theo đường tới kho, thành phố bớt giống đài tích bí mật và giống hơn một cách tổ chức để vượt qua thời gian.

**Dựng hình:** P066 [650–660s]

**Clip tạo P066:** 24mm steady forward dolly into a sequence of modest storage chambers with carved recesses and plain large vessels, limited warm illumination, no enormous treasure vault.

## 05 — Lương thực và chuỗi chuẩn bị

### 067 | 00:11:00–00:11:10

**EN:** Stored food connects an uncertain future to work completed earlier. Grain brought below ground carries the effort of fields, harvests, transport, and preparation.

**VI:** Lương thực dự trữ nối tương lai bất định với công việc đã làm trước. Hạt đưa xuống đất mang theo công sức đồng ruộng, thu hoạch, vận chuyển và chuẩn bị.

**Dựng hình:** P067 [660–665s]; P068 [665–670s]

**Clip tạo P067:** Adult hands tip a small amount of dry cereal grain into a plain storage vessel, 85mm close oblique view, restrained dust, illustrative historical reconstruction, no children.
### 068 | 00:11:10–00:11:20

**EN:** That is the importance of a storeroom. It does not create food; it helps preserve and organize something gathered elsewhere, before it is needed.

**VI:** Kho không tạo ra thức ăn. Nó giúp bảo quản và sắp xếp những thứ đã thu từ nơi khác trước lúc cần dùng.

**Dựng hình:** P067 [670–675s]; P068 [675–680s]

**Clip tạo P068:** Reference-informed rock-cut storage chamber with empty niches and a few modest vessels, 35mm slow pullback, realistic ceiling height and simple unpainted surfaces.
### 069 | 00:11:20–00:11:30

**EN:** The preparation must begin before a refuge is crowded. Waiting until danger arrives would leave little time to move everything through the narrow approaches.

**VI:** Chuẩn bị phải bắt đầu trước khi nơi trú đông người. Đợi nguy hiểm tới sẽ để lại ít thời gian chuyển mọi thứ qua các lối vào chật hẹp.

**Dựng hình:** P069 [680–685s]; P070 [685–690s]

**Clip tạo P069:** Historically inspired adult villagers calmly bring small sacks toward an upper-level entrance during ordinary daylight, 50mm medium-wide slow pan, no invasion, running crowd or children.
### 070 | 00:11:30–00:11:40

**EN:** So the underground settlement remains tied to the world outside. Its stores depend on land, weather, labor, and people moving between surface and shelter.

**VI:** Vì vậy, nơi cư trú ngầm vẫn gắn với thế giới bên ngoài. Kho dựa vào đất đai, thời tiết, lao động và người qua lại giữa mặt đất với nơi trú.

**Dựng hình:** P069 [690–695s]; P070 [695–700s]

**Clip tạo P070:** Broad central Anatolian agricultural landscape near a modest settlement, 35mm elevated gentle track toward a village edge, clearly adult distant workers only, no claim of a precisely reconstructed ancient field.
### 071 | 00:11:40–00:11:50

**EN:** How long supplies last depends on how many people use them and at what rate. A room's size alone cannot tell us the duration of a stay.

**VI:** Đồ dự trữ dùng được bao lâu tùy số người và mức dùng. Chỉ kích thước căn phòng không nói được thời gian một lần trú.

**Dựng hình:** P071 [700–710s]

**Clip tạo P071:** Conceptual overhead illustration of a few storage vessels and adult-only occupancy markers, quiet 50mm top-down view, no fabricated exact consumption figures or crowd census.
### 072 | 00:11:50–00:12:00

**EN:** The familiar image of thousands living below ground needs that qualification. Capacity is a practical question about resources, not just a dramatic number attached to a photograph.

**VI:** Hình dung hàng nghìn người sống dưới đất cần được hiểu cùng điều kiện ấy. Sức chứa là câu hỏi về nguồn sống, không chỉ là con số ấn tượng gắn vào ảnh.

**Dựng hình:** P072 [710–720s]

**Clip tạo P072:** Wide 24mm empty Derinkuyu chamber with one adult archaeologist for honest scale, slow sideways reveal, no enormous artificially enlarged hall or thousands of people.
### 073 | 00:12:00–00:12:10

**EN:** Preserving grain also requires suitable conditions. Moisture, temperature, insects, and handling affect what remains edible; a cool underground location does not solve every problem.

**VI:** Giữ hạt cần điều kiện phù hợp. Độ ẩm, nhiệt độ, côn trùng và cách thao tác ảnh hưởng phần còn ăn được; kho dưới đất mát không giải quyết mọi thứ.

**Dựng hình:** P073 [720–725s]; P074 [725–730s]

**Clip tạo P073:** 100mm macro of dry intact cereal grain in a simple bowl beside a rough tuff wall, slow focus pull, natural material detail, no visible infestation presented as site evidence.
### 074 | 00:12:10–00:12:20

**EN:** A container, a dry surface, and a protected corner can matter as much as depth. Storage is a set of choices repeated over time.

**VI:** Vật chứa, bề mặt khô và góc được che có thể quan trọng như độ sâu. Bảo quản là nhiều lựa chọn được lặp lại theo thời gian.

**Dựng hình:** P073 [730–735s]; P074 [735–740s]

**Clip tạo P074:** Adult hands fit a simple lid onto a plain grain vessel in a sheltered storage recess, 85mm static close side view, believable materials, no vacuum seal or modern packaging.
### 075 | 00:12:20–00:12:30

**EN:** The rock's thermal behavior can help moderate the environment. But people still need to observe the food, manage supplies, and notice when conditions change.

**VI:** Đặc tính nhiệt của đá có thể giúp điều hòa môi trường. Nhưng con người vẫn phải xem lương thực, quản lý dự trữ và nhận biết khi điều kiện đổi.

**Dựng hình:** P075 [740–745s]; P076 [745–750s]

**Clip tạo P075:** Clearly adult storekeeper in a historical illustration inspects a handful of grain near a small lamp, 70mm medium close shot, no invented date inscription or display.
### 076 | 00:12:30–00:12:40

**EN:** Official descriptions include wine-making spaces as well as stores. Such features remind us that the city held different activities, not one identical room repeated endlessly.

**VI:** Mô tả chính thức còn có chỗ làm rượu bên cạnh kho. Chúng nhắc rằng thành phố chứa nhiều hoạt động, không phải một kiểu phòng lặp vô tận.

**Dựng hình:** P075 [750–755s]; P076 [755–760s]

**Clip tạo P076:** Reference-informed rock-cut pressing area with shallow carved basin and collection channel, 35mm slow oblique dolly, empty present-day space, no invented industrial equipment.
### 077 | 00:12:40–00:12:50

**EN:** A carved basin or a channel points toward a process. Understanding its function means asking what entered, what moved through it, and what was collected afterward.

**VI:** Lòng bể hay rãnh đục gợi một quá trình. Muốn hiểu chức năng, cần hỏi thứ gì được đưa vào, chảy qua và được thu lại sau đó.

**Dựng hình:** P077 [760–770s]

**Clip tạo P077:** 85mm close tracking along a shallow rock-cut channel toward a receiving depression, restrained practical light, no red blood-like liquid or unverifiable operating reenactment.
### 078 | 00:12:50–00:13:00

**EN:** The same approach works throughout Derinkuyu. Read each feature as part of an activity, and the empty rooms begin to recover some of their human meaning.

**VI:** Cách nhìn ấy có ích khắp Derinkuyu. Đọc mỗi chi tiết như một phần công việc, các phòng trống dần lấy lại ý nghĩa con người.

**Dựng hình:** P078 [770–780s]

**Clip tạo P078:** Adult researcher compares a modest carved recess with a closed paper field sketch, 50mm observational slow pan, no generated legible writing or claim of a new discovery.
### 079 | 00:13:00–00:13:10

**EN:** Animals brought another set of needs. Stables appear among the listed facilities, often associated with the upper spaces where access from outside was more practical.

**VI:** Động vật mang thêm nhu cầu. Chuồng có trong danh sách tiện ích, thường gắn với không gian phía trên, nơi đi từ ngoài vào thuận tiện hơn.

**Dựng hình:** P079 [780–785s]; P080 [785–790s]

**Clip tạo P079:** Conservative historical illustration of an upper rock-cut stable with one adult donkey and a clearly adult attendant, 35mm slow side move, broad enough access, no animal deep in a narrow shaft.
### 080 | 00:13:10–00:13:20

**EN:** Keeping animals nearby could preserve useful resources, but it also meant feed, water, waste, and space. An additional inhabitant always changes the demands on a refuge.

**VI:** Giữ động vật gần có thể bảo toàn nguồn lực hữu ích, nhưng còn cần thức ăn, nước, xử lý thải và chỗ ở. Thêm một sinh vật là thêm nhu cầu.

**Dựng hình:** P079 [790–795s]; P080 [795–800s]

**Clip tạo P080:** Close 85mm view of a simple upper-level manger and water vessel beside an adult donkey's shoulder, slow lateral slider, restrained realistic space, no graphic waste.
### 081 | 00:13:20–00:13:30

**EN:** Even the light needed supplies. Fuel, containers, tools, and repairs link the underground rooms to a chain of preparation that extends far beyond the doorway.

**VI:** Ngay ánh sáng cũng cần tiếp tế. Nhiên liệu, vật chứa, công cụ và sửa chữa nối các phòng ngầm với chuỗi chuẩn bị vượt xa cửa vào.

**Dựng hình:** P081 [800–810s]

**Clip tạo P081:** Macro-to-medium 70mm view of an adult arranging a small oil container, simple tools and a lamp on a low work surface, localized warm light, plausible period-neutral objects.
### 082 | 00:13:30–00:13:40

**EN:** The city could protect stored resources and the people using them. It did not turn the settlement into a world with no need for the surface.

**VI:** Thành phố có thể che chở đồ dự trữ cùng người sử dụng. Nó không biến nơi cư trú thành thế giới chẳng cần mặt đất.

**Dựng hình:** P082 [810–820s]

**Clip tạo P082:** Conceptual cutaway linking an underground storeroom to a modest surface entrance and surrounding fields, 35mm slow pullback, no invisible modern conveyor or self-sufficient futuristic ecosystem.

## 06 — Con người và phối hợp

### 083 | 00:13:40–00:13:50

**EN:** A settlement also needs people to work together. Rooms and routes only become useful when someone knows where supplies belong and what must happen next.

**VI:** Nơi cư trú còn cần con người phối hợp. Phòng và đường chỉ hữu ích khi có người biết đồ đặt đâu và việc gì phải làm tiếp.

**Dựng hình:** P083 [820–825s]; P084 [825–830s]

**Clip tạo P083:** Illustrative historical communal chamber with four clearly adult residents quietly arranging vessels and baskets, 35mm eye-level slow lateral dolly, modest domestic scale, no children or lavish palace furniture.
### 084 | 00:13:50–00:14:00

**EN:** The labor can be ordinary: carrying a vessel, mending a bag, preparing a meal. Repeated tasks keep a community going while grand structures remain still.

**VI:** Công việc có thể bình thường: mang bình, vá túi, chuẩn bị bữa ăn. Việc lặp lại giữ cộng đồng hoạt động trong khi những cấu trúc lớn đứng yên.

**Dựng hình:** P083 [830–835s]; P084 [835–840s]

**Clip tạo P084:** Clearly adult resident repairs a coarse cloth storage bag beside a small lamp, 85mm hand-focused side shot, period-neutral tools and clothing, no copied prehistoric needle scene.
### 085 | 00:14:00–00:14:10

**EN:** Sharing a limited store means deciding how it is used. We cannot recover every ancient decision, but the need to coordinate is built into the arrangement.

**VI:** Chung kho dự trữ có hạn nghĩa là phải quyết định cách dùng. Ta không biết mọi quyết định xưa, nhưng bố trí này tự nó đòi hỏi phối hợp.

**Dựng hình:** P085 [840–845s]; P086 [845–850s]

**Clip tạo P085:** Illustrative adult residents share a modest measure of grain beside covered storage jars, 70mm medium-close slow pan, calm exchange, no invented ancient written ration system.
### 086 | 00:14:10–00:14:20

**EN:** A small group makes this visible without pretending to count the whole population. Someone brings a container; someone receives it; a space has to remain clear.

**VI:** Một nhóm nhỏ cho thấy việc ấy mà không giả vờ đếm được toàn dân số. Người mang bình tới, người nhận, và vẫn phải chừa lối đi.

**Dựng hình:** P085 [850–855s]; P086 [855–860s]

**Clip tạo P086:** Three clearly adult historical figures pass one plain ceramic container at the side of a narrow corridor, 50mm fixed observational view, passage remains open, no crowd or children.
### 087 | 00:14:20–00:14:30

**EN:** Inside, light would divide the room into useful zones. An activity close to a lamp could continue while the surrounding space remained difficult to see.

**VI:** Bên trong, ánh sáng chia phòng thành các vùng sử dụng. Công việc gần đèn có thể tiếp tục trong khi phần xung quanh khó nhìn rõ.

**Dựng hình:** P087 [860–870s]

**Clip tạo P087:** 35mm wide historical room with one lit work area and genuinely shadowed margins, adult worker seated near a small lamp, slow gentle dolly, no evenly flooded studio lighting.
### 088 | 00:14:30–00:14:40

**EN:** The room's emptiness today can hide those choices. A niche, a doorway, and the position of a small light may once have organized many familiar movements.

**VI:** Phòng trống hôm nay có thể che những lựa chọn ấy. Hốc tường, cửa đi và vị trí ngọn đèn nhỏ từng tổ chức nhiều động tác quen thuộc.

**Dựng hình:** P088 [870–880s]

**Clip tạo P088:** 85mm close-to-medium focus pull between a plain carved niche, a lamp-sized recess and a doorway, empty present-day chamber, subdued practical lighting, no reenactment figures.
### 089 | 00:14:40–00:14:50

**EN:** Derinkuyu also includes Christian religious spaces. A chapel or gathering room adds another part of life that cannot be reduced to calories, water, and air alone.

**VI:** Derinkuyu còn có không gian tôn giáo Kitô giáo. Nhà nguyện hay chỗ tập hợp thêm một phần đời sống không thể chỉ quy về calo, nước và không khí.

**Dựng hình:** P089 [880–890s]

**Clip tạo P089:** Reference-informed undecorated rock-cut chapel space at Derinkuyu with simple geometric cross-plan character, 24mm slow centered dolly, no child depictions, figurative frescoes or invented elaborate altar.
### 090 | 00:14:50–00:15:00

**EN:** These spaces help connect the site to its historical communities. They do not, by themselves, tell us when every corridor was first cut into the rock.

**VI:** Những không gian ấy nối di tích với cộng đồng trong lịch sử. Nhưng riêng chúng không cho biết thời điểm từng đường hầm được đào lần đầu.

**Dựng hình:** P090 [890–900s]

**Clip tạo P090:** 85mm close view of a simple carved architectural junction within an empty chapel, slow lateral slide emphasizing cut surfaces, no readable dates or invented religious portraits.
### 091 | 00:15:00–00:15:10

**EN:** A community needs shared practices as well as shared resources. The meaning of a room can include memory, belief, authority, and the habit of gathering.

**VI:** Cộng đồng cần tập quán chung bên cạnh nguồn lực chung. Ý nghĩa căn phòng có thể gồm ký ức, niềm tin, quyền điều hành và thói quen tập hợp.

**Dựng hình:** P091 [900–910s]

**Clip tạo P091:** Illustrative Byzantine-period gathering of four clearly adult residents in a modest plain rock-cut room, 50mm eye-level observational pan, respectful neutral portrayal, no sermon audio or child imagery.
### 092 | 00:15:10–00:15:20

**EN:** A shared room could bring people together around familiar tasks. The surviving space suggests possibilities, even where the exact routines and personal stories remain unknown.

**VI:** Phòng chung có thể đưa con người lại gần quanh việc quen thuộc. Không gian còn lại gợi khả năng, dù chưa biết chính xác nếp sinh hoạt và chuyện từng người.

**Dựng hình:** P092 [910–920s]

**Clip tạo P092:** Clearly adult hands arrange a few plain containers before a quiet communal meal, 85mm close low shot, period-neutral simple objects, no legible invented personal documents.
### 093 | 00:15:20–00:15:30

**EN:** The question of population returns here. A famous capacity estimate is not a census, and the usable number would depend on conditions and available supplies.

**VI:** Câu hỏi số người trở lại ở đây. Ước tính sức chứa nổi tiếng không phải thống kê dân số; số dùng được tùy điều kiện và nguồn dự trữ.

**Dựng hình:** P093 [920–925s]; P094 [925–930s]

**Clip tạo P093:** 24mm wide modest chamber with a few adult scale figures and ample empty space, slow measured pullback, no thousands of occupants or fabricated crowd count.
### 094 | 00:15:30–00:15:40

**EN:** Air, water, food, space, and the length of a stay set different limits. The practical question is how those limits fit together, rather than which number sounds largest.

**VI:** Không khí, nước, thức ăn, không gian và thời gian trú đặt giới hạn khác nhau. Câu hỏi thực tế là chúng khớp nhau ra sao, thay vì con số nào lớn nhất.

**Dựng hình:** P093 [930–935s]; P094 [935–940s]

**Clip tạo P094:** Conceptual systems illustration connects an air shaft, a water vessel, a grain jar and a chamber using restrained lines, 50mm slow oblique view, no numerical capacity claim or magical iconography.
### 095 | 00:15:40–00:15:50

**EN:** A route that works for a few people can become a bottleneck for many. The same physical design carries both its advantages and its constraints.

**VI:** Lối đi phù hợp cho ít người có thể thành nút nghẽn khi đông hơn. Cùng một thiết kế vật lý chứa cả ưu điểm lẫn hạn chế.

**Dựng hình:** P095 [940–950s]

**Clip tạo P095:** Illustrative adult-only small group pauses in a chamber while one adult passes through a narrow doorway, 50mm static side view, orderly realistic movement, no dangerous crush.
### 096 | 00:15:50–00:16:00

**EN:** That is what makes the city interesting as engineering. It balances competing demands using the shape of the rock, rather than escaping every natural limit.

**VI:** Đó là điều khiến thành phố đáng chú ý về kỹ thuật. Nó cân bằng các yêu cầu cạnh tranh qua hình dạng đá, thay vì thoát khỏi mọi giới hạn tự nhiên.

**Dựng hình:** P096 [950–960s]

**Clip tạo P096:** Scientific 3D section of a thick retained pillar between modest rooms, adjacent shaft and controlled passage, 35mm slow orbit, plausible rock thickness, no impossible thin supports.
### 097 | 00:16:00–00:16:10

**EN:** The people moving through it also carried knowledge: which turn to take, where something was stored, and when a task needed another person's help.

**VI:** Người đi trong đó còn mang theo hiểu biết: rẽ hướng nào, đồ cất ở đâu và việc nào cần người khác giúp.

**Dựng hình:** P097 [960–970s]

**Clip tạo P097:** Clearly adult experienced resident gestures quietly toward a passage while another adult carries a small basket, 70mm medium view, illustrative historical clothing, no dialogue or pointing at fake text.
### 098 | 00:16:10–00:16:20

**EN:** Knowledge is easy to leave out of a diagram. Yet it may be the difference between connected chambers and a place a community can actually use.

**VI:** Hiểu biết dễ bị bỏ khỏi sơ đồ. Nhưng chính nó có thể tạo khác biệt giữa những phòng liên thông với nơi cộng đồng thật sự dùng được.

**Dựng hình:** P098 [970–980s]

**Clip tạo P098:** 24mm slow forward move follows a clearly adult guide through a sequence of rock-cut doorways toward a softly lit chamber, no route labels generated in frame.

## 07 — Lịch sử, bằng chứng và bảo tồn

### 099 | 00:16:20–00:16:30

**EN:** The walls preserve traces of excavation, but a chisel mark is not a calendar. Dating a space requires more evidence than a dramatic photograph can provide.

**VI:** Tường giữ dấu đào khoét, nhưng vết đục không phải lịch. Định tuổi không gian cần nhiều bằng chứng hơn một tấm ảnh ấn tượng.

**Dựng hình:** P099 [980–985s]; P100 [985–990s]

**Clip tạo P099:** 100mm macro of overlapping hand-tool marks on tuff, slow focus pull across shallow grooves, neutral inspection light, no fabricated inscription or highlighted modern date.
### 100 | 00:16:30–00:16:40

**EN:** Researchers compare architecture, historical context, and material evidence. An impressive early date repeated online does not become certain simply because many pages share it.

**VI:** Nhà nghiên cứu đối chiếu kiến trúc, bối cảnh lịch sử và vật chứng. Niên đại sớm gây ấn tượng được lặp trên mạng không tự trở nên chắc chắn.

**Dựng hình:** P099 [990–995s]; P100 [995–1000s]

**Clip tạo P100:** Adult archaeological researcher compares reference photos and measured sketches on a plain desk, 50mm overhead slow slide, no readable invented archaeological report or false dating result.
### 101 | 00:16:40–00:16:50

**EN:** Different accounts assign Derinkuyu's beginnings to different periods. What we see is better approached as a place altered and extended through a long history of use.

**VI:** Các mô tả đặt khởi đầu Derinkuyu vào những thời kỳ khác nhau. Nên tiếp cận di tích còn thấy như nơi đã được sửa đổi, mở rộng qua lịch sử sử dụng lâu dài.

**Dựng hình:** P101 [1000–1010s]

**Clip tạo P101:** Conceptual sequence of modest chamber extensions revealed within a rock block, 35mm side-on slow camera move, no fixed founding year, no claim that colors identify proven chronological phases.
### 102 | 00:16:50–00:17:00

**EN:** A later room can connect to an older passage. Similar-looking surfaces need not have been cut together, and one useful feature may have served changing purposes.

**VI:** Phòng làm sau có thể nối đường cũ. Bề mặt giống nhau chưa chắc được đục cùng lúc; một chi tiết hữu ích có thể thay chức năng theo thời gian.

**Dựng hình:** P102 [1010–1020s]

**Clip tạo P102:** Present-day junction of differently shaped rock-cut passages, 70mm slow pan from one opening to another, natural tool textures, no invented color-coded age labels.
### 103 | 00:17:00–00:17:10

**EN:** UNESCO places the underground towns within Cappadocia's wider history of rock-cut settlement and Byzantine refuge. Derinkuyu belongs to that inhabited regional landscape, not a story outside human history.

**VI:** UNESCO đặt các thị trấn ngầm trong lịch sử cư trú và trú ẩn thời Byzantine ở Cappadocia. Derinkuyu thuộc cảnh quan con người ấy, không nằm ngoài lịch sử.

**Dựng hình:** P103 [1020–1030s]

**Clip tạo P103:** Accurate reference-based regional Cappadocia map with separate points for Derinkuyu and nearby rock-cut settlements, restrained overhead move, labels left for editor, no invented connecting tunnel.
### 104 | 00:17:10–00:17:20

**EN:** The region also contains churches, dwellings, villages, and other underground sites. Comparing them helps reveal possibilities and differences, rather than a single design copied without change.

**VI:** Vùng này còn có nhà thờ, chỗ ở, làng và di tích ngầm khác. So sánh giúp nhận ra khả năng cùng khác biệt, không phải một mẫu được sao chép nguyên vẹn.

**Dựng hình:** P104 [1030–1040s]

**Clip tạo P104:** Wide 35mm present-day Cappadocian rock-cut exterior architecture without figurative religious imagery, slow lateral track, keep distinct from Derinkuyu underground footage, adults only if any distant visitors.
### 105 | 00:17:20–00:17:30

**EN:** Modern accounts commonly place Derinkuyu's rediscovery in 1963. The familiar story of a household opening into a hidden passage should not substitute for the city's much longer history.

**VI:** Các mô tả hiện đại thường đặt việc phát hiện lại Derinkuyu vào năm 1963. Chuyện gia đình mở vào đường ngầm không nên thay thế lịch sử dài hơn nhiều của thành phố.

**Dựng hình:** P105 [1040–1045s]; P106 [1045–1050s]

**Clip tạo P105:** Restrained illustrative 1960s Anatolian domestic cellar with a small dark opening in a wall, 50mm fixed eye-level view, no demolition, named discoverer, child or asserted exact original house.
### 106 | 00:17:30–00:17:40

**EN:** Finding an entrance and understanding a settlement are different achievements. The second requires mapping, documentation, and the patient study of what the spaces actually contain.

**VI:** Tìm ra lối vào và hiểu một khu cư trú là hai việc khác nhau. Việc thứ hai cần bản đồ, ghi chép và kiên nhẫn nghiên cứu những gì không gian thật sự chứa.

**Dựng hình:** P105 [1050–1055s]; P106 [1055–1060s]

**Clip tạo P106:** Present-day clearly adult survey team uses a compact measuring instrument from an established underground route, 50mm medium-wide slow pan, no readable fabricated measurements.
### 107 | 00:17:40–00:17:50

**EN:** A measured plan helps compare routes, room shapes, and connections. It turns an impressive view into information that can be checked against the actual rock.

**VI:** Bản vẽ đo đạc giúp đối chiếu đường đi, hình phòng và kết nối. Nó biến cảnh tượng ấn tượng thành thông tin có thể kiểm tra trên nền đá thật.

**Dựng hình:** P107 [1060–1070s]

**Clip tạo P107:** Conceptual 3D cutaway gently resolves into a simple unlabeled model on an adult researcher's desk, 50mm slow pullback, clearly a visualization, no claim of a newly discovered site survey.
### 108 | 00:17:50–00:18:00

**EN:** A doorway preserves its physical form more clearly than the gestures of the people who used it. Understanding the place means recognizing both kinds of evidence.

**VI:** Cửa giữ hình dạng vật lý rõ hơn động tác của những người từng sử dụng. Hiểu di tích nghĩa là nhận biết khác biệt giữa điều còn thấy với phần phải suy luận.

**Dựng hình:** P108 [1070–1080s]

**Clip tạo P108:** Reference-informed empty stone-door recess viewed with a 70mm slow side slider, no historical people, emphasize surviving physical form under modest present-day lighting.
### 109 | 00:18:00–00:18:10

**EN:** Other underground towns, including Kaymakli, belong in the regional comparison. Their existence does not mean that every room and route forms one fully demonstrated shared network.

**VI:** Những thị trấn ngầm khác, gồm Kaymakli, có ích cho so sánh vùng. Sự tồn tại của chúng không có nghĩa mọi phòng và đường hợp thành một mạng chung đã được chứng minh.

**Dựng hình:** P109 [1080–1090s]

**Clip tạo P109:** Accurate central Cappadocia location diagram with two separate unlabelled site markers, 50mm orthographic slow zoom, no continuous underground line between settlements, labels added only in editing.
### 110 | 00:18:10–00:18:20

**EN:** A map can show where places stand. Establishing a physical connection requires additional evidence, and similar architecture alone cannot provide the missing passage.

**VI:** Bản đồ cho thấy các nơi nằm đâu. Xác lập kết nối vật lý cần bằng chứng khác; kiến trúc tương tự không tự cung cấp đường hầm còn thiếu.

**Dựng hình:** P110 [1090–1100s]

**Clip tạo P110:** Adult researcher places two separate architectural reference drawings side by side on a table, 70mm overhead static shot, no generated legible text or drawn connecting tunnel.
### 111 | 00:18:20–00:18:30

**EN:** The visitor route is also a selection, not an experience of every known space. What feels like an entire city may be only the part arranged for access.

**VI:** Tuyến tham quan cũng là phần được chọn, không phải toàn bộ không gian đã biết. Điều tạo cảm giác cả thành phố có thể chỉ là phần được bố trí tiếp cận.

**Dựng hình:** P111 [1100–1110s]

**Clip tạo P111:** Present-day protected visitor passage ending at a simple barrier before a dark side opening, 35mm slow cautious approach stays on open route, no entering restricted areas.
### 112 | 00:18:30–00:18:40

**EN:** Conservation involves watching the rock as well as guiding people. Research has examined the site's long-term stability and monitored the behavior of the surrounding material.

**VI:** Bảo tồn gồm quan sát đá bên cạnh hướng dẫn khách. Nghiên cứu đã xem xét độ bền lâu dài của di tích và theo dõi ứng xử vật liệu bao quanh.

**Dựng hình:** P112 [1110–1120s]

**Clip tạo P112:** Adult rock-mechanics researcher checks a small nonintrusive monitoring point near a chamber wall, 85mm medium close observational view, no fabricated warning screen or imminent collapse.
### 113 | 00:18:40–00:18:50

**EN:** The worn surfaces invite attention, but every visitor adds movement, contact, and changing conditions. Understanding the site includes recognizing the work needed to care for it.

**VI:** Bề mặt mòn gợi nhiều điều, nhưng mỗi khách thêm chuyển động, tiếp xúc và đổi điều kiện. Hiểu di tích còn là nhận ra công chăm sóc nó.

**Dựng hình:** P113 [1120–1130s]

**Clip tạo P113:** Clearly adult guide gestures from a permitted route without touching the historic wall, 70mm medium view, natural clothing, slow pan along empty chamber edge, no children.
### 114 | 00:18:50–00:19:00

**EN:** This brings us back to the practical city beneath the monument. The same rooms that inspire wonder also ask ordinary questions about air, water, routes, and maintenance.

**VI:** Điều ấy đưa ta về thành phố thực tế phía sau di tích. Cùng những căn phòng gây kinh ngạc vẫn đặt câu hỏi thường ngày về khí, nước, lối đi và bảo trì.

**Dựng hình:** P114 [1130–1140s]

**Clip tạo P114:** 24mm slow pullback through a modest chamber showing a doorway, a small shaft opening and storage recess in one plausible composition, restrained naturalistic lighting.

## 08 — Quay lại cánh cửa

### 115 | 00:19:00–00:19:10

**EN:** Return to the round stone door. It is easy to remember because its shape is clear and its purpose feels immediate: keep danger outside.

**VI:** Hãy trở lại cửa đá tròn. Nó dễ nhớ vì hình dạng rõ ràng và công dụng có vẻ trực tiếp: giữ nguy hiểm bên ngoài.

**Dựng hình:** P115 [1140–1150s]

**Clip tạo P115:** Return to the same reference-informed stone door used in opening, 35mm low slow approach, consistent slab shape and recess, no attack reenactment, warm subdued light.
### 116 | 00:19:10–00:19:20

**EN:** Yet the door cannot provide a drink, preserve a harvest, or replace the air in a room. Its value depends on everything working around it.

**VI:** Nhưng cửa không cung cấp nước, giữ vụ mùa hay thay không khí trong phòng. Giá trị của nó phụ thuộc mọi thứ hoạt động quanh mình.

**Dựng hình:** P116 [1150–1160s]

**Clip tạo P116:** 35mm slow lateral move from the door toward plain water and grain vessels placed clear of a passage, illustrative reconstruction without people, no magical resource effects.
### 117 | 00:19:20–00:19:30

**EN:** The city's achievement is therefore a relationship between parts. A heavy barrier, a narrow route, a deep well, and a small opening each answer a different need.

**VI:** Thành tựu của thành phố nằm ở quan hệ giữa các phần. Rào nặng, lối hẹp, giếng sâu và lỗ mở nhỏ đáp ứng những nhu cầu khác nhau.

**Dựng hình:** P117 [1160–1170s]

**Clip tạo P117:** Conceptual systems cutaway brings doorway, shaft, well and storeroom into one simplified view, 35mm slow orbit, physically plausible thick rock, no exact cadastral-plan claim.
### 118 | 00:19:30–00:19:40

**EN:** None is sufficient alone. The engineering becomes convincing when the pieces support one another and when people know how to use the arrangement.

**VI:** Không phần nào tự nó đủ. Kỹ thuật trở nên thuyết phục khi các phần hỗ trợ nhau và con người biết sử dụng bố trí ấy.

**Dựng hình:** P118 [1170–1180s]

**Clip tạo P118:** Clearly adult historical residents quietly coordinate carrying a water vessel past a storeroom toward a communal space, 50mm observational slow track, small group, no children.
### 119 | 00:19:40–00:19:50

**EN:** Seen this way, Derinkuyu is more than a surprising place to hide. It is a reminder that protection and everyday life have to be designed together.

**VI:** Nhìn như vậy, Derinkuyu hơn một nơi trú lạ thường. Nó nhắc rằng sự che chở và đời sống thường ngày phải được tính cùng nhau.

**Dựng hình:** P119 [1180–1190s]

**Clip tạo P119:** Wide 24mm underground chamber illuminated by a small local lamp and faint shaft daylight, slow measured pullback, believable empty spaces and retained pillars, no monumental fantasy scale.
### 120 | 00:19:50–00:20:00

**EN:** As we climb toward daylight, the surface returns in fragments: a brighter step, a doorway, a patch of sky. The connection was there throughout the journey.

**VI:** Khi lên về ánh sáng, mặt đất trở lại từng mảnh: bậc thang sáng hơn, ô cửa, một mảnh trời. Kết nối ấy vẫn có trong suốt hành trình.

**Dựng hình:** P120 [1190–1200s]

**Clip tạo P120:** 24mm slow forward climb along an authorized ascending tuff stair toward daylight, stable adult eye-level camera, gradual realistic exposure change, no impossible vertical drone flight through rock.
### 121 | 00:20:00–00:20:10

**EN:** Above ground, the town continues around the entrance. The ordinary world is not an interruption of the story; it is part of the city's explanation.

**VI:** Trên mặt đất, thị trấn tiếp tục quanh lối vào. Thế giới bình thường không làm gián đoạn câu chuyện; nó là một phần lời giải của thành phố.

**Dựng hình:** P121 [1200–1210s]

**Clip tạo P121:** Present-day Derinkuyu street near the visitor entrance in gentle late-afternoon light, 35mm quiet lateral move, modest buildings, clearly adult distant pedestrians only, no children in signs or posters.
### 122 | 00:20:10–00:20:20

**EN:** The rooms below needed what this world could supply. Their separation offered shelter, while their connections made that shelter possible to use for a meaningful length of time.

**VI:** Các phòng phía dưới cần những gì thế giới này cung cấp. Tách biệt cho nơi trú, còn kết nối giúp nơi trú được sử dụng trong một khoảng thời gian có ý nghĩa.

**Dựng hình:** P122 [1210–1220s]

**Clip tạo P122:** 35mm high oblique view of a modest surface entrance and surrounding ordinary settlement, slow rise only a little above roofs, no fabricated exposed underground rooms beneath actual buildings.
### 123 | 00:20:20–00:20:30

**EN:** The largest stone catches our eye. The smaller openings explain much of what we missed: a protected place must still exchange something with the world.

**VI:** Tảng đá lớn nhất hút mắt. Những lỗ nhỏ giải thích điều ta bỏ lỡ: nơi được che chở vẫn phải trao đổi với thế giới.

**Dựng hình:** P123 [1220–1230s]

**Clip tạo P123:** Reference-informed ventilation opening with a narrow shaft of daylight on textured tuff, 85mm slow focus pull from rock edge toward sky, no person at unsafe edge.
### 124 | 00:20:30–00:20:40

**EN:** Derinkuyu worked through that balance. The door could close against danger, while the city kept reaching upward for the things that made life continue.

**VI:** Derinkuyu hoạt động nhờ sự cân bằng ấy. Cửa có thể đóng trước hiểm nguy, trong khi thành phố vẫn vươn lên tìm những thứ giúp đời sống tiếp diễn.

**Dựng hình:** P124 [1230–1240s]

**Clip tạo P124:** 35mm restrained upward tilt from an empty underground chamber toward its modest daylight connection, preserve realistic scale and mixed warm-cool light, thoughtful closing composition.
### 125 | 00:20:40–00:20:42

**EN:** [No narration — silent closing hold]

**VI:** [Không đọc — giữ hình kết]

**Dựng hình:** P125 [1240–1242s]

**Clip tạo P125:** Quiet continuation at the surface beside a modest Derinkuyu ventilation opening under soft late-afternoon sky, 50mm nearly static camera, gentle light change suitable for a two-second fade after trimming.
