﻿# Bộ sản xuất Derinkuyu — chủ đề 72 — 20:42

Bộ này gồm kịch bản gốc tiếng Anh, bản Việt và 15 bản ngôn ngữ còn lại; 125 prompt tạo video; timeline dựng; phân tích nguồn; tài liệu kiểm chứng; 5 tiêu đề và 5 prompt thumbnail. Âm thanh được giao thành 17 MP3 riêng, có thể đặt lên cùng một timeline dài 20:42.

## Dùng các tệp

1. Đọc `PHAN_TICH_VIDEO_NGUON_VA_CACH_DUNG.md` để nắm cấu trúc kể và cách dựng theo video người dùng cung cấp. Đọc `NGHIEN_CUU_DERINKUYU_VA_NGUON.md` trước khi thêm số liệu hoặc hình bản đồ.
2. `KICH_BAN_EN_VI_20m42s.md` là kịch bản song ngữ có mốc thời gian. Thư mục `kich_ban_17_ngon_ngu` chứa văn bản từng ngôn ngữ để xem, chỉnh hoặc tái tạo voice.
3. Gửi prompt trong `prompts_10_moi_txt` theo thứ tự 001–125 vào công cụ video. Có 13 TXT: 12 file × 10 prompt và file cuối 5 prompt. `TAT_CA_125_PROMPT.txt` là bản gộp. Mỗi prompt yêu cầu một clip 10 giây, không âm thanh, không lời nói và không hình trẻ em. Đặt tên clip trả về `CLIP_001.mp4`…`CLIP_125.mp4`.
   Để giữ hình cửa nhất quán, sau khi tạo clip001 hãy chọn một khung hình rõ cửa, không có hình trẻ em, làm ảnh tham chiếu cho các clip23–28 và115 nếu công cụ hỗ trợ image-to-video/reference. Dùng cùng bảng màu và chất liệu đá cho toàn bộ nhóm; chỉ lời yêu cầu bằng văn bản không bảo đảm các lần sinh cho ra cùng một đạo cụ.

4. Tạo timeline 24 fps, 16:9. Đặt hình theo `EDIT_DECISIONS.csv`, gồm 185 đoạn dựng; nhiều clip được chia hai đoạn 5 giây và xen trong cặp 20 giây. File CSV ghi chính xác điểm vào/ra. 124 clip đầu dùng đủ 10 giây; clip125 dùng 0–2 giây. Fade kết nằm trong hai giây cuối, không kéo dài phim. Tổng 1.242 giây = 20:42.
5. Đặt MP3 tiếng Anh làm bản chính, bắt đầu tại 00:00. Dùng `TIMELINE_VOICE_PROMPT.csv` để đối chiếu lời và những clip đang hiển thị. Có 20:40 lời kể, sau đó 2 giây kết không lời.
6. Khi xuất bản ngôn ngữ khác, thay track EN bằng MP3 của ngôn ngữ đó tại cùng vị trí 00:00. Bản khác được căn theo khối 100 giây, khối cuối 40 giây; tổng cùng 20:42. Nội dung trong một khối giữ cùng thứ tự, nhưng từng từ/câu không khớp tuyệt đối với từng cú cắt. Nếu cần khớp chi tiết theo từ, tinh chỉnh các cú cắt trong cùng khối khi nghe bản tương ứng.
7. `voice_timing_inputs/*_VOICE_BLOCKS.srt` dùng làm đầu vào theo khối cho công cụ voice, không phải phụ đề hiển thị cuối. Ngoại ngữ có khối SRT dài100 giây; không nên đưa nguyên khối lên màn hình. Muốn phụ đề xem phim, cần căn câu/từ theo âm thanh hoàn chỉnh và giới hạn độ dài dòng.
8. `TEXT_OVERLAYS_EN.csv` là gợi ý chữ chèn khi dựng, không yêu cầu mô hình video tự viết chữ. `5_TIEU_DE_5_PROMPT_THUMBNAIL.txt` có5 cặp tiêu đề–prompt tương ứng; đề xuất dùng số1.

## Giọng đọc và tính liên tục

Có16 giọng nam và 1 giọng H’Mông Trắng nữ. Tiếng Việt giữ đúng **vi-VN-NamMinhNeural**; tiếng Anh **en-US-AndrewNeural**. Các nước còn lại giữ chính các voice ID đã chọn ở bộ trước. Bồ Đào Nha dùng pt-PT, Tây Ban Nha dùng es-ES, Na Uy dùng Bokmål nb-NO. H’Mông dùng Hmong Dawb, mẫu nữ `hmong-female-3`.

`profiles/VOICE_PROFILES_LOCKED.json` lưu lựa chọn, locale, giới tính, engine, revision mã nguồn, cách căn thời gian và SHA-256 của MP3 đã giao. `profiles/DANH_SACH_GIONG.csv` giúp đọc nhanh; `voice_reports/*.json` ghi thời lượng thực, hệ số tempo theo khối và phép đo âm thanh. Lần sau tái sử dụng exact voice ID và mẫu H’Mông, không tự đổi sang tên khác nếu dịch vụ thiếu giọng. Voice trực tuyến có thể được nhà cung cấp cập nhật; tệp đã giao và SHA-256 giữ nguyên bản nghe hiện tại.

Dùng mã nguồn trong [Melo + Việt Studio1.3.1](https://github.com/seotro95/seotro/releases/tag/melo-viet-studio-1.3.1-txt-srt-41595029816), revision `4f4fa1d72d976d6e2b9c94f906b0e12c6a2cf043`, nhánh online_backend/Microsoft Edge cho 16 giọng nam. Đây là backend trực tuyến của công cụ, không phải mô hình Melo offline.

Dùng [Voice Studio Hmong1.6.6](https://github.com/seotro95/seotro/releases/tag/voice-studio-hmong-1.6.6), revision `061430d958b8d5fc14d04209c6f0cd20492382c2`, Native VITS + OpenVoice V2, `clear-v1`, mẫu `hmong-female-3`. SHA-256 của âm thanh tham chiếu nữ: `ffa26422055a9da069ba8d7a9d780405b6504c27ce70fa5ad3ffed84f5b2dc17`.

Môi trường chạy là Linux nên gọi phần Python của cùng mã nguồn, không chạy giao diện/BAT Windows. Danh mục Edge hiện dùng DisplayName; lớp tương thích bổ sung FriendlyName cho kiểm tra danh mục cũ. Không đổi voice ID để xử lý thay đổi tên trường.

## Cách bảo đảm độ dài

Giữ thứ tự nội dung, loại khoảng lặng ở rìa từng đoạn, căn bằng tempo giữ cao độ và thêm đuôi im ngắn. Không cắt bỏ lời để ép thời lượng. Tiếng Anh căn124 đoạn10 giây; ngôn ngữ khác căn12×100 giây+40 giây; tất cả thêm2 giây kết không lời. MP3 đầu ra mono,48kHz,192kbps. Độ dài kiểm bằng số mẫu PCM sau khi giải mã, không chỉ đọc con số thời lượng của container MP3. Mỗi voice có59.616.000 mẫu tại 48.000 Hz =1.242 giây. Một số phần mềm hiện độ dài MP3 hơi dư vì header/encoder delay; kiểm sau giải mã hoặc đặt điểm kết timeline20:42.

Một hệ số gain cố định theo đo loudness/truepeak giữ giọng ổn định và tránh clipping; không thêm nhạc nền hay hiệu ứng vào MP3. Nếu thêm nhạc khi dựng, cân mức để không che lời và dùng bản có quyền sử dụng phù hợp.

## Tình trạng biên tập và điều cần kiểm khi dựng

Lời Anh viết mới; lời Việt biên soạn trực tiếp.14 ngôn ngữ khác sử dụng dịch máy có sửa các câu dễ sai, tên riêng và cách diễn đạt chọn lọc. Bản H’Mông Trắng được biên soạn lại thủ công theo nội dung từng cảnh và kiểm tra bằng bộ xác thực văn bản của công cụ. Chưa có kiểm nghe độc lập bởi người bản ngữ cho toàn bộ 17 track; không coi bản dịch/giọng H’Mông là đã được thẩm định phát âm hoàn chỉnh. Văn bản và báo cáo được giao để thuận tiện sửa.

Hình nhân vật/hoạt động lịch sử là minh họa, không phải footage tư liệu. Sơ đồ là mô hình nguyên lý, không phải sơ đồ đo đạc toàn di tích. Bộ không có125 clip đã tạo hoặc5 ảnh thumbnail đã tạo. Dù mọi prompt đã loại trẻ em, người dựng vẫn cần kiểm toàn bộ clip trả về vì mô hình có thể bỏ qua yêu cầu, kể cả ở tranh, biển hoặc đám đông nền.

Giữ nguyên các tệp profile, báo cáo, script và manifest SHA cùng thư mục dự án để lần sau chọn đúng giọng và biết chính xác bản âm thanh nào đã dùng.
