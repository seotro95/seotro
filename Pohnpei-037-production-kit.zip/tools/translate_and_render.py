"""Local pinned M2M100 inference; preserve numbered cues and render selected voices.
No remote Python code or replacement voice is used. Localizations remain subject
to native-speaker review; the English, Vietnamese, Spanish, French, German and
White Hmong scripts were separately prepared before this helper.
"""
import os
os.environ.update(OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
import concurrent.futures
import json
from pathlib import Path
import re
import subprocess
import sys
import time
import ctranslate2
import sentencepiece

ROOT=Path(__file__).resolve().parents[1]
MODEL=Path('/workspace/models/translation/m2m100-418m-ct2')
CODES=['ko','it','pt','nl','pl','sv','da','fi','no','cs']

def render(code):
    with (ROOT/f'validation/render-{code}.log').open('w') as log:
        process=subprocess.run([sys.executable,str(ROOT/'tools/render_audio.py'),code],stdout=log,stderr=subprocess.STDOUT)
    return {'language':code,'render_exit':process.returncode}

def main():
    source=json.loads((ROOT/'scripts/en.json').read_text())
    sp=sentencepiece.SentencePieceProcessor(model_file=str(MODEL/'sentencepiece.bpe.model'))
    translator=ctranslate2.Translator(str(MODEL),device='cpu',compute_type='int8',inter_threads=1,intra_threads=2)
    tokens=[['__en__']+sp.encode(r['text'],out_type=str)+['</s>'] for r in source]
    report={'model':'michaelfeil/ct2fast-m2m100_418M','revision':'06bd83294674f3737eb929e501aa5beafaa229d8','languages':{},'native_speaker_review':False}
    futures=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
        for code in CODES:
            started=time.monotonic();rows=[]
            path=ROOT/f'scripts/{code}.lines.txt'
            if not path.exists():
                for offset in range(0,120,8):
                    batch=tokens[offset:offset+8]
                    results=translator.translate_batch(batch,target_prefix=[['__'+code+'__'] for _ in batch],beam_size=4,
                        repetition_penalty=1.05,no_repeat_ngram_size=4,max_decoding_length=192,
                        suppress_sequences=[['<unk>'],['<','unk','>']])
                    for j,result in enumerate(results):
                        kept=[t for t in result.hypotheses[0] if not t.startswith('__') and t not in ['</s>','<s>','<pad>']]
                        text=sp.decode(kept).strip()
                        assert text and '<unk>' not in text,(code,offset+j+1,text)
                        if code=='pt':
                            for a,b in [('umidade','humidade'),('planejamento','planeamento'),('cotidiano','quotidiano'),('monitoramento','monitorização')]:
                                text=re.sub(a,b,text,flags=re.I)
                        rows.append(f'{offset+j+1:03d}\t{text}')
                assert len(rows)==120
                temp=path.with_suffix('.partial');temp.write_text('\n'.join(rows)+'\n');temp.replace(path)
            subprocess.run([sys.executable,str(ROOT/'tools/compile_scripts.py')],check=True,stdout=subprocess.DEVNULL)
            prepared=json.loads((ROOT/f'scripts/{code}.json').read_text())
            assert all(a['text']!=b['text'] for a,b in zip(source,prepared))
            report['languages'][code]={'cues':120,'seconds':1200,'translation_seconds':round(time.monotonic()-started,2),
                                       'samples':[prepared[i]['text'] for i in [0,3,20,64,92,93,95,119]]}
            (ROOT/'validation/localization-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
            print(json.dumps({'language':code,'translation_cues':120,'seconds':round(time.monotonic()-started,2)}),flush=True)
            futures.append(executor.submit(render,code))
        outputs=[f.result() for f in futures]
    (ROOT/'validation/localized-render-results.json').write_text(json.dumps(outputs,indent=2)+'\n')
    print(json.dumps(outputs),flush=True)

if __name__=='__main__':main()
