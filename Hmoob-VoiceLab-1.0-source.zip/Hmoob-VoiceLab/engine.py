"""Bounded, offline F5-Hmong inference for Hmoob VoiceLab.

The community checkpoint is experimental. Having model files is not evidence
that Hmong White pronunciation or similarity to a reference has been verified.
No model, ASR model, or vocabulary is downloaded by this module.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import threading
import wave


BASE = Path(__file__).resolve().parent
QUALITY_STEPS = {"draft": 8, "fast": 16, "standard": 32}
MODEL_FILES = (
    "f5-hmong/model_159952.safetensors",
    "f5-hmong/vocab.txt",
    "vocos/config.yaml",
    "vocos/pytorch_model.bin",
)
_integrity_cache = {}
_integrity_lock = threading.Lock()


class EngineError(RuntimeError):
    """An actionable inference failure safe to show in the interface."""


def model_directory():
    data = Path(os.getenv("HMOOB_DATA_DIR", str(BASE / ".data")))
    return Path(os.getenv("HMOOB_MODEL_DIR", str(data / "models"))).expanduser().resolve()


def _sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def verify_models(root=None):
    """Verify all files once per filesystem identity; never trust size alone."""
    root = Path(root) if root is not None else model_directory()
    try:
        manifest_path = root / "verified-models.json"
        if manifest_path.stat().st_size > 100_000:
            raise ValueError("manifest too large")
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        records = manifest["files"]
        fingerprint = [(str(root.resolve()), manifest_path.stat().st_mtime_ns,
                        manifest_path.stat().st_ctime_ns, manifest_path.stat().st_size)]
        for relative in MODEL_FILES:
            path = root / relative
            record = records[relative]
            expected = record["sha256"]
            if (not isinstance(expected, str) or len(expected) != 64
                    or any(ch not in "0123456789abcdef" for ch in expected)):
                raise ValueError("invalid hash")
            stat = path.stat()
            if not path.is_file() or stat.st_size != record["size"] or stat.st_size <= 0:
                raise ValueError("file size")
            fingerprint.append((relative, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns, expected))
        key = tuple(fingerprint)
        with _integrity_lock:
            if key in _integrity_cache:
                return key
            for relative in MODEL_FILES:
                if _sha256(root / relative) != records[relative]["sha256"]:
                    raise ValueError("checksum mismatch")
            _integrity_cache.clear()
            _integrity_cache[key] = True
        return key
    except (OSError, ValueError, KeyError, TypeError):
        raise EngineError("Thiếu mô hình hoặc kiểm tra SHA-256 không đạt. Chạy install_voice.bat "
                          "hoặc python setup_voice.py bằng mạng được phép; không dùng tệp chưa xác minh.") from None


def availability():
    """Return prerequisites without importing PyTorch or making network calls."""
    root = model_directory()
    requested = os.getenv("HMOOB_DEVICE", "auto").lower()
    dependencies = all(importlib.util.find_spec(name) is not None
                       for name in ("torch", "torchaudio", "f5_tts", "numpy"))
    reason = None
    if requested not in ("auto", "cpu", "cuda", "mps"):
        reason = "HMOOB_DEVICE chỉ nhận auto, cpu, cuda hoặc mps."
    else:
        try:
            verify_models(root)
        except EngineError as exc:
            reason = str(exc)
    if reason is None and not dependencies:
        reason = "Chưa cài thư viện tạo giọng. Chạy install_voice.bat hoặc cài requirements-voice.txt."
    return {
        "ready": reason is None,
        "reason": reason or "Đủ tệp và thư viện để chạy thử F5-Hmong; cần nghe kiểm tra phát âm và độ giống giọng.",
        "device": requested,
        "model_dir": str(root),
        "dependencies": dependencies,
        "dialect_verified": False,
        "quality_steps": QUALITY_STEPS.copy(),
    }


def _reference_identity(path, reference_text):
    path = Path(path)
    try:
        with wave.open(str(path), "rb") as handle:
            if (handle.getnchannels() != 1 or handle.getsampwidth() != 2
                    or handle.getframerate() != 24000):
                raise EngineError("Đoạn mẫu cần là WAV mono PCM 16-bit, 24.000 Hz.")
            seconds = handle.getnframes() / handle.getframerate()
            if not 3 <= seconds <= 8.001:
                raise EngineError("Chọn một đoạn giọng mẫu rõ lời dài 3–8 giây.")
        stat = path.stat()
        return (str(path.resolve()), stat.st_size, stat.st_mtime_ns, reference_text)
    except (OSError, wave.Error, EOFError):
        raise EngineError("Không đọc được đoạn WAV mẫu. Kiểm tra FFmpeg và chọn lại đoạn mẫu.") from None


def _bounded_batches(text, max_bytes):
    """Split at spaces where possible, without dropping or repeating a word."""
    pending = ""
    for token in re.findall(r"\S+\s*", text):
        if pending and len((pending + token).encode("utf-8")) > max_bytes:
            yield pending.strip()
            pending = ""
        if len(token.encode("utf-8")) <= max_bytes:
            pending += token
        else:
            for character in token:
                if pending and len((pending + character).encode("utf-8")) > max_bytes:
                    if pending.strip():
                        yield pending.strip()
                    pending = ""
                pending += character
    if pending.strip():
        yield pending.strip()


class SpeechEngine:
    """One loaded model and one cached reference tensor, reused across chunks."""

    def __init__(self):
        self._lock = threading.Lock()
        self._model = None
        self._model_key = None
        self._reference = None
        self._reference_key = None
        self.device = None

    def _load(self):
        root = model_directory()
        integrity = verify_models(root)
        requested = os.getenv("HMOOB_DEVICE", "auto").lower()
        if requested not in ("auto", "cpu", "cuda", "mps"):
            raise EngineError("HMOOB_DEVICE chỉ nhận auto, cpu, cuda hoặc mps.")
        import torch
        if requested == "auto":
            device = ("cuda" if torch.cuda.is_available() else "mps"
                      if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available()
                      else "cpu")
        else:
            device = requested
        if device == "cuda" and not torch.cuda.is_available():
            raise EngineError("Đã chọn CUDA nhưng PyTorch chưa nhận GPU. Cài bản PyTorch CUDA phù hợp hoặc chọn auto/cpu.")
        if device == "mps" and not (getattr(torch.backends, "mps", None) and torch.backends.mps.is_available()):
            raise EngineError("Đã chọn MPS nhưng máy này không có MPS khả dụng. Chọn auto/cpu.")
        key = (integrity, device)
        if self._model is None or self._model_key != key:
            cache = root.parent / "cache"
            for name, folder in (("MPLCONFIGDIR", "matplotlib"), ("NUMBA_CACHE_DIR", "numba"),
                                 ("XDG_CACHE_HOME", "xdg")):
                if not os.getenv(name):
                    target = cache / folder
                    target.mkdir(parents=True, exist_ok=True)
                    os.environ[name] = str(target)
            from f5_tts.api import F5TTS
            torch.set_num_threads(max(1, min(4, os.cpu_count() or 1)))
            candidate = F5TTS(
                model="F5TTS_Base",
                ckpt_file=str(root / MODEL_FILES[0]),
                vocab_file=str(root / MODEL_FILES[1]),
                vocoder_local_path=str(root / "vocos"),
                device=device,
            )
            self._model = candidate
            self._model_key = key
            self._reference = self._reference_key = None
            self.device = device
        return self._model

    def _prepare_reference(self, path, text, key):
        if self._reference_key != key:
            # Input is already a user-selected, 3–8 second, normalized WAV.
            # Avoid per-chunk pydub/FFmpeg preprocessing and automatic ASR.
            import soundfile
            import torch
            audio, rate = soundfile.read(str(path), dtype="float32", always_2d=True)
            tensor = torch.from_numpy(audio.T.copy())
            if not torch.isfinite(tensor).all() or float(tensor.square().mean()) < 1e-12:
                raise EngineError("Đoạn mẫu chỉ có im lặng hoặc dữ liệu không hợp lệ. Chọn đoạn có tiếng nói.")
            normalized_text = text.strip()
            if not normalized_text.endswith((".", "!", "?", "。")):
                normalized_text += "."
            normalized_text += " "
            self._reference = ((tensor, rate), normalized_text)
            self._reference_key = key
        return self._reference

    def synthesize(self, text, reference_path, reference_text, speed=1.0, quality="fast"):
        if not isinstance(text, str) or not text.strip() or len(text) > 400:
            raise EngineError("Mỗi đoạn tạo giọng cần 1–400 ký tự; dùng hàng đợi để đọc kịch bản dài.")
        if not isinstance(reference_text, str) or not reference_text.strip() or len(reference_text) > 2000:
            raise EngineError("Nhập đúng lời Hmong của đoạn mẫu; không tự nhận dạng hoặc đoán lời mẫu.")
        if (isinstance(speed, bool) or not isinstance(speed, (int, float))
                or not math.isfinite(speed) or not 0.5 <= speed <= 2):
            raise EngineError("Tốc độ đọc cần từ 0,5 đến 2 lần.")
        if quality not in QUALITY_STEPS:
            raise EngineError("Chọn fast (16 bước), standard (32 bước) hoặc draft (8 bước thử nghiệm).")
        reference_key = _reference_identity(reference_path, reference_text)
        with self._lock:
            try:
                model = self._load()
                reference, normalized_text = self._prepare_reference(reference_path, reference_text, reference_key)
                from f5_tts.infer.utils_infer import infer_batch_process
                # One bounded batch: no whole-book array or unbounded inference
                # fan-out, and no duplicate copy of a large model per process.
                import numpy as np
                reference_seconds = reference[0].shape[-1] / reference[1]
                # Match upstream's approximately 22-second context budget,
                # while running its sub-batches sequentially, never a large
                # ThreadPool of simultaneous GPU/CPU model calls.
                budget = int(len(normalized_text.encode("utf-8")) / reference_seconds
                             * (22 - reference_seconds) * speed)
                if budget < 8:
                    raise EngineError("Lời mẫu quá ngắn so với đoạn âm thanh. Nhập đủ lời khớp đoạn 3–8 giây.")
                pieces = []
                frames = 0
                expected_rate = None
                for batch in _bounded_batches(text.strip(), min(400, budget)):
                    result = next(infer_batch_process(
                        reference, normalized_text, [batch], model.ema_model, model.vocoder,
                        mel_spec_type=model.mel_spec_type, progress=None,
                        nfe_step=QUALITY_STEPS[quality], speed=float(speed), device=self.device,
                        cross_fade_duration=0,
                    ))
                    samples, rate = np.asarray(result[0]), result[1]
                    if (isinstance(rate, bool) or not isinstance(rate, int) or not 8000 <= rate <= 96000
                            or samples.ndim != 1 or not 0 < len(samples) <= rate * 120
                            or not np.isfinite(samples).all() or float(np.max(np.abs(samples))) < 1e-6
                            or (expected_rate is not None and rate != expected_rate)):
                        raise EngineError("Mô hình trả âm thanh rỗng, im lặng, quá dài hoặc không hợp lệ. Chưa có đoạn hoàn tất.")
                    expected_rate = rate
                    frames += len(samples)
                    if frames > rate * 120:
                        raise EngineError("Một đoạn vượt 2 phút âm thanh. Kiểm tra lời mẫu có khớp đoạn thu hay không.")
                    pieces.append(samples)
                if not pieces:
                    raise EngineError("Không có lời đọc hợp lệ trong đoạn này.")
                return np.concatenate(pieces) if len(pieces) > 1 else pieces[0], expected_rate
            except EngineError:
                raise
            except ImportError:
                raise EngineError("Thiếu thư viện tạo giọng. Chạy install_voice.bat bằng Python 3.10–3.12.") from None
            except Exception as exc:
                if type(exc).__name__ in ("OutOfMemoryError",):
                    raise EngineError("Thiếu RAM/VRAM khi tạo giọng. Tắt ứng dụng nặng hoặc chọn HMOOB_DEVICE=cpu.") from None
                raise EngineError("Không chạy được F5-Hmong. Kiểm tra phiên bản thư viện, checkpoint F5TTS_Base, "
                                  "vocabulary, Vocos và RAM; xem hướng dẫn cài giọng.") from None
