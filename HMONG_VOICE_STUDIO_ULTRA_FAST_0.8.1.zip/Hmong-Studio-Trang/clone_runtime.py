"""Install clone dependencies without mutating an environment used by Studio."""
from contextlib import contextmanager
import csv
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import uuid
import venv

from setup_venv import supported

BASE = Path(__file__).resolve().parent
SCHEMA = 1
TORCH = ['torch==2.6.0', 'torchaudio==2.6.0']
ENVIRONMENT = re.compile(r'\.venv-clone-[0-9a-f]{12}')
PROFILES = {
    'cpu': ('CPU', 'https://download.pytorch.org/whl/cpu'),
    'cu124': ('NVIDIA CUDA 12.4', 'https://download.pytorch.org/whl/cu124'),
}
CUDA_CHECK = (
    'import torch; '
    'assert torch.cuda.is_available(), '
    '"Khong nhan duoc GPU NVIDIA CUDA. Kiem tra GPU va cap nhat driver NVIDIA; bo may cu van duoc giu nguyen."; '
    'torch.ones(1, device="cuda").add_(1); torch.cuda.synchronize(); '
    'print("GPU NVIDIA da kiem tra: " + torch.cuda.get_device_name(0))'
)
AUTO_GPU_STATE = 'auto-gpu.json'


def detect_nvidia():
    """Read driver-provided adapter details without importing or installing Torch."""
    command = shutil.which('nvidia-smi')
    if not command:
        return []
    try:
        result = subprocess.run(
            [command, '--query-gpu=name,driver_version', '--format=csv,noheader'],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, check=True,
            text=True, encoding='utf-8', errors='replace', timeout=5,
        )
        if not result.stdout or len(result.stdout) > 65536:
            return []
        adapters = []
        for row in csv.reader(result.stdout.splitlines()):
            if len(row) != 2:
                return []
            name, driver = (value.strip() for value in row)
            if (not name or len(name) > 200 or any(ord(char) < 32 for char in name)
                    or not re.fullmatch(r'[0-9]+(?:\.[0-9]+){1,3}', driver)):
                return []
            adapters.append({'name': name, 'driver': driver})
        return sorted(adapters, key=lambda adapter: (adapter['name'], adapter['driver']))
    except (OSError, subprocess.SubprocessError, csv.Error):
        return []


def _automatic_gpu_key(root, adapters):
    digest = hashlib.sha256(dependency_fingerprint(root, 'cu124').encode())
    digest.update(json.dumps(adapters, sort_keys=True, ensure_ascii=True).encode())
    return digest.hexdigest()


def _automatic_gpu_failed(root, key):
    folder, _ = _paths(root)
    path = folder / AUTO_GPU_STATE
    try:
        if path.stat().st_size > 4096:
            return False
        record = json.loads(path.read_text(encoding='utf-8'))
        return (isinstance(record, dict) and set(record) == {'schema', 'key', 'status'}
                and type(record['schema']) is int and record['schema'] == 1
                and record['status'] == 'failed' and isinstance(record['key'], str)
                and bool(re.fullmatch(r'[0-9a-f]{64}', record['key']))
                and record['key'] == key)
    except (OSError, ValueError, TypeError):
        return False


def _remember_automatic_gpu_failure(root, key):
    folder, _ = _paths(root)
    try:
        _atomic_json(folder / AUTO_GPU_STATE, {'schema': 1, 'key': key, 'status': 'failed'})
    except OSError:
        print('Khong luu duoc ket qua thu GPU. Bo may CPU van duoc giu nguyen.', file=sys.stderr)


def dependency_fingerprint(root, profile='cpu'):
    if profile not in PROFILES:
        raise ValueError('Cau hinh bo may khong duoc ho tro: ' + str(profile))
    # Keep this prefix byte-for-byte compatible with existing CPU installs.
    digest = hashlib.sha256(('hmong-clone-' + profile + '-runtime-v1\0').encode())
    for name in ('requirements.txt', 'requirements-cosy.txt'):
        digest.update(name.encode() + b'\0' + (Path(root) / name).read_bytes())
    digest.update(json.dumps(TORCH).encode())
    return digest.hexdigest()


def _paths(root):
    folder = Path(root).resolve() / '.data' / 'runtime'
    folder.mkdir(parents=True, exist_ok=True)
    return folder, folder / 'clone-runtime.json'


def _atomic_json(path, value):
    with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=path.parent,
                                     prefix=path.name + '-', suffix='.tmp', delete=False) as stream:
        temporary = Path(stream.name)
        json.dump(value, stream, ensure_ascii=False, indent=2)
    try:
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


@contextmanager
def installer_lock(root):
    folder, _ = _paths(root)
    with (folder / 'clone-install.lock').open('a+b') as handle:
        handle.seek(0, os.SEEK_END)
        if not handle.tell():
            handle.write(b'0')
            handle.flush()
        handle.seek(0)
        try:
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            raise RuntimeError('Dang co bo cai nhan ban khac chay. Dong cua so bo cai cua tool roi thu lai.') from exc
        try:
            yield
        finally:
            handle.seek(0)
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def _record_profile(record):
    profile = record.get('profile', 'cpu')
    if profile not in PROFILES:
        raise ValueError('unsupported runtime profile')
    return profile


def _preferred_profile(root):
    """Retain a user's GPU selection when dependency updates need a new venv."""
    _, pointer = _paths(root)
    try:
        record = json.loads(pointer.read_text(encoding='utf-8'))
        if (not isinstance(record, dict) or record.get('schema') != SCHEMA
                or not ENVIRONMENT.fullmatch(record.get('environment', ''))):
            return 'cpu'
        return _record_profile(record)
    except (OSError, ValueError, TypeError):
        return 'cpu'


def selected_python(root, profile=None):
    root = Path(root).resolve()
    _, pointer = _paths(root)
    try:
        record = json.loads(pointer.read_text(encoding='utf-8'))
        if not isinstance(record, dict):
            raise ValueError('invalid runtime record')
        name = record['environment']
        selected_profile = _record_profile(record)
        if (record.get('schema') != SCHEMA or not ENVIRONMENT.fullmatch(name)
                or (profile is not None and profile != selected_profile)
                or record.get('fingerprint') != dependency_fingerprint(root, selected_profile)):
            raise ValueError('unverified or incompatible runtime')
        environment = root / name
        executable = environment / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
        if not environment.resolve().is_relative_to(root) or not executable.is_file():
            raise ValueError('missing runtime')
        return executable
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise RuntimeError('Chua co bo may nhan ban cai xong. Chay install_clone_ai.bat, cho thanh cong roi mo start.bat.') from exc


def _stop_child(process):
    if process.poll() is not None:
        return
    if os.name == 'nt':
        subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
    else:
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
    try:
        process.wait(timeout=10)
    except subprocess.TimeoutExpired:
        if os.name != 'nt':
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        else:
            process.kill()
        process.wait()


def _run(command, root, log=None):
    environment = dict(os.environ)
    environment['PYTHONUTF8'] = '1'
    environment['PIP_DISABLE_PIP_VERSION_CHECK'] = '1'
    environment['PATH'] = str(Path(root) / '.data' / 'tools' / 'ffmpeg' / 'bin') + os.pathsep + environment.get('PATH', '')
    options = {'creationflags': subprocess.CREATE_NEW_PROCESS_GROUP} if os.name == 'nt' else {'start_new_session': True}
    process = subprocess.Popen([str(part) for part in command], cwd=root, env=environment,
                               stdout=subprocess.PIPE if log else None,
                               stderr=subprocess.STDOUT if log else None,
                               text=True, encoding='utf-8', errors='replace', **options)
    try:
        if log:
            for line in process.stdout:
                print(line, end='', flush=True)
                log.write(line)
                log.flush()
        code = process.wait()
    except BaseException:
        _stop_child(process)
        raise
    if code:
        raise subprocess.CalledProcessError(code, command)
    return code


def _validate(executable, root, log, profile='cpu'):
    _run([executable, '-m', 'pip', 'check'], root, log)
    _run([executable, '-c', 'import torch,torchaudio,onnxruntime,whisper,transformers,soundfile,fastapi,uvicorn; from hyperpyyaml import load_hyperpyyaml; print("Thu vien nhan ban da kiem tra xong.")'], root, log)
    if profile == 'cu124':
        _run([executable, '-c', CUDA_CHECK], root, log)
    _run([executable, '-c', 'import cosy_engine,sys; s=cosy_engine.availability(); print(s["reason"] or "Mo hinh cuc bo da san sang."); sys.exit(0 if s["ready"] else 1)'], root, log)


def install(root=BASE, profile=None):
    import struct
    if sys.implementation.name != 'cpython' or not supported(sys.version_info, struct.calcsize('P') * 8):
        raise RuntimeError('Can CPython 3.10-3.12 64-bit; khuyen dung Python 3.12.')
    root = Path(root).resolve()
    with installer_lock(root):
        profile = _preferred_profile(root) if profile is None else profile
        expected_fingerprint = dependency_fingerprint(root, profile)
        folder, pointer = _paths(root)
        logfile = folder / ('install-' + datetime.now().strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:6] + '.log')
        with logfile.open('w', encoding='utf-8') as log:
            try:
                existing = None
                try:
                    existing = selected_python(root, profile)
                except RuntimeError:
                    pass
                if existing:
                    print('Kiem tra bo may da cai. Khong cai de thu vien dang dung.', flush=True)
                    try:
                        _validate(existing, root, log, profile)
                        if dependency_fingerprint(root, profile) != expected_fingerprint:
                            raise RuntimeError('Tep cai dat da thay doi trong luc cai. Hay chay lai bo cai.')
                        return existing
                    except (subprocess.CalledProcessError, OSError):
                        print('Bo may cu chua dat kiem tra; se tao moi truong rieng moi, khong sua bo cu.', flush=True)
                name = '.venv-clone-' + uuid.uuid4().hex[:12]
                target = root / name
                if target.exists():
                    raise RuntimeError('Ten moi truong moi da ton tai; chay lai bo cai.')
                print('Dang tao moi truong NHAN BAN RIENG: ' + name, flush=True)
                print('Giu nguyen .venv cu, du lieu va cac mau giong.', flush=True)
                venv.EnvBuilder(with_pip=True).create(target)
                executable = target / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
                print('[1/5] Kiem tra FFmpeg...', flush=True)
                _run([executable, '-X', 'utf8', 'prepare_media_tools.py'], root, log)
                description, index_url = PROFILES[profile]
                print('[2/5] Cai PyTorch ' + description + ' trong moi truong rieng...', flush=True)
                _run([executable, '-m', 'pip', 'install', '--no-input', '--only-binary=:all:', *TORCH,
                      '--index-url', index_url], root, log)
                if profile == 'cu124':
                    # Fail before downloading models if this machine cannot run CUDA.
                    _run([executable, '-c', CUDA_CHECK], root, log)
                print('[3/5] Cai thu vien nhan ban...', flush=True)
                _run([executable, '-m', 'pip', 'install', '--no-input', '--only-binary=:all:',
                      '--no-binary=antlr4-python3-runtime,openai-whisper', '-r', 'requirements-cosy.txt'], root, log)
                print('[4/5] Tai/xac minh mo hinh; cac tep da dung duoc tai su dung...', flush=True)
                _run([executable, '-X', 'utf8', 'prepare_clone_model.py'], root, log)
                print('[5/5] Kiem tra truoc khi kich hoat...', flush=True)
                _validate(executable, root, log, profile)
                if dependency_fingerprint(root, profile) != expected_fingerprint:
                    raise RuntimeError('Tep cai dat da thay doi trong luc cai. Chua kich hoat; hay chay lai bo cai.')
                _atomic_json(pointer, {'schema': SCHEMA, 'environment': name,
                    'fingerprint': expected_fingerprint, 'profile': profile,
                    'created_at': datetime.now(timezone.utc).isoformat()})
                print('Da cai xong va kich hoat bo may nhan ban. Chay start.bat.', flush=True)
                return executable
            except BaseException:
                print('Chua cai xong; bo may cu va cac mau giong khong bi thay doi.', file=sys.stderr)
                print('Nhat ky: ' + str(logfile), file=sys.stderr)
                print('Neu thay WinError 32, dong Studio/cac bo cai cua tool; khoi dong lai Windows neu van bi giu tep.', file=sys.stderr)
                raise


def serve(root=BASE, *, open_browser=False):
    root = Path(root).resolve()
    executable = selected_python(root)
    print('Hmong Studio dang dung bo may nhan ban: ' + executable.parent.parent.name, flush=True)
    print('Mo trinh duyet: http://127.0.0.1:8090', flush=True)
    try:
        if open_browser:
            return _run([executable, '-X', 'utf8', 'open_studio.py'], root)
        return _run([executable, '-m', 'uvicorn', 'app:app', '--host', '127.0.0.1', '--port', '8090', '--no-access-log',
                     '--timeout-graceful-shutdown', '10'], root)
    except KeyboardInterrupt:
        return 0
    except subprocess.CalledProcessError:
        print('Khong mo duoc Studio. Dong cua so Studio cu dang dung cong8090 roi chay lai CHAY-STUDIO.bat.', file=sys.stderr)
        raise


def launch(root=BASE, profile=None):
    if profile is None:
        install(root)
    else:
        install(root, profile=profile)
    return serve(root, open_browser=True)


def launch_auto(root=BASE):
    """Try a detected NVIDIA GPU once, retaining a working CPU installation.

    Detection only chooses an installer: activation still requires the real
    CUDA check in install(). A manually selected GPU profile always stays in
    control, including when its validation fails and needs user attention.
    """
    root = Path(root).resolve()
    if _preferred_profile(root) == 'cu124':
        return launch(root)
    adapters = detect_nvidia()
    if not adapters:
        return launch(root)
    key = _automatic_gpu_key(root, adapters)
    if _automatic_gpu_failed(root, key):
        print('Lan thu GPU tu dong truoc chua thanh cong; tiep tuc dung CPU. '
              'Chay CAI-NVIDIA.bat neu muon thu lai GPU.', flush=True)
        return launch(root)
    print('Phat hien GPU NVIDIA: ' + ', '.join(adapter['name'] for adapter in adapters), flush=True)
    print('Dang chuan bi CUDA. Chi kich hoat sau khi kiem tra GPU that thanh cong.', flush=True)
    try:
        install(root, profile='cu124')
    except (OSError, RuntimeError, subprocess.CalledProcessError) as exc:
        # Another installer may have explicitly selected a GPU meanwhile. Do
        # not replace that choice with a CPU profile after our failed attempt.
        if _preferred_profile(root) == 'cu124':
            raise
        print('Chua kich hoat duoc GPU tu dong: ' + str(exc)[:1500], file=sys.stderr)
        print('Dang kiem tra/dung lai bo may CPU. Chay CAI-NVIDIA.bat de thu lai GPU.', flush=True)
        _remember_automatic_gpu_failure(root, key)
        return launch(root)
    folder, _ = _paths(root)
    try:
        (folder / AUTO_GPU_STATE).unlink(missing_ok=True)
    except OSError:
        # A stale failed-attempt memo cannot override the selected GPU profile.
        pass
    return serve(root, open_browser=True)


if __name__ == '__main__':
    try:
        if sys.argv[1:] == ['install']:
            install()
        elif sys.argv[1:] == ['install-gpu']:
            install(profile='cu124')
        elif sys.argv[1:] == ['serve']:
            sys.exit(serve())
        elif sys.argv[1:] == ['launch']:
            sys.exit(launch())
        elif sys.argv[1:] == ['launch-auto']:
            sys.exit(launch_auto())
        elif sys.argv[1:] == ['launch-gpu']:
            sys.exit(launch(profile='cu124'))
        else:
            raise RuntimeError('Lenh ho tro: install, install-gpu, serve, launch, launch-auto hoac launch-gpu.')
    except (Exception, KeyboardInterrupt) as exc:
        print('Khong hoan tat: ' + (str(exc) or 'Da dung theo yeu cau.'), file=sys.stderr)
        sys.exit(1)
