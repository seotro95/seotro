@echo off
setlocal EnableExtensions DisableDelayedExpansion
rem This is a downloader. The complete application is downloaded afterward.
rem Only fixed release data is downloaded; downloaded scripts are not executed.
set "VS_EXIT=1"
set "VS_PUSHED="
pushd "%~dp0"
if errorlevel 1 goto failed
set "VS_PUSHED=1"
set "VS_ARCHIVE=Voice-Studio-1.12.3-19-Turbo-Windows.zip"
set "VS_FULL_SIZE=2459854010"
set "VS_FULL_SHA=8d530815e77f0e955a05d73667222ab4642533a70ca833152bc9cefc2d0de126"
set "VS_BASE=https://github.com/seotro95/seotro/releases/download/voice-studio-1.12.3-turbo19/"
set "VS_FINAL=%CD%\%VS_ARCHIVE%"
set "VS_CACHE=%CD%\_Voice-Studio-Download-8d530815e77f"
set "VS_STAGING=%VS_CACHE%\complete.zip.assembling"
set "VS_OWNER=voice-studio-download-v1 8d530815e77f0e955a05d73667222ab4642533a70ca833152bc9cefc2d0de126"
where powershell.exe >nul 2>&1
if errorlevel 1 goto missing_powershell
echo VOICE STUDIO - TAI GOI DAY DU THANH MOT TEP ZIP
echo Day la tep tai tu dong, khong chua san toan bo tool.
echo Can Internet va nen co it nhat 12 GB dung luong trong de tai, ghep va giai nen.
echo Co the chay lai neu mat mang; cac phan da xac minh duoc dung lai.
echo.
set "VS_CHECK=%VS_FINAL%"
set "VS_EXPECT_SIZE=%VS_FULL_SIZE%"
set "VS_EXPECT_SHA=%VS_FULL_SHA%"
if not exist "%VS_FINAL%" goto prepare_cache
call :verify
if errorlevel 1 goto existing_zip_invalid
goto success

:prepare_cache
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "$ErrorActionPreference='Stop';try{$p=$env:VS_CACHE;$m=Join-Path $p 'OWNER.txt';if(Test-Path -LiteralPath $p){$d=Get-Item -LiteralPath $p;if(-not $d.PSIsContainer -or ($d.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Cache path is not a regular directory'};if(-not(Test-Path -LiteralPath $m -PathType Leaf)){throw 'Existing cache has no ownership marker'};$f=Get-Item -LiteralPath $m;if(($f.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $f.Length -gt 256 -or [IO.File]::ReadAllText($m).Trim() -cne $env:VS_OWNER){throw 'Existing cache belongs to different data'}}else{$null=[IO.Directory]::CreateDirectory($p);[IO.File]::WriteAllText($m,$env:VS_OWNER+[Environment]::NewLine,[Text.Encoding]::ASCII)};exit 0}catch{Write-Host $_.Exception.Message;exit 1}"
if errorlevel 1 goto failed
set "VS_CURL="
where curl.exe >nul 2>&1
if not errorlevel 1 set "VS_CURL=1"
call :part "Voice-Studio-1.12.3-19-Turbo-Windows.zip.part001" "1610612736" "8f897e6a798cb9c8708e458ae7db7bbfecf5673ba022531c54787a2fefd1d779" "001"
if errorlevel 1 goto failed
call :part "Voice-Studio-1.12.3-19-Turbo-Windows.zip.part002" "849241274" "45ce6038a6d05df05f5494d1765f8aa71d7ce01ac6aa042be86f6be83fe1c168" "002"
if errorlevel 1 goto failed
rem Rebuild only our staging file, never an existing user ZIP.
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "$ErrorActionPreference='Stop';try{$p=$env:VS_STAGING;if(Test-Path -LiteralPath $p){$f=Get-Item -LiteralPath $p;if($f.PSIsContainer -or ($f.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Unsafe staging path'};Remove-Item -LiteralPath $p};exit 0}catch{Write-Host $_.Exception.Message;exit 1}"
if errorlevel 1 goto failed
echo Dang ghep mot tep ZIP day du...
copy /b "%VS_SOURCE_001%"+"%VS_SOURCE_002%" "%VS_STAGING%" >nul
if errorlevel 1 goto failed
set "VS_CHECK=%VS_STAGING%"
set "VS_EXPECT_SIZE=%VS_FULL_SIZE%"
set "VS_EXPECT_SHA=%VS_FULL_SHA%"
call :verify
if errorlevel 1 goto full_hash_failed
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "$ErrorActionPreference='Stop';try{[IO.File]::Move($env:VS_STAGING,$env:VS_FINAL);exit 0}catch{Write-Host $_.Exception.Message;exit 1}"
if errorlevel 1 goto failed

:success
set "VS_EXIT=0"
call :cleanup_cache
echo.
echo DA TAO VA KIEM TRA SHA256 MOT TEP ZIP DAY DU:
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "Write-Host $env:VS_FINAL"
echo Giai nen toan bo ZIP vao thu muc moi. Sau do mo MO_TOOL.bat.
echo Khong can tai thu cong cac tep part hoac tep ghep nao khac.
goto finish

:existing_zip_invalid
echo ZIP cung ten da ton tai nhung khong khop. Tep cu duoc giu nguyen.
echo Hay dung mot thu muc moi cho tep tai nay.
goto failed
:full_hash_failed
echo Kich thuoc hoac SHA256 ZIP ghep khong khop. Khong su dung tep do.
goto failed
:missing_powershell
echo Can Windows PowerShell de kiem tra SHA256. Chua tai hoac chay tool.
goto failed
:failed
echo.
echo Chua hoan tat. Cac tep cu va cac phan da xac minh duoc giu nguyen.
echo Kiem tra ket noi va dung luong, roi chay lai tep tai nay.
:finish
if not defined VOICE_DOWNLOAD_NO_PAUSE pause
if defined VS_PUSHED popd
exit /b %VS_EXIT%

:verify
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "$ErrorActionPreference='Stop';$s=$null;$h=$null;try{$p=$env:VS_CHECK;if(-not(Test-Path -LiteralPath $p -PathType Leaf)){exit 2};$f=Get-Item -LiteralPath $p;if(($f.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $f.Length -ne [long]$env:VS_EXPECT_SIZE){exit 1};$s=[IO.File]::OpenRead($p);$h=[Security.Cryptography.SHA256]::Create();$digest=([BitConverter]::ToString($h.ComputeHash($s))).Replace('-','').ToLowerInvariant();if($digest -cne $env:VS_EXPECT_SHA){exit 1};exit 0}catch{Write-Host $_.Exception.Message;exit 1}finally{if($null -ne $s){$s.Dispose()};if($null -ne $h){$h.Dispose()}}"
exit /b %ERRORLEVEL%

:cleanup_cache
rem Only after the complete ZIP is verified: clean an entirely owned cache.
rem Unknown data, unsafe paths or mismatching bytes preserve the entire cache.
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "$ErrorActionPreference='Stop';function Matches($f,$size,$sha){if($f.Length -ne [long]$size){return $false};$s=$null;$h=$null;try{$s=[IO.File]::OpenRead($f.FullName);$h=[Security.Cryptography.SHA256]::Create();return ([BitConverter]::ToString($h.ComputeHash($s))).Replace('-','').ToLowerInvariant() -ceq $sha}finally{if($null -ne $s){$s.Dispose()};if($null -ne $h){$h.Dispose()}}};try{$p=$env:VS_CACHE;if(-not(Test-Path -LiteralPath $p)){exit 0};$d=Get-Item -LiteralPath $p;$m=Join-Path $p 'OWNER.txt';if(-not $d.PSIsContainer -or ($d.Attributes -band [IO.FileAttributes]::ReparsePoint) -or -not(Test-Path -LiteralPath $m -PathType Leaf)){Write-Host 'Giu cache vi khong xac nhan duoc quyen so huu.';exit 0};$marker=Get-Item -LiteralPath $m;if(($marker.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $marker.Length -gt 256 -or [IO.File]::ReadAllText($m).Trim() -cne $env:VS_OWNER){Write-Host 'Giu cache vi khong xac nhan duoc quyen so huu.';exit 0};$known=@{'Voice-Studio-1.12.3-19-Turbo-Windows.zip.part001'=@(1610612736,'8f897e6a798cb9c8708e458ae7db7bbfecf5673ba022531c54787a2fefd1d779');'Voice-Studio-1.12.3-19-Turbo-Windows.zip.part001.partial'=@(1610612736,'8f897e6a798cb9c8708e458ae7db7bbfecf5673ba022531c54787a2fefd1d779');'Voice-Studio-1.12.3-19-Turbo-Windows.zip.part002'=@(849241274,'45ce6038a6d05df05f5494d1765f8aa71d7ce01ac6aa042be86f6be83fe1c168');'Voice-Studio-1.12.3-19-Turbo-Windows.zip.part002.partial'=@(849241274,'45ce6038a6d05df05f5494d1765f8aa71d7ce01ac6aa042be86f6be83fe1c168');'complete.zip.assembling'=@(2459854010,'8d530815e77f0e955a05d73667222ab4642533a70ca833152bc9cefc2d0de126')};$files=@();foreach($f in Get-ChildItem -LiteralPath $p -Force){if($f.Name -eq 'OWNER.txt'){continue};$key=$f.Name;if($f.PSIsContainer -or ($f.Attributes -band [IO.FileAttributes]::ReparsePoint) -or -not $known.ContainsKey($key)){Write-Host 'Giu cache vi co tep khac hoac du lieu chua khop.';exit 0};$expected=$known[$key];if(-not(Matches $f $expected[0] $expected[1])){Write-Host 'Giu cache vi co tep khac hoac du lieu chua khop.';exit 0};$files+=$f};foreach($f in $files){Remove-Item -LiteralPath $f.FullName};if(@(Get-ChildItem -LiteralPath $p -Force).Count -eq 1){Remove-Item -LiteralPath $m;[IO.Directory]::Delete($p);Write-Host 'Da xoa cac phan tai tam; chi giu ZIP day du.'};exit 0}catch{Write-Host 'Chua don het cache; ZIP day du van da duoc xac minh.';exit 0}"
exit /b 0

:part
set "VS_PART=%~1"
set "VS_EXPECT_SIZE=%~2"
set "VS_EXPECT_SHA=%~3"
set "VS_SLOT=%~4"
set "VS_NEAR=%CD%\%VS_PART%"
set "VS_FILE=%VS_CACHE%\%VS_PART%"
set "VS_PARTIAL=%VS_FILE%.partial"
set "VS_URL=%VS_BASE%%VS_PART%"
set "VS_CHECK=%VS_NEAR%"
call :verify
if not errorlevel 1 goto part_near
if not exist "%VS_FILE%" goto part_partial
set "VS_CHECK=%VS_FILE%"
call :verify
if errorlevel 1 goto part_existing_invalid
goto part_complete
:part_partial
set "VS_CHECK=%VS_PARTIAL%"
call :verify
if not errorlevel 1 goto part_move
rem This partial file is in our owner-marked cache. Reject redirects/symlinks.
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "$ErrorActionPreference='Stop';try{$p=$env:VS_PARTIAL;if(Test-Path -LiteralPath $p){$f=Get-Item -LiteralPath $p;if($f.PSIsContainer -or ($f.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Unsafe partial download path'};if($f.Length -ge [long]$env:VS_EXPECT_SIZE){Remove-Item -LiteralPath $p}};exit 0}catch{Write-Host $_.Exception.Message;exit 1}"
if errorlevel 1 exit /b 1
echo Dang tai va kiem tra %VS_PART% ...
if not defined VS_CURL goto part_webclient
set "VS_RESTARTED="
:part_curl
curl.exe --fail --location --show-error --progress-bar --proto "=https" --proto-redir "=https" --connect-timeout 30 --retry 2 --retry-delay 2 --continue-at - --output "%VS_PARTIAL%" "%VS_URL%"
set "VS_CURL_ERROR=%ERRORLEVEL%"
if "%VS_CURL_ERROR%"=="0" goto part_downloaded
if defined VS_RESTARTED goto part_network_failed
if "%VS_CURL_ERROR%"=="33" goto part_restart
if "%VS_CURL_ERROR%"=="36" goto part_restart
goto part_network_failed
:part_restart
set "VS_RESTARTED=1"
echo May chu khong cho tiep tuc phan dang do; tai lai rieng phan nay.
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "$ErrorActionPreference='Stop';try{if(Test-Path -LiteralPath $env:VS_PARTIAL){Remove-Item -LiteralPath $env:VS_PARTIAL};exit 0}catch{Write-Host $_.Exception.Message;exit 1}"
if errorlevel 1 exit /b 1
goto part_curl
:part_webclient
echo Khong co curl.exe; PowerShell se tai lai phan dang do. Cac phan da xac minh van duoc dung lai.
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "$ErrorActionPreference='Stop';$w=$null;try{[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12;$w=New-Object Net.WebClient;$w.DownloadFile($env:VS_URL,$env:VS_PARTIAL);exit 0}catch{Write-Host $_.Exception.Message;exit 1}finally{if($null -ne $w){$w.Dispose()}}"
if errorlevel 1 goto part_network_failed
:part_downloaded
set "VS_CHECK=%VS_PARTIAL%"
call :verify
if errorlevel 1 goto part_download_invalid
:part_move
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "$ErrorActionPreference='Stop';try{[IO.File]::Move($env:VS_PARTIAL,$env:VS_FILE);exit 0}catch{Write-Host $_.Exception.Message;exit 1}"
if errorlevel 1 exit /b 1
:part_complete
set "VS_SOURCE_%VS_SLOT%=%VS_FILE%"
echo Da xac minh %VS_PART%.
exit /b 0
:part_near
set "VS_SOURCE_%VS_SLOT%=%VS_NEAR%"
echo Dung lai phan da co va dung SHA256: %VS_PART%.
exit /b 0
:part_existing_invalid
echo Phan trong cache khong khop. Giu nguyen tep va dung thu muc tai moi.
exit /b 1
:part_download_invalid
echo Phan vua tai chua du hoac sai SHA256. Chay lai de tai lai rieng phan nay.
exit /b 1
:part_network_failed
echo Tai bi gian doan. Chay lai de tiep tuc; khong can tai lai cac phan da xac minh.
exit /b 1
