# Kết quả kiểm tra Video Studio VN 0.1.0

Môi trường xác minh: Linux, Python 3.12.14, FFmpeg/FFprobe 7.1.5.

- 10 kiểm thử của tool mới: đạt; không bỏ qua kiểm thử nào.
- Trình duyệt Chromium thật: nhập video qua giao diện, tạo/lưu SRT, render kèm phụ đề/tiêu đề, liên kết tải kết quả, kiểm tra cấu hình API, bố cục 390 px: đạt; không có lỗi JavaScript.
- Hàng loạt: render hai video với cùng cấu hình; kiểm tra kích thước, thời lượng, giữ audio và mốc SRT sau cắt/tăng tốc: đạt.
- Ghép giọng đọc: tệp âm thanh ngắn được đệm theo thời lượng video: đạt.
- Dừng tiến trình: tiến trình thật được kết thúc; nguồn giữ nguyên: đạt.
- Thư viện và lịch sử được giữ khi mở instance mới: đạt. Thư viện chạy cho người dùng đã được làm sạch; dữ liệu kiểm tra được giữ riêng ngoài mã nguồn.
- Adapter STT/TTS/dịch/biên tập AI: đạt với phản hồi HTTP giả lập đúng định dạng; chưa xác minh nhà cung cấp AI thật.
- Bộ công cụ v1.5 có sẵn trong repository: 37 kiểm thử đạt, 34 subtest đạt, 3 kiểm thử aria2 tùy chọn bỏ qua. API cục bộ nhập video, lấy khung hình, xử lý vùng ảnh và xuất tệp: đạt.
- HTTPS Git read với xác thực nền tảng: đạt.

Chưa thực thi trên Windows; chưa chạy các file BAT, giọng Windows, Edge TTS, model Whisper hoặc tải video từ nền tảng thật. Proxy của môi trường cloud trả CONNECT 403 khi kiểm tra Bilibili/Douyin trước khi cập nhật cấu hình mạng. API/model/cookie cần cấu hình tương ứng; xem HUONG_DAN.md.

Không có chỉnh sửa các tệp đã được theo dõi trong repository ban đầu. `video-studio/` là mã nguồn mới được tạo theo yêu cầu xây dựng tool của người dùng.
