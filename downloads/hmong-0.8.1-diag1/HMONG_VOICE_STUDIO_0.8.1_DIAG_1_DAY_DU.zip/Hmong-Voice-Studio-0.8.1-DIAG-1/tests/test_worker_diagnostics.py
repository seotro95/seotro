"""Real child failures retain evidence without reporting partial voice as complete.

The tiny workers exercise process ownership and diagnostics, not model inference
or Windows hardware compatibility.
"""
import asyncio
from pathlib import Path
import textwrap
from types import SimpleNamespace

import pytest

import voice_jobs


def _script(tmp_path, source):
    path = tmp_path / 'diagnostic-worker.py'
    path.write_text(textwrap.dedent(source), encoding='utf-8')
    return path


def _configure(monkeypatch, tmp_path, worker):
    directory = tmp_path / 'logs'
    monkeypatch.setattr(voice_jobs, 'WORKER', worker)
    monkeypatch.setattr(voice_jobs, '_DIAGNOSTIC_DIR', directory)
    return directory


def _logs(directory):
    return list(directory.glob('*.log'))


async def _until(job_id, predicate):
    deadline = asyncio.get_running_loop().time() + 8
    while True:
        state = voice_jobs.view(voice_jobs.get(job_id))
        if predicate(state):
            return state
        assert asyncio.get_running_loop().time() < deadline, state
        await asyncio.sleep(.01)


def test_abrupt_exit_retains_child_log_and_exit_code(monkeypatch, tmp_path):
    worker = _script(tmp_path, '''
        import json, os, sys
        from pathlib import Path
        request = json.loads(input())
        folder = Path(request['folder'])
        (folder / 'progress.json').write_text(json.dumps({
            'progress': 33, 'completed_units': 1, 'total_units': 6,
            'generated_seconds': 3, 'phase': 'generating'}))
        print('native-runtime-diagnostic-sentinel', file=sys.stderr, flush=True)
        os._exit(23)
    ''')
    directory = _configure(monkeypatch, tmp_path, worker)

    async def scenario():
        try:
            ident = voice_jobs.create({'text': 'six cues'})['id']
            await voice_jobs.get(ident)['task']
            failed = voice_jobs.view(voice_jobs.get(ident))
            assert failed['status'] == 'failed'
            assert failed['progress'] == 33
            assert failed['completed_units'] == 1
            assert failed['audio_bytes'] == 0
            assert '23' in failed['message']
            assert '0x00000017' in failed['message'].lower()
            assert '.log' in failed['message']
            assert voice_jobs._WORKER_STATE is None
            files = _logs(directory)
            assert len(files) == 1
            assert 'native-runtime-diagnostic-sentinel' in files[0].read_text(encoding='utf-8')
        finally:
            await voice_jobs.shutdown()
        # Releasing all jobs and worker temporary directories must not remove
        # the evidence the Windows user needs to report the crash.
        assert len(_logs(directory)) == 1

    asyncio.run(scenario())


def test_python_worker_exception_retains_traceback(monkeypatch, tmp_path):
    source = '''
        import asyncio, sys, types
        from pathlib import Path
        app = types.ModuleType('app')
        class Speech:
            @staticmethod
            def model_validate(value):
                return value
        async def generate_speech(payload, progress=None, output_path=None):
            raise RuntimeError('python-error-diagnostic-sentinel')
        app.Speech = Speech
        app.generate_speech = generate_speech
        sys.modules['app'] = app
    '''
    source = textwrap.dedent(source)
    source += '\nsys.path.insert(0, ' + repr(str(Path(voice_jobs.__file__).parent)) + ')\n'
    source += 'import voice_worker\nasyncio.run(voice_worker.main())\n'
    directory = _configure(monkeypatch, tmp_path, _script(tmp_path, source))

    async def scenario():
        try:
            ident = voice_jobs.create({'text': 'one cue'})['id']
            await voice_jobs.get(ident)['task']
            assert voice_jobs.view(voice_jobs.get(ident))['status'] == 'failed'
            files = _logs(directory)
            assert len(files) == 1
            contents = files[0].read_text(encoding='utf-8')
            assert 'Traceback (most recent call last)' in contents
            assert 'RuntimeError: python-error-diagnostic-sentinel' in contents
        finally:
            await voice_jobs.shutdown()

    asyncio.run(scenario())


def test_success_does_not_archive_failure_log(monkeypatch, tmp_path):
    worker = _script(tmp_path, '''
        import json, wave
        from pathlib import Path
        for line in __import__('sys').stdin:
            folder = Path(json.loads(line)['folder'])
            with wave.open(str(folder / 'audio.bin'), 'wb') as audio:
                audio.setnchannels(1)
                audio.setsampwidth(2)
                audio.setframerate(24000)
                audio.writeframes(b'\\x01\\x00' * 100)
            (folder / 'result.json').write_text(json.dumps({'media_type': 'audio/wav'}))
    ''')
    directory = _configure(monkeypatch, tmp_path, worker)

    async def scenario():
        try:
            ident = voice_jobs.create({'text': 'successful cue'})['id']
            await voice_jobs.get(ident)['task']
            assert voice_jobs.view(voice_jobs.get(ident))['status'] == 'completed'
            assert not _logs(directory)
        finally:
            await voice_jobs.shutdown()
        assert not _logs(directory)

    asyncio.run(scenario())


def test_cancel_does_not_archive_failure_log(monkeypatch, tmp_path):
    worker = _script(tmp_path, '''
        import json, sys, time
        from pathlib import Path
        request = json.loads(input())
        folder = Path(request['folder'])
        print('cancelled-worker-output', file=sys.stderr, flush=True)
        (folder / 'progress.json').write_text(json.dumps({
            'progress': 10, 'completed_units': 0, 'total_units': 1,
            'generated_seconds': 0, 'phase': 'generating'}))
        time.sleep(60)
    ''')
    directory = _configure(monkeypatch, tmp_path, worker)

    async def scenario():
        try:
            ident = voice_jobs.create({'text': 'cancelled cue'})['id']
            await _until(ident, lambda state: state['progress'] == 10)
            cancelled = await voice_jobs.cancel(ident)
            assert cancelled['status'] == 'cancelled'
            assert not _logs(directory)
        finally:
            await voice_jobs.shutdown()
        assert not _logs(directory)

    asyncio.run(scenario())


@pytest.mark.parametrize('code', [-1073741819, 3221225477])
def test_windows_exit_code_keeps_unsigned_hex(monkeypatch, tmp_path, code):
    directory = tmp_path / 'logs'
    monkeypatch.setattr(voice_jobs, '_DIAGNOSTIC_DIR', directory)
    worker_folder = tmp_path / 'worker'
    worker_folder.mkdir()
    (worker_folder / 'worker.log').write_text('native crash evidence', encoding='utf-8')
    state = {'process': SimpleNamespace(returncode=code),
             'temp': SimpleNamespace(name=str(worker_folder))}
    message = voice_jobs._preserve_failure(state, {'id': 'windows-code'})
    assert str(code) in message
    assert '0xc0000005' in message.lower()
    files = _logs(directory)
    assert len(files) == 1
    contents = files[0].read_text(encoding='utf-8')
    assert str(code) in contents
    assert '0xc0000005' in contents.lower()
    assert 'native crash evidence' in contents


def test_unwritable_diagnostic_directory_does_not_mask_failure(monkeypatch, tmp_path, capsys):
    directory = tmp_path / 'read-only-logs'
    monkeypatch.setattr(voice_jobs, '_DIAGNOSTIC_DIR', directory)
    mkdir = Path.mkdir

    def deny_diagnostic_directory(path, *args, **kwargs):
        if path == directory:
            raise PermissionError('simulated application directory permissions')
        return mkdir(path, *args, **kwargs)

    monkeypatch.setattr(Path, 'mkdir', deny_diagnostic_directory)
    state = {'process': SimpleNamespace(returncode=23)}
    message = voice_jobs._preserve_failure(state, {'id': 'read-only'})
    assert '23' in message
    assert '0x00000017' in message.lower()
    assert 'quyền ghi' in message
    assert 'PermissionError' in capsys.readouterr().err
    assert not directory.exists()
