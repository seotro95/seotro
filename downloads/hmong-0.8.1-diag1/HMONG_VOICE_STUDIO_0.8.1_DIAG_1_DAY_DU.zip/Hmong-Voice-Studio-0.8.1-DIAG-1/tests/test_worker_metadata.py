"""Windows file-sharing failures must not silently terminate a valid job."""
import json
import pytest
import voice_worker


def test_result_survives_temporary_windows_file_lock(monkeypatch, tmp_path):
    target = tmp_path / 'result.json'
    target.write_text('{"previous": true}')
    replace = voice_worker.os.replace
    attempts = []
    waits = []

    def locked(source, destination):
        attempts.append(1)
        if len(attempts) <= 5:
            assert json.loads(target.read_text()) == {'previous': True}
            raise PermissionError('simulated Windows sharing violation')
        replace(source, destination)

    monkeypatch.setattr(voice_worker.os, 'replace', locked)
    monkeypatch.setattr(voice_worker.time, 'sleep', waits.append)
    voice_worker.atomic_json(target, {'media_type': 'audio/wav'})
    assert len(attempts) == 6
    assert json.loads(target.read_text()) == {'media_type': 'audio/wav'}
    assert not target.with_name('result.json.tmp').exists()
    assert sum(waits) < .711


def test_permanent_write_lock_is_reported_and_bounded(monkeypatch, tmp_path):
    target = tmp_path / 'result.json'
    target.write_text('{"previous": true}')
    attempts = []
    waits = []

    def locked(*args):
        attempts.append(1)
        raise PermissionError('permanent Windows sharing violation')

    monkeypatch.setattr(voice_worker.os, 'replace', locked)
    monkeypatch.setattr(voice_worker.time, 'sleep', waits.append)
    with pytest.raises(PermissionError):
        voice_worker.atomic_json(target, {'media_type': 'audio/wav'})
    assert len(attempts) == 8
    assert sum(waits) == pytest.approx(.71)
    assert json.loads(target.read_text()) == {'previous': True}
