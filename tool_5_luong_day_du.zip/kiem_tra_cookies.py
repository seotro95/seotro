"""Local cookie metadata diagnostics. Never print cookie values or parser errors."""
from __future__ import annotations
import contextlib
import http.cookiejar
import importlib.metadata
import io
import os
import time
from pathlib import Path


def inspect_cookie_file(path: Path) -> list[str]:
    if not path.is_file():
        return ['KHONG TIM THAY TEP COOKIES.']
    if path.stat().st_size == 0:
        return ['TEP COOKIES RONG. Can xuat cookies tu trinh duyet.']
    jar = http.cookiejar.MozillaCookieJar(str(path))
    try:
        # Malformed cookie errors/warnings can contain credential values.
        with contextlib.redirect_stderr(io.StringIO()), contextlib.redirect_stdout(io.StringIO()):
            jar.load(ignore_discard=True, ignore_expires=True)
    except Exception:
        return ['KHONG DOC DUOC DINH DANG NETSCAPE. Can xuat lai cookies.txt, khong dung JSON.']
    cookies = list(jar)
    douyin = [c for c in cookies if c.domain.lstrip('.').lower() in ('douyin.com', 'www.douyin.com')]
    active = [c for c in douyin if not c.is_expired(time.time())]
    messages = [
        'DINH DANG NETSCAPE: DOC DUOC',
        f'Tong so cookies: {len(cookies)}',
        f'Cookies cho Douyin: {len(douyin)}',
        f'Cookies Douyin con han: {len(active)}',
        'Co cookie s_v_web_id con han: ' + ('CO' if any(c.name == 's_v_web_id' for c in active) else 'KHONG'),
    ]
    if not douyin:
        messages.append('TEP KHONG CO COOKIES CHO DOUYIN. Xuat tai tab www.douyin.com dang phat video.')
    elif not active:
        messages.append('COOKIES DOUYIN DA HET HAN. Can xuat lai tu tab dang phat duoc video.')
    else:
        messages.append('Tep doc duoc va co cookies con han. Dieu nay KHONG bao dam Douyin chap nhan yeu cau yt-dlp.')
    return messages


def main():
    root = Path(__file__).resolve().parent
    lines = ['KIEM TRA COOKIES DOUYIN - KHONG HIEN GIA TRI COOKIES']
    try:
        lines.append('Phien ban yt-dlp: ' + importlib.metadata.version('yt-dlp'))
    except importlib.metadata.PackageNotFoundError:
        lines.append('yt-dlp: CHUA CAI TRONG PYTHON DANG DUNG')
    configured = os.environ.get('YTDLP_COOKIES_FILE', '').strip()
    if configured:
        path = Path(configured).expanduser().resolve()
        lines.append('Dang dung duong dan tu YTDLP_COOKIES_FILE.')
    else:
        path = root / 'cookies.txt'
        lines.append('Kiem tra cookies.txt canh tool. Bien YTDLP_COOKIES_FILE chua dat trong cua so nay.')
    if not path.is_file() and (root / 'cookies.txt.txt').is_file():
        lines.append('PHAT HIEN cookies.txt.txt: can doi ten thanh cookies.txt.')
    lines.extend(inspect_cookie_file(path))
    lines.append('Ket qua nay chi chua trang thai va so luong. KHONG gui tep cookies.txt.')
    report = '\n'.join(lines) + '\n'
    print(report)
    (root / 'ket_qua_kiem_tra.txt').write_text(report, encoding='utf-8')
    print('Da luu ket_qua_kiem_tra.txt. Co the gui tep ket qua nay de kiem tra tiep.')


if __name__ == '__main__':
    main()
