"""Offline, non-destructive logo/text masking for locally available video.

FFmpeg delogo estimates the background within user-selected rectangles; it
cannot reconstruct information that is absent from the underlying video.
"""
from __future__ import annotations

import json
import math
import re
import shutil
import subprocess
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from fastapi import HTTPException
from pydantic import BaseModel, Field, model_validator


class Mask(BaseModel):
    x: float = Field(ge=0, le=1)
    y: float = Field(ge=0, le=1)
    w: float = Field(gt=0, le=1)
    h: float = Field(gt=0, le=1)
    start: float = Field(default=0, ge=0)
    end: float | None = Field(default=None, gt=0)

    @model_validator(mode="after")
    def check(self):
        vals = (self.x, self.y, self.w, self.h, self.start)
        if not all(math.isfinite(v) for v in vals) or (self.end is not None and not math.isfinite(self.end)):
            raise ValueError("Toạ độ và thời gian phải là số hữu hạn.")
        if self.x + self.w > 1.00001 or self.y + self.h > 1.00001:
            raise ValueError("Vùng xoá nằm ngoài khung hình.")
        if self.end is not None and self.end <= self.start:
            raise ValueError("Thời gian kết thúc phải lớn hơn thời gian bắt đầu.")
        return self


class CleanRequest(BaseModel):
    source_id: str
    masks: list[Mask] = Field(min_length=1, max_length=20)
    quality: str = "standard"

    @model_validator(mode="after")
    def quality_check(self):
        if self.quality not in ("standard", "high"):
            raise ValueError("Chất lượng xuất không hợp lệ.")
        return self


def ffprobe_info(path: Path) -> dict:
    if not shutil.which('ffprobe'):
        raise RuntimeError("Không tìm thấy ffprobe. Hãy cài FFmpeg và mở lại tool.")
    cmd = ["ffprobe", "-v", "error", "-show_entries",
           "stream=codec_type,width,height:format=duration", "-of", "json", str(path)]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=35, check=True)
        data = json.loads(p.stdout)
        stream = next(x for x in data.get("streams", []) if x.get("codec_type") == "video")
        width, height = int(stream["width"]), int(stream["height"])
        duration = float(data.get("format", {}).get("duration") or 0)
        if width < 16 or height < 16 or duration <= 0 or not math.isfinite(duration):
            raise ValueError("Không đọc được kích thước hoặc thời lượng video.")
    except (subprocess.SubprocessError, OSError, ValueError, KeyError, StopIteration) as exc:
        raise RuntimeError("Không đọc được video bằng FFprobe. Tệp có thể bị hỏng hoặc sai định dạng.") from exc
    return {"width": width, "height": height, "duration": round(duration, 3),
            "has_audio": any(x.get("codec_type") == "audio" for x in data.get("streams", []))}


def frame_jpeg(path: Path, second: float, duration: float) -> bytes:
    if not math.isfinite(second) or second < 0 or second >= duration:
        raise HTTPException(422, "Thời điểm xem trước không nằm trong video.")
    cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-ss", str(round(second, 2)),
           "-i", str(path), "-an", "-frames:v", "1",
           "-vf", "scale=w='min(960,iw)':h=-2", "-q:v", "3", "-f", "image2pipe", "-"]
    try:
        p = subprocess.run(cmd, capture_output=True, check=True, timeout=45)
        if not p.stdout.startswith(b"\xff\xd8"):
            raise RuntimeError("Không trích xuất được ảnh xem trước.")
        return p.stdout
    except (subprocess.SubprocessError, OSError) as exc:
        raise RuntimeError("Lỗi khi trích xuất khung hình xem trước.") from exc


def mask_filter(masks: list[Mask], width: int, height: int, duration: float) -> str:
    filters = []
    for mask in masks:
        # Protect the boundary pixels that delogo uses for interpolation.
        x = max(1, min(width - 5, int(mask.x * width)))
        y = max(1, min(height - 5, int(mask.y * height)))
        w = max(4, min(width - x - 1, round(mask.w * width)))
        h = max(4, min(height - y - 1, round(mask.h * height)))
        if mask.start >= duration:
            raise HTTPException(422, "Thời gian bắt đầu vượt quá thời lượng video.")
        if mask.end is not None and mask.end > duration + .1:
            raise HTTPException(422, "Thời gian kết thúc vượt quá thời lượng video.")
        # No timeline is needed for a region applied throughout the video.
        timeline = ''
        if mask.start > 0 or (mask.end is not None and mask.end < duration - .1):
            until = min(duration, mask.end) if mask.end is not None else duration
            # Filtergraph commas require escaping, quotations are handled by ffmpeg itself.
            timeline = f":enable='between(t,{mask.start:.3f},{until:.3f})'"
        filters.append(f"delogo=x={x}:y={y}:w={w}:h={h}:show=0{timeline}")
    return ",".join(filters)


class CleanerManager:
    def __init__(self, directory: Path, workers: int = 1):
        self.directory = directory
        self.directory.mkdir(parents=True, exist_ok=True)
        self.pool = ThreadPoolExecutor(max_workers=workers)
        self.lock = threading.RLock()
        self.jobs: dict[str, dict] = {}

    def enqueue(self, source_path: Path, source_id: str, req: CleanRequest, media: dict) -> str:
        if not shutil.which("ffmpeg"):
            raise HTTPException(503, "Chưa tìm thấy FFmpeg trong PATH.")
        filt = mask_filter(req.masks, media["width"], media["height"], media["duration"])
        task_id = str(uuid.uuid4())
        with self.lock:
            self.jobs[task_id] = {"id": task_id, "status": "queued", "progress": 0,
                                  "phase": "Chờ xử lý...", "error": None, "filename": None,
                                  "path": None, "source_id": source_id}
        self.pool.submit(self._work, task_id, source_path, filt, req.quality, media["duration"])
        return task_id

    def get(self, task_id: str) -> dict:
        with self.lock:
            item = self.jobs.get(task_id)
            if not item:
                raise HTTPException(404, "Không tìm thấy lượt xử lý logo/chữ.")
            return {k: v for k, v in item.items() if k != 'path'}

    def _update(self, task_id: str, **updates):
        with self.lock:
            self.jobs[task_id].update(updates)

    def output_path(self, task_id: str) -> Path:
        self.get(task_id)
        with self.lock:
            job = self.jobs[task_id]
            if job["status"] != "done":
                raise HTTPException(409, "Video chưa xử lý xong.")
            path = Path(job["path"])
        if not path.is_file() or path.parent.resolve() != (self.directory / task_id).resolve():
            raise HTTPException(404, "Không tìm thấy video đã xử lý.")
        return path

    def _work(self, task_id: str, source_path: Path, video_filter: str, quality: str, duration: float):
        folder = self.directory / task_id
        folder.mkdir(parents=True, exist_ok=True)
        output = folder / "video_da_xoa_logo_chu.mp4"
        crf, preset = (18, "medium") if quality == "high" else (23, "veryfast")
        cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostats", "-y",
               "-i", str(source_path), "-map", "0:v:0", "-map", "0:a?",
               "-vf", video_filter, "-c:v", "libx264", "-preset", preset, "-crf", str(crf),
               "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k",
               "-movflags", "+faststart", "-progress", "pipe:1", str(output)]
        self._update(task_id, status="processing", phase="Đang xử lý các vùng logo/chữ...")
        errors: list[str] = []
        try:
            with subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                  text=True, encoding="utf-8", errors="replace", bufsize=1) as process:
                assert process.stdout is not None
                for raw in process.stdout:
                    line = raw.strip()
                    if line.startswith("out_time="):
                        hms = line.split("=", 1)[1]
                        try:
                            h, m, sec = hms.split(":")
                            current = int(h) * 3600 + int(m) * 60 + float(sec)
                            pct = max(0, min(99.9, round(current * 100 / duration, 1)))
                            self._update(task_id, progress=pct,
                                         phase=f"Đang làm sạch video... {pct}%")
                        except (ValueError, ZeroDivisionError):
                            pass
                    elif line and not line.startswith(("frame=", "fps=", "stream_", "bitrate=", "total_size=", "out_time_ms=", "out_time_us=", "dup_frames=", "drop_frames=", "speed=", "progress=")):
                        errors.append(line[-280:])
                        errors[:] = errors[-5:]
                return_code = process.wait()
            if return_code != 0 or not output.is_file() or not output.stat().st_size:
                raise RuntimeError("; ".join(errors[-3:]) or f"FFmpeg kết thúc với mã lỗi {return_code}.")
            self._update(task_id, status="done", phase="Hoàn tất – giữ âm thanh nếu nguồn có",
                         progress=100, filename=output.name, path=str(output))
        except Exception as exc:
            output.unlink(missing_ok=True)
            msg = re.sub(r"\s+", " ", str(exc))[:320]
            self._update(task_id, status="error", phase="Xử lý thất bại", error=msg)
