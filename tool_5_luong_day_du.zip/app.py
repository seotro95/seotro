"""Local Vietnamese Douyin/Bilibili video downloader.

For videos you own or have permission to download. No DRM bypass or paywall circumvention.
"""
from __future__ import annotations

import os
import re
import shutil
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

from fastapi import FastAPI, HTTPException, UploadFile, File, Query
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from starlette.concurrency import run_in_threadpool
from cleaner import CleanRequest, CleanerManager, ffprobe_info, frame_jpeg

BASE_DIR = Path(__file__).resolve().parent
DOWNLOAD_DIR = Path(os.environ.get("VIDEO_DOWNLOAD_DIR", str(BASE_DIR / "downloads"))).resolve()
DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
ALLOWED_HOSTS = {
    "bilibili.com", "www.bilibili.com", "m.bilibili.com", "b23.tv", "www.b23.tv",
    "douyin.com", "www.douyin.com", "v.douyin.com", "iesdouyin.com", "www.iesdouyin.com",
}
QUALITY_CHOICES = (360, 480, 720, 1080, 1440, 2160)


def validate_url(value: str) -> str:
    """Extract one supported HTTPS URL from a link or copied share text."""
    if not isinstance(value, str) or len(value) > 8192:
        raise HTTPException(422, "Nội dung liên kết quá dài hoặc không hợp lệ.")
    # Share captions can surround the URL with quotes, brackets or Chinese punctuation.
    candidates = re.findall(r"https?://[^\s<>\"'“”‘’（）()【】\[\]，。；！、]+", value.strip(), flags=re.IGNORECASE)
    valid = []
    search_error = None
    for candidate in candidates:
        candidate = candidate.rstrip(".,;!?")
        try:
            parsed = urlsplit(candidate)
            host = (parsed.hostname or "").lower().rstrip(".")
            if (parsed.scheme != "https" or host not in ALLOWED_HOSTS or
                    parsed.port not in (None, 443) or parsed.username or parsed.password):
                continue
            if (not parsed.path.strip("/") or len(candidate) > 2048 or
                    any(ord(char) < 32 or ord(char) == 127 for char in candidate) or
                    "\\" in candidate):
                continue
        except (ValueError, TypeError):
            continue
        if host in {"douyin.com", "www.douyin.com"} and (parsed.path == "/search" or parsed.path.startswith("/search/")):
            ids = parse_qs(parsed.query, keep_blank_values=True).get("modal_id", [])
            if len(ids) != 1 or not re.fullmatch(r"[1-9][0-9]{0,19}", ids[0]):
                search_error = "Link tìm kiếm chưa xác định một video. Hãy mở video và sao chép link bằng nút Chia sẻ."
                continue
            candidate = "https://www.douyin.com/video/" + ids[0]
        if candidate not in valid:
            valid.append(candidate)
    if not valid:
        if search_error:
            raise HTTPException(422, search_error)
        raise HTTPException(422, "Không tìm thấy link HTTPS Douyin hoặc Bilibili hợp lệ trong nội dung đã dán.")
    if len(valid) > 1:
        raise HTTPException(422, "Có nhiều liên kết video. Hãy chỉ dán một liên kết cần tải.")
    return valid[0]


def require_ytdlp():
    try:
        import yt_dlp
        return yt_dlp
    except ImportError as exc:
        raise RuntimeError("Chưa cài yt-dlp. Hãy chạy script cài đặt trước.") from exc


def ydl_options(extra: dict | None = None) -> dict:
    opts = {
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "socket_timeout": 35,
        "retries": 15,
        "fragment_retries": 15,
        "extractor_retries": 5,
        "file_access_retries": 5,
        # Larger chunks reduce HTTP request overhead while keeping resumable transfers.
        # Fragment concurrency applies only when the source supplies fragments.
        "http_chunk_size": 8 * 1024 * 1024,
        "continuedl": True,
        "nopart": False,
        "overwrites": False,
        "concurrent_fragment_downloads": 5,
        "retry_sleep_functions": {
            "http": lambda n: min(2 ** min(max(n - 1, 0), 4), 16),
            "fragment": lambda n: min(2 ** min(max(n - 1, 0), 4), 16),
            "extractor": lambda n: min(2 ** min(max(n - 1, 0), 4), 16),
        },
    }
    cookie_file = os.environ.get("YTDLP_COOKIES_FILE", "").strip()
    if cookie_file:
        path = Path(cookie_file).expanduser().resolve()
        if not path.is_file():
            raise RuntimeError("YTDLP_COOKIES_FILE không trỏ đến tệp cookies hợp lệ.")
        opts["cookiefile"] = str(path)
    if extra:
        opts.update(extra)
    return opts


def first_video(info: dict) -> dict:
    if info.get("_type") in ("playlist", "multi_video"):
        entries = iter(info.get("entries") or ())
        info = next(entries, None)
        if not isinstance(info, dict):
            raise RuntimeError("Không tìm thấy video trong liên kết này.")
    return info


def inspect_video(url: str) -> dict:
    url = validate_url(url)
    yt_dlp = require_ytdlp()
    with yt_dlp.YoutubeDL(ydl_options({"skip_download": True})) as ydl:
        info = first_video(ydl.extract_info(validate_url(url), download=False))
    formats = info.get("formats") or []
    heights = sorted({int(f["height"]) for f in formats
                      if f.get("height") and f.get("vcodec", "none") != "none"})
    if not heights and info.get("height"):
        heights = [int(info["height"])]
    return {
        "title": str(info.get("title") or "Không có tiêu đề")[:200],
        "platform": "Bilibili" if "bili" in urlsplit(url).hostname.lower() or "b23.tv" in url else "Douyin",
        "duration": info.get("duration"),
        "thumbnail": info.get("thumbnail") or "",
        "available_heights": heights,
        "has_audio": any(f.get("acodec", "none") != "none" for f in formats)
                     or info.get("acodec", "none") != "none",
    }


class AnalyzeRequest(BaseModel):
    url: str = Field(min_length=8, max_length=8192)


class DownloadRequest(AnalyzeRequest):
    quality: int = 1080


class DownloadManager:
    def __init__(self, directory: Path = DOWNLOAD_DIR, workers: int = 5):
        self.directory = directory
        self.directory.mkdir(parents=True, exist_ok=True)
        self.jobs: dict[str, dict] = {}
        self.lock = threading.RLock()
        self.workers = workers
        self.pool = ThreadPoolExecutor(max_workers=workers)

    def update(self, job_id: str, **changes) -> None:
        with self.lock:
            self.jobs[job_id].update(changes)

    def get(self, job_id: str) -> dict:
        with self.lock:
            job = self.jobs.get(job_id)
            if not job:
                raise HTTPException(404, "Không tìm thấy lượt tải.")
            return {k: v for k, v in job.items() if k not in ("path", "url")}

    def enqueue(self, url: str, quality: int) -> str:
        url = validate_url(url)
        if quality not in QUALITY_CHOICES:
            raise HTTPException(422, "Chất lượng phải thuộc 360p, 480p, 720p, 1080p, 1440p hoặc 4K.")
        job_id = str(uuid.uuid4())
        with self.lock:
            self.jobs[job_id] = {
                "id": job_id, "url": url, "quality": quality,
                "status": "queued", "phase": "Đang xếp hàng", "progress": 0,
                "filename": None, "error": None, "path": None,
            }
        self.pool.submit(self._download, job_id)
        return job_id

    def retry(self, job_id: str) -> str:
        """Retry failed transfer in its ORIGINAL folder, keeping any .part files.

        A new job would create a new folder and therefore discard resumability.
        """
        with self.lock:
            job = self.jobs.get(job_id)
            if job is None:
                raise HTTPException(404, "Không tìm thấy lượt tải.")
            if job["status"] != "error":
                raise HTTPException(409, "Chỉ tải tiếp được lượt tải đang báo lỗi.")
            job.update(status="queued", phase="Đang thử tải tiếp phần còn thiếu...",
                       error=None, filename=None, path=None)
        self.pool.submit(self._download, job_id)
        return job_id

    def _download(self, job_id: str) -> None:
        with self.lock:
            job = dict(self.jobs[job_id])
        folder = self.directory / job_id
        folder.mkdir(parents=True, exist_ok=True)
        progress_stream = {"name": None, "index": 0}

        def on_progress(data):
            state = data.get("status")
            if state == "downloading":
                name = data.get("filename") or data.get("tmpfilename") or ""
                if name and progress_stream["name"] != name:
                    progress_stream["name"] = name
                    progress_stream["index"] += 1
                received = data.get("downloaded_bytes") or 0
                total = data.get("total_bytes") or data.get("total_bytes_estimate") or 0
                pct = round(received * 100 / total, 1) if total else 0
                self.update(job_id, status="downloading", progress=min(100, pct),
                            phase=f"Đang tải luồng {progress_stream['index'] or 1}" +
                                  (" (đang tính dung lượng...)" if not total else ""))
            elif state == "finished":
                self.update(job_id, status="processing", progress=100,
                            phase="Đã tải xong một luồng, đang xử lý/ghép âm thanh...")

        def on_postprocess(data):
            if data.get("status") in ("started", "processing"):
                self.update(job_id, status="processing", phase="Đang ghép video và âm thanh...")

        try:
            if not shutil.which("ffmpeg"):
                raise RuntimeError("Thiếu FFmpeg để ghép video và âm thanh. Hãy cài FFmpeg rồi khởi động lại.")
            yt_dlp = require_ytdlp()
            quality = job["quality"]
            options = ydl_options({
                "format": f"bv[height<={quality}]+ba/b[height<={quality}]",
                "merge_output_format": "mp4",
                "outtmpl": str(folder / "video.%(ext)s"),
                "progress_hooks": [on_progress],
                "postprocessor_hooks": [on_postprocess],
            })
            self.update(job_id, status="downloading", phase="Đang kết nối video...")
            with yt_dlp.YoutubeDL(options) as ydl:
                result = ydl.extract_info(job["url"], download=True)
                if not result:
                    raise RuntimeError("Không lấy được thông tin video.")
            candidates = sorted(
                (p for p in folder.iterdir() if p.is_file() and p.suffix.lower() in (".mp4", ".mkv", ".webm")),
                key=lambda p: p.stat().st_size, reverse=True,
            )
            if not candidates:
                raise RuntimeError("Không có tệp video hoàn tất sau khi tải/ghép.")
            path = candidates[0]
            self.update(job_id, status="done", phase="Hoàn tất – có âm thanh nếu nguồn cung cấp",
                        progress=100, filename=path.name, path=str(path))
        except Exception as exc:
            message = str(exc)
            # Avoid showing traceback, cookie paths, or huge HTML errors to the browser.
            message = re.sub(r"\x1b\[[0-9;]*m", "", message)
            message = re.sub(r"\s+", " ", message)[:320]
            if "fresh cookies" in message.lower():
                message = "Douyin yêu cầu cookies trình duyệt mới. Đặt YTDLP_COOKIES_FILE trỏ tới tệp cookies.txt đã xuất từ trình duyệt, rồi khởi động lại tool. Không gửi tệp cookies cho người khác."
            self.update(job_id, status="error", phase="Đã ngắt kết nối, có thể thử tải tiếp",
                        error=message)


manager = DownloadManager()
cleaner = CleanerManager(DOWNLOAD_DIR / "edited")
app = FastAPI(title="Tải video Douyin & Bilibili - Tiếng Việt", version="1.2.4")
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")


@app.get("/")
def homepage():
    return FileResponse(BASE_DIR / "static" / "index.html", media_type="text/html")


@app.get("/api/health")
def health():
    try:
        require_ytdlp()
        yt_ready = True
    except RuntimeError:
        yt_ready = False
    return {"yt_dlp": yt_ready, "ffmpeg": bool(shutil.which("ffmpeg")),
            "local_only": True, "download_workers": manager.workers,
            "fragment_workers": 5}


@app.post("/api/analyze")
async def analyze(req: AnalyzeRequest):
    url = validate_url(req.url)
    try:
        return await run_in_threadpool(inspect_video, url)
    except HTTPException:
        raise
    except Exception as exc:
        message = re.sub(r"\x1b\[[0-9;]*m", "", str(exc))
        message = re.sub(r"\s+", " ", message)[:240]
        if "fresh cookies" in message.lower():
            message = "Douyin yêu cầu cookies trình duyệt mới. Đặt YTDLP_COOKIES_FILE trỏ tới tệp cookies.txt đã xuất từ trình duyệt, rồi khởi động lại tool. Không gửi tệp cookies cho người khác."
        raise HTTPException(400, f"Không phân tích được link: {message}") from exc


@app.post("/api/download", status_code=202)
def download(req: DownloadRequest):
    return {"job_id": manager.enqueue(req.url, req.quality)}


@app.post("/api/retry/{job_id}", status_code=202)
def retry_download(job_id: str):
    return {"job_id": manager.retry(job_id)}


@app.get("/api/status/{job_id}")
def status(job_id: str):
    return manager.get(job_id)


@app.get("/api/file/{job_id}")
def get_file(job_id: str):
    record = manager.get(job_id)
    if record["status"] != "done":
        raise HTTPException(409, "Video chưa tải xong.")
    with manager.lock:
        p = Path(manager.jobs[job_id]["path"])
    if not p.is_file() or p.parent != manager.directory / job_id:
        raise HTTPException(404, "Tệp đã bị di chuyển hoặc xóa.")
    return FileResponse(p, media_type="application/octet-stream", filename=p.name)


def local_video_path(job_id: str) -> Path:
    with manager.lock:
        job = manager.jobs.get(job_id)
        if job is None:
            raise HTTPException(404, "Không tìm thấy video.")
        if job["status"] != "done":
            raise HTTPException(409, "Video chưa tải xong.")
        p = Path(job["path"])
    # Prevent a future path handling regression from escaping the job directory.
    if not p.is_file() or p.resolve().parent != (manager.directory / job_id).resolve():
        raise HTTPException(404, "Không tìm thấy video trên máy.")
    return p


@app.post("/api/upload", status_code=201)
async def upload_video(file: UploadFile = File(...)):
    """Import an existing local video, without requiring a Bilibili/Douyin download."""
    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in {".mp4", ".mov", ".mkv", ".webm", ".avi"}:
        raise HTTPException(422, "Chỉ hỗ trợ video MP4, MOV, MKV, WEBM hoặc AVI.")
    job_id = str(uuid.uuid4())
    folder = manager.directory / job_id
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / ("video_goc" + suffix)
    count = 0
    limit = 4 * 1024 * 1024 * 1024
    try:
        with target.open("wb") as dest:
            while chunk := await file.read(1024 * 1024):
                count += len(chunk)
                if count > limit:
                    raise HTTPException(413, "Video vượt giới hạn 4 GB.")
                dest.write(chunk)
        media = await run_in_threadpool(ffprobe_info, target)
        with manager.lock:
            manager.jobs[job_id] = {
                "id": job_id, "quality": None, "status": "done", "progress": 100,
                "phase": "Video từ máy tính", "error": None,
                "filename": target.name, "path": str(target), "url": None,
            }
        return {"source_id": job_id, **media}
    except Exception as exc:
        shutil.rmtree(folder, ignore_errors=True)
        if isinstance(exc, HTTPException):
            raise
        raise HTTPException(422, f"Không nhập được video: {str(exc)[:200]}") from exc
    finally:
        await file.close()


@app.get("/api/source/{source_id}")
async def source_metadata(source_id: str):
    path = local_video_path(source_id)
    try:
        return await run_in_threadpool(ffprobe_info, path)
    except RuntimeError as exc:
        raise HTTPException(422, str(exc)) from exc


@app.get("/api/frame/{source_id}")
async def video_frame(source_id: str, at: float = Query(default=0, ge=0)):
    path = local_video_path(source_id)
    try:
        media = await run_in_threadpool(ffprobe_info, path)
        frame = await run_in_threadpool(frame_jpeg, path, at, media["duration"])
        return Response(content=frame, media_type="image/jpeg", headers={"Cache-Control": "no-store"})
    except RuntimeError as exc:
        raise HTTPException(422, str(exc)) from exc


@app.post("/api/clean", status_code=202)
async def clean_video(req: CleanRequest):
    path = local_video_path(req.source_id)
    try:
        media = await run_in_threadpool(ffprobe_info, path)
        return {"job_id": cleaner.enqueue(path, req.source_id, req, media)}
    except RuntimeError as exc:
        raise HTTPException(422, str(exc)) from exc


@app.get("/api/clean/status/{job_id}")
def clean_status(job_id: str):
    return cleaner.get(job_id)


@app.get("/api/clean/file/{job_id}")
def clean_file(job_id: str):
    path = cleaner.output_path(job_id)
    return FileResponse(path, media_type="video/mp4", filename=path.name)
