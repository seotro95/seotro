"""Observe local aria2 progress without exposing RPC authentication or cookies."""
import json
import socket
import threading
import urllib.request
import uuid

class AriaProgress:
    def __init__(self,on_progress):
        with socket.socket() as sock:
            sock.bind(('127.0.0.1',0));self.port=sock.getsockname()[1]
        self.secret=uuid.uuid4().hex
        self.on_progress=on_progress
        self.error=False
        self.completed=False
        self.process=None
        self.stop=threading.Event()
        self.thread=threading.Thread(target=self._watch,daemon=True)
        self.args=['-x4','-s4','-j1','--min-split-size=4M','--max-tries=3','--retry-wait=2',
                   '--connect-timeout=10','--timeout=15','--check-certificate=true','--http-accept-gzip=false',
                   '--enable-rpc=true','--rpc-listen-all=false',f'--rpc-listen-port={self.port}',
                   f'--rpc-secret={self.secret}']

    def __enter__(self):
        self.thread.start();return self

    def __exit__(self,*args):
        self.stop.set();self.thread.join(timeout=2)

    def _watch(self):
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
        while not self.stop.wait(.5):
            try:
                body=json.dumps({'jsonrpc':'2.0','id':'progress','method':'aria2.tellActive',
                                 'params':['token:'+self.secret,['gid','completedLength','totalLength','downloadSpeed','status']]}).encode()
                request=urllib.request.Request(f'http://127.0.0.1:{self.port}/jsonrpc',data=body,
                                               headers={'Content-Type':'application/json'})
                with opener.open(request,timeout=1) as response:
                    active=json.load(response).get('result') or []
                if not active:
                    body=json.dumps({'jsonrpc':'2.0','id':'done','method':'aria2.tellStopped',
                                     'params':['token:'+self.secret,0,10,['status','errorCode']]}).encode()
                    request=urllib.request.Request(f'http://127.0.0.1:{self.port}/jsonrpc',data=body,
                                                   headers={'Content-Type':'application/json'})
                    with opener.open(request,timeout=1) as response:
                        stopped=json.load(response).get('result') or []
                    if stopped:
                        self.error=any(x.get('status')!='complete' for x in stopped)
                        self.completed=not self.error
                        if self.completed and self.process is not None:
                            if self.process.poll() is None:self.process.terminate()
                            return
                        body=json.dumps({'jsonrpc':'2.0','id':'shutdown','method':'aria2.forceShutdown' if self.completed else 'aria2.shutdown',
                                         'params':['token:'+self.secret]}).encode()
                        request=urllib.request.Request(f'http://127.0.0.1:{self.port}/jsonrpc',data=body,
                                                       headers={'Content-Type':'application/json'})
                        with opener.open(request,timeout=1) as response:response.read()
                        return
                for item in active:
                    done=int(item.get('completedLength') or 0)
                    total=int(item.get('totalLength') or 0)
                    speed=int(item.get('downloadSpeed') or 0)
                    self.on_progress({'status':'downloading','filename':'aria2:'+item['gid'],
                                      'downloaded_bytes':done,'total_bytes':total,'speed':speed,
                                      'eta':round((total-done)/speed) if speed and total else None})
            except Exception:
                # The aria2 process can be starting, between streams, or already stopped.
                pass


def make_fast_ytdlp(base):
    import shutil
    import subprocess
    import re
    import xml.etree.ElementTree as ET
    from pathlib import Path
    from yt_dlp.networking import Request
    from yt_dlp.downloader.external import Aria2cFD

    class ObservedAriaFD(Aria2cFD):
        @classmethod
        def get_basename(cls):
            return 'aria2c'

        def _call_downloader(self,tmpfilename,info_dict):
            with AriaProgress(lambda data:self._hook_progress(data,info_dict)) as monitor:
                self.params=dict(self.params,external_downloader_args={'aria2c':monitor.args})
                info_dict=dict(info_dict,http_headers={**(info_dict.get('http_headers') or {}),'Accept-Encoding':'identity'})
                command=self._make_cmd(tmpfilename,info_dict)
                size=info_dict.get('filesize')
                if not size:
                    try:
                        headers={**info_dict['http_headers'],'Range':'bytes=0-0'}
                        with self.ydl.urlopen(Request(info_dict['url'],headers=headers)) as response:
                            encoded=response.headers.get('Content-Encoding','').lower()
                            matched=re.fullmatch(r'bytes 0-0/(\d+)',response.headers.get('Content-Range',''))
                            if encoded in ('','identity'):
                                size=int(matched.group(1)) if matched else int(response.headers.get('Content-Length',0)) if response.status==200 else None
                    except Exception:
                        size=None
                metadata=None
                if isinstance(size,(int,float)) and 0<size<1024**4:
                    # Knowing the total size lets aria2 bound the first range instead
                    # of fetching an entire primary response while peers fetch its tail.
                    root=ET.Element('metalink',xmlns='urn:ietf:params:xml:ns:metalink')
                    file=ET.SubElement(root,'file',name=Path(tmpfilename).name)
                    ET.SubElement(file,'size').text=str(int(size))
                    ET.SubElement(file,'url').text=info_dict['url']
                    metadata=ET.tostring(root,encoding='utf-8',xml_declaration=True)
                    command=command[:-2]+['--metalink-file=-']
                with subprocess.Popen(command,stdin=subprocess.PIPE if metadata else subprocess.DEVNULL,
                                      stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL) as process:
                    monitor.process=process
                    try:
                        if metadata:
                            process.stdin.write(metadata);process.stdin.close()
                        code=process.wait(timeout=1800)
                    finally:
                        if process.poll() is None:
                            process.kill();process.wait()
                # RPC shutdown can return zero even when the media task failed.
                # Report failure BEFORE ExternalFD can rename an incomplete .part file.
                return 0 if monitor.completed and not monitor.error else code if code else 1

    class FastYoutubeDL(base):
        def dl(self,name,info,subtitle=False,test=False):
            binary=shutil.which('aria2c')
            if not binary or subtitle or test or info.get('requested_formats') or info.get('protocol') not in ('http','https'):
                return super().dl(name,info,subtitle=subtitle,test=test)
            downloader=ObservedAriaFD(self,self.params)
            downloader.exe=binary
            for hook in self._progress_hooks:downloader.add_progress_hook(hook)
            candidate=self._copy_infodict(info)
            if candidate.get('http_headers') is None:
                candidate['http_headers']=self._calc_headers(candidate)
            return downloader.download(name,candidate,subtitle)
    return FastYoutubeDL
