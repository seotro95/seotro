@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo Chua co moi truong Python. Chay cai_dat.bat truoc.
    pause
    exit /b 1
)
".venv\Scripts\python.exe" kiem_tra_cookies.py
pause
