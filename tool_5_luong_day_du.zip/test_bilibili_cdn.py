import functools
import http.server
import tempfile
import threading
import unittest
from pathlib import Path
from bilibili_cdn import backup_map, make_ytdlp

class BackupTests(unittest.TestCase):
    def test_only_official_https_backups_for_same_stream(self):
        primary='https://main.bilivideo.com/video.m4s'
        data={'dash':{'video':[{'baseUrl':primary,'backupUrl':[
            'https://backup.bilivideo.com/video.m4s','https://backup.bilivideo.com/video.m4s',
            'https://127.0.0.1/private','https://evil.example/video','http://backup.bilivideo.com/video',
            'https://user:pass@backup.bilivideo.com/video',primary]}]}}
        self.assertEqual(backup_map(data),{primary:['https://backup.bilivideo.com/video.m4s']})

    def test_extractor_preserves_backups_and_format_metadata(self):
        import yt_dlp
        from app import format_selector
        primary='https://main.bilivideo.com/video-80.m4s?test=1'
        backup='https://backup.bilivideo.com/video-80.m4s?test=1'
        play={'dash':{'video':[{'id':80,'baseUrl':primary,'backupUrl':[backup],
                              'mimeType':'video/mp4','codecs':'avc1','width':1920,'height':1080}]}}
        YDL=make_ytdlp(yt_dlp)
        with YDL({'quiet':True,'format':format_selector(2160)}) as y:
            formats=y.get_info_extractor('BiliBili').extract_formats(play)
            self.assertEqual(formats[0]['_bili_backup_urls'],[backup])
            self.assertEqual(formats[0]['width'],1920)
            result=y.process_ie_result({'id':'test','title':'test','formats':formats},download=False)
            self.assertEqual(result['_bili_backup_urls'],[backup])

    def test_real_primary_503_falls_back_without_changing_output(self):
        import yt_dlp
        requests=[]
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);source=root/'source.mp4';source.write_bytes(b'test-video-bytes'*4096)
            class Handler(http.server.SimpleHTTPRequestHandler):
                def log_message(self,*args):pass
                def do_GET(self):
                    requests.append(self.path)
                    if self.path=='/failed.mp4':
                        self.send_response(503);self.end_headers();return
                    super().do_GET()
            server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=d))
            threading.Thread(target=server.serve_forever,daemon=True).start()
            base=f'http://127.0.0.1:{server.server_port}'
            class Logger:
                def debug(self,*args):pass
                def warning(self,*args):pass
                def error(self,*args):pass
            attempts=[];YDL=make_ytdlp(yt_dlp,attempts.append)
            output=root/'video.mp4';part=root/'video.mp4.part';part.write_bytes(source.read_bytes()[:1024])
            try:
                with YDL({'quiet':True,'noprogress':True,'retries':0,'continuedl':True,
                          'nopart':False,'logger':Logger()}) as y:
                    result=y.dl(str(output),{'url':base+'/failed.mp4','protocol':'http','ext':'mp4',
                                            '_bili_backup_urls':[base+'/source.mp4']})
                    self.assertTrue(result[0]);self.assertEqual(y._download_retcode,0)
                self.assertEqual(output.read_bytes(),source.read_bytes())
                self.assertEqual(attempts,[1])
                self.assertIn('/failed.mp4',requests);self.assertIn('/source.mp4',requests)
            finally:
                server.shutdown();server.server_close()

    def test_all_backups_fail_reports_failure(self):
        from unittest.mock import patch
        import yt_dlp
        from yt_dlp.utils import DownloadError
        YDL=make_ytdlp(yt_dlp)
        with YDL({'quiet':True}) as y, patch.object(yt_dlp.YoutubeDL,'dl',side_effect=DownloadError('network failure')) as dl:
            with self.assertRaises(DownloadError):
                y.dl('video.mp4',{'url':'https://a.bilivideo.com/v','_bili_backup_urls':['https://b.bilivideo.com/v']})
            self.assertEqual(dl.call_count,2)

if __name__=='__main__':unittest.main()
