@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ========================================
echo  CAI DAT TOOL DOUYIN - BILIBILI
 echo ========================================
where py >nul 2>&1
if %errorlevel% equ 0 (
    py -3 -m venv .venv
) else (
    python -m venv .venv
)
if errorlevel 1 (
    echo LOI: Chua cai Python 3.10+ hoac tao moi truong that bai.
    pause
    exit /b 1
)
call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip
if errorlevel 1 goto fail
python -m pip install --upgrade -r requirements.txt
if errorlevel 1 goto fail
where ffmpeg >nul 2>&1
if errorlevel 1 (
    echo.
    echo CANH BAO: Chua co FFmpeg. Cai bang lenh: winget install Gyan.FFmpeg
    echo Sau khi cai hay dong cua so CMD va mo lai.
) else (
    echo FFmpeg: OK
)
echo.
echo CAI DAT THANH CONG. Chay khoi_dong.bat de mo web.
pause
exit /b 0
:fail
echo CAI DAT THAT BAI. Kiem tra ket noi Internet, Python va pip.
pause
exit /b 1
