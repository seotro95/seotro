"""Bound extractor/download work in killable processes; do not log credentials."""
from __future__ import annotations
import json
import os
import queue
import signal
import subprocess
import sys
import threading
import time
from pathlib import Path


class WorkerCancelled(RuntimeError):
    pass


def stop_process(process):
    if process.poll() is not None:
        return
    if os.name == 'nt':
        subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    else:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    if process.poll() is None:
        process.kill()
    process.wait(timeout=10)


def run_in_worker(payload, on_update=None, *, start_timeout=60, idle_timeout=120,
                  max_seconds=1800, worker_path=None, cancel_event=None):
    if cancel_event is not None and cancel_event.is_set():
        raise WorkerCancelled("Đã dừng theo yêu cầu.")
    script = Path(worker_path) if worker_path else Path(__file__).resolve()
    kwargs = {'start_new_session': True} if os.name != 'nt' else {
        'creationflags': subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_NO_WINDOW}
    events = queue.Queue()
    started = last_activity = time.monotonic()
    transfer_started = processing = False
    previous_bytes = 0
    with subprocess.Popen([sys.executable, str(script)], stdin=subprocess.PIPE,
                          stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                          text=True, encoding='utf-8', **kwargs) as process:
        def read_output():
            try:
                for line in process.stdout:
                    try:
                        event = json.loads(line)
                        if isinstance(event, dict):
                            events.put(event)
                    except (ValueError, TypeError):
                        pass
            finally:
                events.put(None)
        reader = threading.Thread(target=read_output, daemon=True)
        reader.start()
        try:
            process.stdin.write(json.dumps(payload) + '\n')
            process.stdin.close()
            while True:
                if cancel_event is not None and cancel_event.is_set():
                    raise WorkerCancelled("Đã dừng theo yêu cầu.")
                now = time.monotonic()
                if now - started > max_seconds:
                    raise TimeoutError('Lượt tải vượt thời gian tối đa. Đã dừng; có thể thử tải tiếp tệp .part.')
                if payload['action'] == 'analyze' and now - started > start_timeout:
                    raise TimeoutError('Nguồn không trả thông tin trong 45 giây. Đã dừng phân tích; hãy kiểm tra link hoặc thử lại sau.')
                if payload['action'] == 'download':
                    limit = 300 if processing else idle_timeout if transfer_started else start_timeout
                    if now - last_activity > limit:
                        raise TimeoutError('Nguồn không gửi thêm dữ liệu trong thời gian cho phép. Đã dừng; có thể thử tải tiếp tệp .part.')
                try:
                    event = events.get(timeout=.2)
                except queue.Empty:
                    continue
                if event is None:
                    raise RuntimeError('Tiến trình tải kết thúc mà chưa có kết quả. Kiểm tra cài đặt và thử lại.')
                kind = event.get('kind')
                if kind == 'update':
                    changes = event['changes']
                    # Connection status alone is not evidence of download activity.
                    if 'received_bytes' in changes:
                        received = changes['received_bytes']
                        if received > 0 and received != previous_bytes:
                            transfer_started = True
                            last_activity = time.monotonic()
                        previous_bytes = received
                        processing = False
                    if changes.get('status') == 'processing':
                        processing = True
                        last_activity = time.monotonic()
                    if on_update:
                        on_update(changes)
                elif kind == 'result':
                    return event['result']
                elif kind == 'error':
                    raise RuntimeError(event['message'])
        finally:
            stop_process(process)
            reader.join(timeout=2)


def emit(event):
    print(json.dumps(event, ensure_ascii=True), flush=True)


def main():
    payload = json.loads(sys.stdin.readline())
    import app
    if payload['action'] == 'analyze':
        try:
            emit({'kind': 'result', 'result': app.inspect_video_direct(payload['url'])})
        except Exception as exc:
            emit({'kind': 'error', 'message': app.extractor_error_message(exc)})
    else:
        manager = app.DownloadManager(Path(payload['directory']))
        job_id = payload['job_id']
        manager.jobs[job_id] = {'id': job_id, 'url': payload['url'], 'quality': payload['quality']}
        original = manager.update
        def update(job_id, **changes):
            original(job_id, **changes)
            emit({'kind': 'update', 'changes': changes})
        manager.update = update
        manager._download_direct(job_id)
        job = manager.jobs[job_id]
        if job['status'] == 'error':
            emit({'kind': 'error', 'message': job['error']})
        else:
            emit({'kind': 'result', 'result': {k: job[k] for k in
                  ('status', 'phase', 'progress', 'filename', 'path')}})


if __name__ == '__main__':
    main()
