@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "VIDEO_FOLDER=%~dp0downloads"
if defined VIDEO_DOWNLOAD_DIR set "VIDEO_FOLDER=%VIDEO_DOWNLOAD_DIR%"
if not exist "%VIDEO_FOLDER%" mkdir "%VIDEO_FOLDER%"
if not exist "%VIDEO_FOLDER%" (
    echo Khong tao duoc thu muc video. Kiem tra duong dan va quyen ghi.
    pause
    exit /b 1
)
start "" explorer.exe "%VIDEO_FOLDER%"
