"""Test actual backend definitions without the unavailable cleaner/static modules."""
import ast
import asyncio
import re
import unittest
from pathlib import Path
from urllib.parse import urlsplit
from unittest.mock import MagicMock
from fastapi import HTTPException
from pydantic import BaseModel, Field

source = ast.parse(Path(__file__).with_name('app.py').read_text())
keep = {'ydl_options', 'ALLOWED_HOSTS', 'validate_url', 'AnalyzeRequest', 'DownloadRequest', 'inspect_video', 'analyze', 'DownloadManager'}
nodes = [node for node in source.body if
         getattr(node, 'name', None) in keep or
         isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id in keep for t in node.targets)]
# Route decorators need the running app; the handler itself remains unchanged.
for node in nodes:
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        node.decorator_list = []
ns = dict(re=re, urlsplit=urlsplit, HTTPException=HTTPException,
          BaseModel=BaseModel, Field=Field, Path=Path, DOWNLOAD_DIR=Path('/tmp'))
exec(compile(ast.Module(body=nodes, type_ignores=[]), 'app.py', 'exec'), ns)
validate = ns['validate_url']
original_options = ns['ydl_options']

class ShareLinkTests(unittest.TestCase):
    def test_parallel_download_limit_and_queue(self):
        import threading, uuid, tempfile
        from concurrent.futures import ThreadPoolExecutor
        ns.update(threading=threading, uuid=uuid, ThreadPoolExecutor=ThreadPoolExecutor,
                  QUALITY_CHOICES=(1080,))
        release = threading.Event()
        all_started = threading.Event()
        started = []
        lock = threading.Lock()
        with tempfile.TemporaryDirectory() as directory:
            manager = ns['DownloadManager'](Path(directory))
            def fake_download(job_id):
                with lock:
                    started.append(job_id)
                    if len(started) == 5:
                        all_started.set()
                if not release.wait(10):
                    raise RuntimeError('Test did not release workers')
            manager._download = fake_download
            try:
                jobs = [manager.enqueue(f'https://v.douyin.com/id{i}', 1080) for i in range(6)]
                self.assertTrue(all_started.wait(5), 'Five jobs did not start concurrently')
                self.assertEqual(manager.workers, 5)
                with lock:
                    self.assertEqual(len(started), 5)
                    self.assertNotIn(jobs[5], started)
            finally:
                release.set()
                manager.pool.shutdown(wait=True)
            self.assertEqual(set(started), set(jobs))

    def test_fast_options_keep_resumability(self):
        import os
        from unittest.mock import patch
        ns['os'] = os
        with patch.dict(os.environ, {'YTDLP_COOKIES_FILE': ''}):
            opts = original_options()
        self.assertEqual(opts['concurrent_fragment_downloads'], 5)
        self.assertEqual(opts['http_chunk_size'], 8 * 1024 * 1024)
        self.assertTrue(opts['continuedl'])
        self.assertFalse(opts['nopart'])
        self.assertFalse(opts['overwrites'])
        self.assertNotIn('nocheckcertificate', opts)

    def test_supported_inputs(self):
        cases = [
            ('https://v.douyin.com/abc123/', 'https://v.douyin.com/abc123/'),
            ('0.25 o@d.an 02/12 :7pm 蜘蛛侠 https://v.douyin.com/abc123/ 复制此链接，打开抖音搜索', 'https://v.douyin.com/abc123/'),
            ('复制：https://v.douyin.com/abc123/。打开抖音', 'https://v.douyin.com/abc123/'),
            ('（https://v.douyin.com/abc123/）', 'https://v.douyin.com/abc123/'),
            ('“https://b23.tv/abc123”', 'https://b23.tv/abc123'),
            ('Xem https://www.bilibili.com/video/BV123?p=2&foo=bar', 'https://www.bilibili.com/video/BV123?p=2&foo=bar'),
            (' https://www.douyin.com/video/123\n', 'https://www.douyin.com/video/123'),
            ('https://v.douyin.com/abc. ', 'https://v.douyin.com/abc'),
            ('https://b23.tv/abc https://b23.tv/abc', 'https://b23.tv/abc'),
        ]
        for raw, expected in cases:
            with self.subTest(raw=raw): self.assertEqual(validate(raw), expected)

    def test_reject_invalid_and_ambiguous(self):
        for raw in [
            'http://v.douyin.com/abc', 'https://evil.example/abc',
            'https://douyin.com.evil.example/abc', 'https://127.0.0.1/abc',
            'https://user:pass@v.douyin.com/abc', 'https://v.douyin.com:444/abc',
            'https://v.douyin.com/', 'không có link', 'file:///tmp/a',
            'https://[invalid/abc', 'https://v.douyin.com/abc\\def',
            'https://v.douyin.com/a https://b23.tv/b', 'x' * 8193,
        ]:
            with self.subTest(raw=raw):
                with self.assertRaises(HTTPException) as raised: validate(raw)
                self.assertEqual(raised.exception.status_code, 422)

    def test_inspection_passes_clean_url_to_extractor(self):
        raw = '标题 https://b23.tv/abc 复制链接'
        ytdlp = MagicMock()
        extractor = ytdlp.YoutubeDL.return_value.__enter__.return_value
        extractor.extract_info.return_value = {'title': 'Test', 'formats': []}
        ns.update(require_ytdlp=lambda: ytdlp, ydl_options=lambda x: x, first_video=lambda x: x)
        result = ns['inspect_video'](raw)
        extractor.extract_info.assert_called_once_with('https://b23.tv/abc', download=False)
        self.assertEqual(result['platform'], 'Bilibili')

    def test_analyze_handler_passes_clean_url(self):
        async def run(fn, url):
            self.assertEqual(url, 'https://v.douyin.com/abc')
            return {'title': 'ok'}
        ns['run_in_threadpool'] = run
        req = ns['AnalyzeRequest'](url='标题 https://v.douyin.com/abc 复制链接')
        self.assertEqual(asyncio.run(ns['analyze'](req)), {'title': 'ok'})

    def test_enqueue_stores_clean_url(self):
        import threading, uuid
        ns.update(threading=threading, uuid=uuid, QUALITY_CHOICES=(1080,))
        manager = ns['DownloadManager'].__new__(ns['DownloadManager'])
        manager.lock = threading.RLock()
        manager.jobs = {}
        manager.pool = MagicMock()
        job_id = manager.enqueue('标题 https://v.douyin.com/abc 复制链接', 1080)
        self.assertEqual(manager.jobs[job_id]['url'], 'https://v.douyin.com/abc')
        manager.pool.submit.assert_called_once()

if __name__ == '__main__':
    unittest.main()
