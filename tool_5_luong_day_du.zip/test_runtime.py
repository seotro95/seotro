import os
import tempfile
import time
import unittest
from pathlib import Path
from runtime_worker import run_in_worker

class WorkerTests(unittest.TestCase):
    def test_returns_result(self):
        with tempfile.TemporaryDirectory() as d:
            script=Path(d)/'fake.py'
            script.write_text('import json,sys\np=json.loads(sys.stdin.readline())\nprint(json.dumps({"kind":"result","result":{"ok":True}}),flush=True)\n')
            self.assertEqual(run_in_worker({'action':'analyze'}, worker_path=script, start_timeout=2), {'ok':True})

    def test_stalled_process_is_killed(self):
        with tempfile.TemporaryDirectory() as d:
            script=Path(d)/'fake.py';pidfile=Path(d)/'pid'
            script.write_text('import os,time,json,sys\nfrom pathlib import Path\np=json.loads(sys.stdin.readline())\nPath(p["pidfile"]).write_text(str(os.getpid()))\ntime.sleep(60)\n')
            start=time.monotonic()
            with self.assertRaises(TimeoutError):
                run_in_worker({'action':'download','pidfile':str(pidfile)}, worker_path=script, start_timeout=.4)
            self.assertLess(time.monotonic()-start,3)
            if os.name != 'nt':
                with self.assertRaises(ProcessLookupError):os.kill(int(pidfile.read_text()),0)

    def test_hard_limit_even_with_activity(self):
        with tempfile.TemporaryDirectory() as d:
            script=Path(d)/'fake.py'
            script.write_text('import time,json,sys\np=json.loads(sys.stdin.readline())\ni=0\nwhile True:\n i+=1\n print(json.dumps({"kind":"update","changes":{"received_bytes":i}}),flush=True)\n time.sleep(.03)\n')
            updates=[]
            with self.assertRaises(TimeoutError):
                run_in_worker({'action':'download'},updates.append, worker_path=script, max_seconds=.5)
            self.assertTrue(updates)

    def test_analysis_has_deadline(self):
        with tempfile.TemporaryDirectory() as d:
            script=Path(d)/'fake.py';script.write_text('import time\ntime.sleep(60)\n')
            with self.assertRaises(TimeoutError):
                run_in_worker({'action':'analyze'},worker_path=script,start_timeout=.3)

class TransferTests(unittest.TestCase):
    def test_real_http_download_in_worker(self):
        import functools
        import http.server
        import subprocess
        import threading
        import json
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            media=root/'source.mp4'
            subprocess.run(['ffmpeg','-nostdin','-v','error','-f','lavfi','-i','testsrc2=size=320x180:rate=10',
                            '-f','lavfi','-i','sine=frequency=440','-t','0.5','-c:v','libx264','-threads','2','-c:a','aac',str(media)],check=True)
            class QuietHandler(http.server.SimpleHTTPRequestHandler):
                def log_message(self,*args):pass
            server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(QuietHandler,directory=d))
            threading.Thread(target=server.serve_forever,daemon=True).start()
            url=f'http://127.0.0.1:{server.server_port}/source.mp4'
            script=root/'fixture_worker.py'
            script.write_text("import sys\nsys.path.insert(0,"+repr(str(Path(__file__).resolve().parent))+" )\n" +
                "import app,runtime_worker,yt_dlp\nfrom yt_dlp.extractor.common import InfoExtractor\nfrom types import SimpleNamespace\n" +
                "class FixtureIE(InfoExtractor):\n _VALID_URL=r'fixture:(?P<id>test)'\n def _real_extract(self,url):\n  return {'id':'test','title':'test','formats':[{'format_id':'source','url':"+repr(url)+",'width':320,'height':180,'vcodec':'h264','acodec':'aac','ext':'mp4','protocol':'http'}]}\n"+
                "class FixtureYDL(yt_dlp.YoutubeDL):\n def __init__(self,opts):\n  super().__init__(opts,auto_init=False)\n  self.add_info_extractor(FixtureIE())\n"+
                "app.require_ytdlp=lambda:SimpleNamespace(YoutubeDL=FixtureYDL)\nruntime_worker.main()\n")
            try:
                updates=[]
                result=run_in_worker({'action':'download','url':'fixture:test','job_id':'job',
                                      'quality':2160,'directory':str(root/'out')},updates.append,
                                     worker_path=script,start_timeout=15,max_seconds=30)
                self.assertEqual(result['status'],'done')
                output=Path(result['path'])
                self.assertEqual(output.read_bytes(),media.read_bytes())
                self.assertTrue(any(u.get('received_bytes',0)>0 for u in updates))
                probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=codec_type,width,height','-of','json',str(output)]))
                self.assertEqual({x['codec_type'] for x in probe['streams']},{'audio','video'})
            finally:
                server.shutdown();server.server_close()

class QualityTests(unittest.TestCase):
    def test_real_ytdlp_selector_caps_landscape_and_portrait(self):
        from app import format_selector
        import yt_dlp
        def f(name,w,h,a='none',codec='h264',ext='mp4'):
            return {'format_id':name,'width':w,'height':h,'vcodec':codec,'acodec':a,
                    'ext':ext,'protocol':'https','url':'https://example.invalid/'+name}
        for portrait in [False,True]:
            formats=[f('1080',1080 if portrait else 1920,1920 if portrait else 1080),
                     f('4k',2160 if portrait else 3840,3840 if portrait else 2160),
                     f('8k',4320 if portrait else 7680,7680 if portrait else 4320),
                     f('audio',None,None,'aac','none','m4a')]
            for cap,expected in [(2160,'4k'),(1440,'1080'),(1080,'1080')]:
                with self.subTest(portrait=portrait,cap=cap):
                    with yt_dlp.YoutubeDL({'quiet':True,'format':format_selector(cap)}) as y:
                        result=y.process_ie_result({'id':'test','title':'test','formats':formats},download=False)
                    selected=result['requested_formats']
                    self.assertEqual(selected[0]['format_id'],expected)
                    self.assertEqual(selected[1]['format_id'],'audio')

    def test_missing_dimensions_does_not_ignore_cap(self):
        from app import format_selector
        with self.assertRaises(RuntimeError):
            list(format_selector(2160)({'formats':[{'format_id':'unknown','vcodec':'h264'}]}))

    def test_lower_combined_preserves_audio_without_audio_only(self):
        from app import format_selector
        low={'format_id':'720','vcodec':'h264','acodec':'aac','width':1280,'height':720}
        high={'format_id':'1080','vcodec':'h264','acodec':'none','width':1920,'height':1080}
        self.assertEqual(list(format_selector(2160)({'formats':[low,high]})),[low])

    def test_direct_format_with_audio(self):
        from app import format_selector
        f={'format_id':'combined','vcodec':'h264','acodec':'aac','width':1280,'height':720}
        self.assertEqual(list(format_selector(2160)({'formats':[f]})),[f])

if __name__=='__main__':unittest.main()
