@echo off
chcp 65001 >nul
where aria2c >nul 2>&1
if not errorlevel 1 (
    echo aria2 da duoc cai. Hay dong va mo lai tool.
    pause
    exit /b 0
)
where winget >nul 2>&1
if errorlevel 1 (
    echo Chua co winget. Cai hoac cap nhat App Installer tu Microsoft Store.
    echo Tool van dung duoc che do On dinh ma khong can aria2.
    pause
    exit /b 1
)
winget install --id aria2.aria2 -e --source winget --accept-package-agreements --accept-source-agreements
if errorlevel 1 (
    echo Cai aria2 chua thanh cong. Tool van dung duoc che do On dinh.
) else (
    echo Da cai aria2. Dong cua so tool cu va CMD cu, roi mo lai khoi_dong.bat.
)
pause
