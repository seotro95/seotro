import hashlib
import http.server
import os
import shutil
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest.mock import patch

class FastOptionsTests(unittest.TestCase):
    def test_fast_connections_are_bounded_and_tls_verified(self):
        from app import download_options
        with patch('app.shutil.which',return_value='/tools/aria2c'):
            opts=download_options('https://www.bilibili.com/video/BV123',mode='fast')
        self.assertIn('external_downloader',opts)
        args=opts['external_downloader_args']['aria2c']
        self.assertIn('-x4',args);self.assertIn('-s4',args)
        self.assertIn('--check-certificate=true',args)
        self.assertNotIn('nocheckcertificate',opts)
        stable=download_options('https://www.bilibili.com/video/BV123')
        self.assertNotIn('external_downloader',stable)

    def test_without_aria2_native_is_available(self):
        from app import download_options
        with patch('app.shutil.which',return_value=None):
            opts=download_options('https://v.douyin.com/test',mode='fast')
        self.assertNotIn('external_downloader',opts)
        self.assertEqual(opts['concurrent_fragment_downloads'],4)

    def test_mode_is_validated(self):
        from app import DownloadRequest
        from pydantic import ValidationError
        with self.assertRaises(ValidationError):
            DownloadRequest(url='https://v.douyin.com/a',mode='invalid')

class NativeFallbackTests(unittest.TestCase):
    def test_fast_failure_does_not_mix_partial_files(self):
        import app
        from types import SimpleNamespace
        with tempfile.TemporaryDirectory() as d:
            directory=Path(d);manager=app.DownloadManager(directory)
            folder=directory/'job';folder.mkdir()
            (folder/'video.mp4.part').write_bytes(b'old-native-part')
            class Native:
                def __init__(self,opts):self.opts=opts
                def __enter__(self):return self
                def __exit__(self,*args):pass
                def extract_info(self,*args,**kwargs):
                    self_outer.assertNotIn('external_downloader',self.opts)
                    (folder/'video.mp4').write_bytes(b'complete-native-file')
                    return {'id':'test'}
            class FailFast(Native):
                def extract_info(self,*args,**kwargs):
                    (folder/'fast'/'video.mp4.part').write_bytes(b'sparse-fast-part')
                    raise RuntimeError('aria2c exited with code 1')
            self_outer=self
            manager.jobs['job']={'id':'job','url':'https://v.douyin.com/test','quality':2160,'mode':'fast'}
            try:
                with patch('app.require_ytdlp',return_value=SimpleNamespace(YoutubeDL=Native)), \
                     patch('app.make_fast_ytdlp',return_value=FailFast), \
                     patch('app.shutil.which',return_value='/tools/aria2c'):
                    manager._download_direct('job')
                self.assertEqual(manager.get('job')['status'],'done')
                self.assertEqual((folder/'video.mp4').read_bytes(),b'complete-native-file')
                self.assertEqual((folder/'video.mp4.part').read_bytes(),b'old-native-part')
                self.assertEqual((folder/'fast'/'video.mp4.part').read_bytes(),b'sparse-fast-part')
            finally:manager.pool.shutdown(wait=True)

@unittest.skipUnless(shutil.which('aria2c'),'optional aria2 executable not installed')
class AriaTransferTests(unittest.TestCase):
    def test_real_parallel_transfer_progress_and_integrity(self):
        import yt_dlp
        from app import download_options
        from fast_transfer import make_fast_ytdlp
        payload=b'0123456789abcdef'*(4*1024*1024)
        active=peak=0;lock=threading.Lock();ranges=[]
        class Handler(http.server.BaseHTTPRequestHandler):
            def log_message(self,*args):pass
            def do_GET(self):
                nonlocal active,peak
                start=0;end=len(payload)-1
                byte_range=self.headers.get('Range')
                ranges.append(byte_range)
                if byte_range:
                    limits=byte_range.removeprefix('bytes=').split('-',1)
                    start=int(limits[0]);end=int(limits[1]) if limits[1] else end
                    end=min(end,len(payload)-1)
                if start> end:
                    self.send_response(416);self.end_headers();return
                self.send_response(206 if byte_range else 200)
                self.send_header('Content-Length',str(end-start+1))
                self.send_header('Accept-Ranges','bytes')
                if byte_range:self.send_header('Content-Range',f'bytes {start}-{end}/{len(payload)}')
                self.end_headers()
                with lock:active+=1;peak=max(peak,active)
                try:
                    for offset in range(start,end+1,65536):
                        self.wfile.write(payload[offset:min(offset+65536,end+1)])
                        time.sleep(.005)
                except (BrokenPipeError,ConnectionResetError):pass
                finally:
                    with lock:active-=1
        server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler)
        threading.Thread(target=server.serve_forever,daemon=True).start()
        updates=[]
        try:
            with tempfile.TemporaryDirectory() as d:
                opts=download_options('https://www.bilibili.com/video/BVtest',mode='fast',extra={'progress_hooks':[updates.append]})
                info={'url':f'http://127.0.0.1:{server.server_port}/video.mp4','protocol':'http','ext':'mp4'}
                out=Path(d)/'video.mp4'
                native=Path(d)/'native.mp4'
                native_started=time.monotonic()
                with yt_dlp.YoutubeDL(download_options('https://www.bilibili.com/video/BVtest')) as y:
                    self.assertTrue(y.dl(str(native),info)[0])
                native_elapsed=time.monotonic()-native_started
                self.assertEqual(hashlib.sha256(native.read_bytes()).digest(),hashlib.sha256(payload).digest())
                started=time.monotonic()
                with make_fast_ytdlp(yt_dlp.YoutubeDL)(opts) as y:
                    success=y.dl(str(out),info)[0]
                elapsed=time.monotonic()-started
                self.assertTrue(success)
                self.assertEqual(hashlib.sha256(out.read_bytes()).digest(),hashlib.sha256(payload).digest())
                self.assertGreaterEqual(peak,2)
                self.assertLessEqual(peak,4)
                self.assertTrue(any(x.get('downloaded_bytes',0)>0 for x in updates))
                self.assertTrue(any(x.get('speed',0)>0 for x in updates))
                print(f'Local parallel fixture: {peak} connections, fast {elapsed:.2f}s vs native {native_elapsed:.2f}s, verified hash')
        finally:server.shutdown();server.server_close()

    def test_fast_worker_downloads_and_merges_video_and_audio(self):
        import functools,subprocess,json
        from runtime_worker import run_in_worker
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            video=root/'source.mp4';audio=root/'source.m4a'
            subprocess.run(['ffmpeg','-nostdin','-v','error','-f','lavfi','-i','testsrc2=size=320x180:rate=10',
                            '-t','0.5','-an','-c:v','libx264','-threads','2',str(video)],check=True)
            subprocess.run(['ffmpeg','-nostdin','-v','error','-f','lavfi','-i','sine=frequency=440',
                            '-t','0.5','-vn','-c:a','aac',str(audio)],check=True)
            class Handler(http.server.SimpleHTTPRequestHandler):
                def log_message(self,*args):pass
            server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=d))
            threading.Thread(target=server.serve_forever,daemon=True).start()
            base=f'http://127.0.0.1:{server.server_port}'
            formats=[{'format_id':'video','url':base+'/source.mp4','width':320,'height':180,
                      'vcodec':'h264','acodec':'none','ext':'mp4','protocol':'http','filesize':video.stat().st_size},
                     {'format_id':'audio','url':base+'/source.m4a','vcodec':'none','acodec':'aac',
                      'ext':'m4a','protocol':'http','filesize':audio.stat().st_size}]
            script=root/'fixture.py'
            script.write_text('import sys\nsys.path.insert(0,'+repr(str(Path(__file__).resolve().parent))+')\n'+
                'import app,runtime_worker,yt_dlp\nfrom yt_dlp.extractor.common import InfoExtractor\nfrom types import SimpleNamespace\n'+
                "class FixtureIE(InfoExtractor):\n _VALID_URL=r'fixture:(?P<id>test)'\n def _real_extract(self,url):\n  return {'id':'test','title':'test','formats':"+repr(formats)+"}\n"+
                'class FixtureYDL(yt_dlp.YoutubeDL):\n def __init__(self,opts):\n  super().__init__(opts,auto_init=False)\n  self.add_info_extractor(FixtureIE())\n'+
                'app.require_ytdlp=lambda:SimpleNamespace(YoutubeDL=FixtureYDL)\nruntime_worker.main()\n')
            try:
                result=run_in_worker({'action':'download','job_id':'job','url':'fixture:test',
                                      'quality':2160,'mode':'fast','directory':str(root/'out')},
                                     worker_path=script,start_timeout=15,max_seconds=30)
                output=Path(result['path'])
                self.assertEqual(output.parent,root/'out'/'job')
                self.assertEqual(result['status'],'done')
                media=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=codec_type,width,height','-of','json',str(output)]))
                self.assertEqual({x['codec_type'] for x in media['streams']},{'audio','video'})
                subprocess.run(['ffmpeg','-nostdin','-v','error','-i',str(output),'-f','null','-'],check=True)
            finally:server.shutdown();server.server_close()

    def test_failed_aria_does_not_publish_partial_as_completed(self):
        import yt_dlp
        from yt_dlp.utils import DownloadError
        from fast_transfer import AriaProgress,make_fast_ytdlp
        from app import download_options
        class Handler(http.server.BaseHTTPRequestHandler):
            def log_message(self,*args):pass
            def do_GET(self):self.send_response(503);self.end_headers()
        server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler)
        threading.Thread(target=server.serve_forever,daemon=True).start()
        original=AriaProgress.__init__
        def init(self,*args):
            original(self,*args);self.args.extend(['--max-tries=1','--retry-wait=0'])
        class Logger:
            def debug(self,*args):pass
            def warning(self,*args):pass
            def error(self,*args):pass
        try:
            with tempfile.TemporaryDirectory() as d, patch.object(AriaProgress,'__init__',init):
                out=Path(d)/'video.mp4'
                opts=download_options('https://www.bilibili.com/video/BVtest',mode='fast',extra={'logger':Logger()})
                with make_fast_ytdlp(yt_dlp.YoutubeDL)(opts) as y:
                    with self.assertRaises(DownloadError):
                        y.dl(str(out),{'url':f'http://127.0.0.1:{server.server_port}/video.mp4','protocol':'http','ext':'mp4'})
                self.assertFalse(out.exists())
        finally:server.shutdown();server.server_close()

if __name__=='__main__':unittest.main()
