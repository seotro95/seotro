"""Use alternate URLs provided for the same media stream by Bilibili."""
from urllib.parse import urlsplit


def official_backup(url):
    if not isinstance(url,str):
        return False
    try:
        parsed=urlsplit(url)
        host=(parsed.hostname or '').lower()
        return (parsed.scheme=='https' and parsed.port in (None,443) and
                not parsed.username and not parsed.password and
                any(host==base or host.endswith('.'+base) for base in
                    ('bilivideo.com','bilivideo.cn','bilibili.com')))
    except ValueError:
        return False


def backup_map(data):
    result={}
    def visit(value):
        if isinstance(value,dict):
            primary=value.get('baseUrl') or value.get('base_url')
            backups=value.get('backupUrl') or value.get('backup_url') or []
            if isinstance(primary,str) and isinstance(backups,list):
                result[primary]=list(dict.fromkeys(u for u in backups
                                                  if u!=primary and official_backup(u)))[:2]
            for child in value.values():visit(child)
        elif isinstance(value,list):
            for child in value:visit(child)
    visit(data)
    return result


def make_ytdlp(yt_dlp,on_fallback=None):
    from yt_dlp.extractor.bilibili import BiliBiliIE
    from yt_dlp.utils import DownloadError

    class BilibiliBackupsIE(BiliBiliIE):
        @classmethod
        def ie_key(cls):
            return BiliBiliIE.ie_key()

        def extract_formats(self,play_info):
            formats=super().extract_formats(play_info)
            backups=backup_map(play_info)
            for fmt in formats:
                if backups.get(fmt.get('url')):
                    fmt['_bili_backup_urls']=backups[fmt['url']]
            return formats

    class BackupYoutubeDL(yt_dlp.YoutubeDL):
        def __init__(self,*args,**kwargs):
            super().__init__(*args,**kwargs)
            self.add_info_extractor(BilibiliBackupsIE())

        def dl(self,name,info,subtitle=False,test=False):
            backups=info.get('_bili_backup_urls') or []
            if subtitle or test or not backups:
                return super().dl(name,info,subtitle=subtitle,test=test)
            original_code=self._download_retcode
            last_error=None
            outcome=None
            # The extractor only attaches backups of this exact stream.
            # Keep its format ID and output filename so .part data can resume.
            for index,url in enumerate([info['url'],*backups]):
                if index and on_fallback:
                    on_fallback(index)
                candidate=dict(info,url=url)
                try:
                    outcome=super().dl(name,candidate,subtitle=subtitle,test=test)
                    if outcome[0]:
                        self._download_retcode=original_code
                        return outcome
                except DownloadError as exc:
                    last_error=exc
            if last_error:
                raise last_error
            return outcome
    return BackupYoutubeDL
