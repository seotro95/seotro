@echo off
cd /d "%~dp0"
set "YTDLP_BROWSER=chrome"
set "VIDEO_WORKERS=2"
call khoi_dong.bat
