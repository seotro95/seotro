import os
import tempfile
import time
import unittest
from pathlib import Path
from runtime_worker import run_in_worker

class WorkerTests(unittest.TestCase):
    def test_returns_result(self):
        with tempfile.TemporaryDirectory() as d:
            script=Path(d)/'fake.py'
            script.write_text('import json,sys\np=json.loads(sys.stdin.readline())\nprint(json.dumps({"kind":"result","result":{"ok":True}}),flush=True)\n')
            self.assertEqual(run_in_worker({'action':'analyze'}, worker_path=script, start_timeout=2), {'ok':True})

    def test_stalled_process_is_killed(self):
        with tempfile.TemporaryDirectory() as d:
            script=Path(d)/'fake.py';pidfile=Path(d)/'pid'
            script.write_text('import os,time,json,sys\nfrom pathlib import Path\np=json.loads(sys.stdin.readline())\nPath(p["pidfile"]).write_text(str(os.getpid()))\ntime.sleep(60)\n')
            start=time.monotonic()
            with self.assertRaises(TimeoutError):
                run_in_worker({'action':'download','pidfile':str(pidfile)}, worker_path=script, start_timeout=.4)
            self.assertLess(time.monotonic()-start,3)
            if os.name != 'nt':
                with self.assertRaises(ProcessLookupError):os.kill(int(pidfile.read_text()),0)

    def test_hard_limit_even_with_activity(self):
        with tempfile.TemporaryDirectory() as d:
            script=Path(d)/'fake.py'
            script.write_text('import time,json,sys\np=json.loads(sys.stdin.readline())\ni=0\nwhile True:\n i+=1\n print(json.dumps({"kind":"update","changes":{"received_bytes":i}}),flush=True)\n time.sleep(.03)\n')
            updates=[]
            with self.assertRaises(TimeoutError):
                run_in_worker({'action':'download'},updates.append, worker_path=script, max_seconds=.5)
            self.assertTrue(updates)

    def test_analysis_has_deadline(self):
        with tempfile.TemporaryDirectory() as d:
            script=Path(d)/'fake.py';script.write_text('import time\ntime.sleep(60)\n')
            with self.assertRaises(TimeoutError):
                run_in_worker({'action':'analyze'},worker_path=script,start_timeout=.3)

class CancellationTests(unittest.TestCase):
    def test_cancellation_kills_process_and_keeps_part(self):
        import threading
        from runtime_worker import WorkerCancelled
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);script=root/'fake.py';pidfile=root/'pid';part=root/'video.mp4.part'
            script.write_text('import os,time,json,sys\nfrom pathlib import Path\np=json.loads(sys.stdin.readline())\nPath(p["pidfile"]).write_text(str(os.getpid()))\nPath(p["part"]).write_bytes(b"partial")\ntime.sleep(60)\n')
            cancel=threading.Event()
            def stop_when_started():
                deadline=time.monotonic()+5
                while not part.exists() and time.monotonic()<deadline:time.sleep(.01)
                cancel.set()
            stopper=threading.Thread(target=stop_when_started);stopper.start()
            with self.assertRaises(WorkerCancelled):
                run_in_worker({'action':'download','pidfile':str(pidfile),'part':str(part)},
                              worker_path=script,cancel_event=cancel,start_timeout=5)
            stopper.join()
            self.assertEqual(part.read_bytes(),b'partial')
            if os.name != 'nt':
                with self.assertRaises(ProcessLookupError):os.kill(int(pidfile.read_text()),0)

    def test_stop_queued_and_running_jobs_and_retry(self):
        import threading
        from unittest.mock import patch
        import app
        from runtime_worker import WorkerCancelled
        started=threading.Event()
        runs=[]
        def fake_worker(payload,on_update,*,cancel_event,start_timeout=60):
            runs.append(payload['job_id']);started.set()
            self.assertTrue(cancel_event.wait(5))
            on_update({'status':'done'})  # Late progress must not override stop.
            raise WorkerCancelled('stopped')
        with tempfile.TemporaryDirectory() as d, patch.object(app,'run_in_worker',fake_worker):
            manager=app.DownloadManager(Path(d),workers=1)
            try:
                first=manager.enqueue('https://v.douyin.com/first',2160)
                self.assertTrue(started.wait(3))
                second=manager.enqueue('https://v.douyin.com/second',1080)
                manager.stop(second)
                self.assertEqual(manager.get(second)['status'],'stopped')
                self.assertNotIn(second,runs)
                manager.stop(first)
                manager.futures[first].result(timeout=3)
                self.assertEqual(manager.get(first)['status'],'stopped')
                self.assertIsNone(manager.get(first)['error'])
                manager.stop(first)  # Idempotent.
                started.clear();manager.retry(first)
                self.assertTrue(started.wait(3))
                manager.stop(first);manager.futures[first].result(timeout=3)
                self.assertEqual(runs,[first,first])
                self.assertEqual(manager.get(first)['status'],'stopped')
            finally:
                for event in manager.cancel_events.values():event.set()
                manager.pool.shutdown(wait=True)

class StopAPITests(unittest.TestCase):
    def test_stop_route_and_status(self):
        import app, threading
        from unittest.mock import patch
        from fastapi.testclient import TestClient
        from runtime_worker import WorkerCancelled
        started=threading.Event()
        def fake_worker(payload,on_update,*,cancel_event,start_timeout=60):
            started.set();cancel_event.wait(5);raise WorkerCancelled('stopped')
        with tempfile.TemporaryDirectory() as d:
            manager=app.DownloadManager(Path(d),workers=1)
            try:
                with patch.object(app,'manager',manager), patch.object(app,'run_in_worker',fake_worker), TestClient(app.app) as client:
                    self.assertEqual(client.post('/api/stop/missing').status_code,404)
                    r=client.post('/api/download',json={'url':'https://v.douyin.com/test','quality':2160})
                    self.assertEqual(r.status_code,202);job=r.json()['job_id']
                    self.assertTrue(started.wait(3))
                    r=client.post('/api/stop/'+job)
                    self.assertEqual(r.status_code,202)
                    manager.futures[job].result(timeout=3)
                    self.assertEqual(client.get('/api/status/'+job).json()['status'],'stopped')
            finally:
                for event in manager.cancel_events.values():event.set()
                manager.pool.shutdown(wait=True)

class TransferTests(unittest.TestCase):
    def test_real_http_download_in_worker(self):
        import functools
        import http.server
        import subprocess
        import threading
        import json
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            media=root/'source.mp4'
            subprocess.run(['ffmpeg','-nostdin','-v','error','-f','lavfi','-i','testsrc2=size=320x180:rate=10',
                            '-f','lavfi','-i','sine=frequency=440','-t','0.5','-c:v','libx264','-threads','2','-c:a','aac',str(media)],check=True)
            requests=[]
            class QuietHandler(http.server.SimpleHTTPRequestHandler):
                def log_message(self,*args):pass
                def do_GET(self):
                    requests.append(self.path)
                    if len(requests)<=2:
                        self.send_response(503);self.end_headers();return
                    super().do_GET()
            server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(QuietHandler,directory=d))
            threading.Thread(target=server.serve_forever,daemon=True).start()
            url=f'http://127.0.0.1:{server.server_port}/source.mp4'
            script=root/'fixture_worker.py'
            script.write_text("import sys\nsys.path.insert(0,"+repr(str(Path(__file__).resolve().parent))+" )\n" +
                "import app,runtime_worker,yt_dlp\nfrom yt_dlp.extractor.common import InfoExtractor\nfrom types import SimpleNamespace\n" +
                "class FixtureIE(InfoExtractor):\n _VALID_URL=r'fixture:(?P<id>test)'\n def _real_extract(self,url):\n  return {'id':'test','title':'test','formats':[{'format_id':'source','url':"+repr(url)+",'width':320,'height':180,'vcodec':'h264','acodec':'aac','ext':'mp4','protocol':'http'}]}\n"+
                "class FixtureYDL(yt_dlp.YoutubeDL):\n def __init__(self,opts):\n  super().__init__(opts,auto_init=False)\n  self.add_info_extractor(FixtureIE())\n"+
                "app.require_ytdlp=lambda:SimpleNamespace(YoutubeDL=FixtureYDL)\nruntime_worker.main()\n")
            try:
                updates=[]
                result=run_in_worker({'action':'download','url':'fixture:test','job_id':'job',
                                      'quality':2160,'directory':str(root/'out')},updates.append,
                                     worker_path=script,start_timeout=15,max_seconds=30)
                self.assertEqual(result['status'],'done')
                output=Path(result['path'])
                self.assertEqual(output.read_bytes(),media.read_bytes())
                self.assertGreaterEqual(len(requests),3)
                self.assertTrue(any(u.get('received_bytes',0)>0 for u in updates))
                probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=codec_type,width,height','-of','json',str(output)]))
                self.assertEqual({x['codec_type'] for x in probe['streams']},{'audio','video'})
            finally:
                server.shutdown();server.server_close()

class BilibiliOptionsTests(unittest.TestCase):
    def test_reduce_connections_for_bilibili_only(self):
        from app import download_options
        bili=download_options('https://www.bilibili.com/video/BV123')
        self.assertEqual(bili['http_chunk_size'],0)
        self.assertEqual(bili['concurrent_fragment_downloads'],1)
        self.assertEqual(bili['retries'],4)
        self.assertTrue(bili['continuedl'])
        self.assertFalse(bili['overwrites'])
        douyin=download_options('https://www.douyin.com/video/123')
        self.assertEqual(douyin['concurrent_fragment_downloads'],1)

    def test_503_error_is_explained(self):
        from app import extractor_error_message
        self.assertIn('Thử tải tiếp',extractor_error_message(RuntimeError('HTTP Error 503: Service Unavailable')))

class QualityTests(unittest.TestCase):
    def test_real_ytdlp_selector_caps_landscape_and_portrait(self):
        from app import format_selector
        import yt_dlp
        def f(name,w,h,a='none',codec='h264',ext='mp4'):
            return {'format_id':name,'width':w,'height':h,'vcodec':codec,'acodec':a,
                    'ext':ext,'protocol':'https','url':'https://example.invalid/'+name}
        for portrait in [False,True]:
            formats=[f('1080',1080 if portrait else 1920,1920 if portrait else 1080),
                     f('4k',2160 if portrait else 3840,3840 if portrait else 2160),
                     f('8k',4320 if portrait else 7680,7680 if portrait else 4320),
                     f('audio',None,None,'aac','none','m4a')]
            for cap,expected in [(2160,'4k'),(1440,'1080'),(1080,'1080')]:
                with self.subTest(portrait=portrait,cap=cap):
                    with yt_dlp.YoutubeDL({'quiet':True,'format':format_selector(cap)}) as y:
                        result=y.process_ie_result({'id':'test','title':'test','formats':formats},download=False)
                    selected=result['requested_formats']
                    self.assertEqual(selected[0]['format_id'],expected)
                    self.assertEqual(selected[1]['format_id'],'audio')

    def test_missing_dimensions_does_not_ignore_cap(self):
        from app import format_selector
        with self.assertRaises(RuntimeError):
            list(format_selector(2160)({'formats':[{'format_id':'unknown','vcodec':'h264'}]}))

    def test_lower_combined_preserves_audio_without_audio_only(self):
        from app import format_selector
        low={'format_id':'720','vcodec':'h264','acodec':'aac','width':1280,'height':720}
        high={'format_id':'1080','vcodec':'h264','acodec':'none','width':1920,'height':1080}
        self.assertEqual(list(format_selector(2160)({'formats':[low,high]})),[low])

    def test_direct_format_with_audio(self):
        from app import format_selector
        f={'format_id':'combined','vcodec':'h264','acodec':'aac','width':1280,'height':720}
        self.assertEqual(list(format_selector(2160)({'formats':[f]})),[f])

if __name__=='__main__':unittest.main()
