import unittest
from unittest.mock import Mock, patch
from network_retry import extract_with_retry


class RetryTests(unittest.TestCase):
    @patch('network_retry.time.sleep')
    def test_timeout_then_success(self, sleep):
        ydl = Mock()
        ydl.extract_info.side_effect = [RuntimeError('read operation timed out'), {'id': 'ok'}]
        notify = Mock()
        self.assertEqual(extract_with_retry(ydl, 'url', download=True, on_retry=notify), {'id': 'ok'})
        self.assertEqual(ydl.extract_info.call_count, 2)
        notify.assert_called_once_with(1)
        sleep.assert_called_once_with(2)

    @patch('network_retry.time.sleep')
    def test_reset_is_bounded(self, sleep):
        ydl = Mock()
        ydl.extract_info.side_effect = RuntimeError('[WinError 10054] forcibly closed')
        with self.assertRaises(RuntimeError):
            extract_with_retry(ydl, 'url', download=True)
        self.assertEqual(ydl.extract_info.call_count, 3)

    @patch('network_retry.time.sleep')
    def test_credentials_and_tls_not_retried(self, sleep):
        for error in ('Fresh cookies are needed', 'HTTP Error 403', 'certificate verify failed'):
            ydl = Mock()
            ydl.extract_info.side_effect = RuntimeError(error)
            with self.assertRaises(RuntimeError):
                extract_with_retry(ydl, 'url', download=False)
            self.assertEqual(ydl.extract_info.call_count, 1)
        sleep.assert_not_called()

    def test_browser_cookie_options_and_file_precedence(self):
        import app, os, tempfile
        from pathlib import Path
        with patch.dict(os.environ, {'YTDLP_BROWSER': 'firefox', 'YTDLP_COOKIES_FILE': ''}):
            self.assertEqual(app.ydl_options()['cookiesfrombrowser'], ('firefox',))
            with tempfile.TemporaryDirectory() as folder:
                path = Path(folder) / 'cookies.txt'
                path.write_text('# Netscape HTTP Cookie File\n')
                with patch.dict(os.environ, {'YTDLP_COOKIES_FILE': str(path)}):
                    options = app.ydl_options()
                    self.assertNotIn('cookiesfrombrowser', options)
                    self.assertEqual(options['cookiefile'], str(path))
