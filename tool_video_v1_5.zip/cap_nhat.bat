@echo off
cd /d "%~dp0"
".venv\Scripts\python.exe" -m pip install --upgrade -r requirements.txt
if errorlevel 1 (
 echo Cap nhat that bai.
 pause
 exit /b 1
)
echo Cap nhat thanh cong. Hay khoi dong lai tool.
pause
