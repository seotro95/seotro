"""Bounded retries for transient failures; never retry authentication failures."""
import time


def transient_error(exc):
    message = str(exc).lower()
    if any(x in message for x in ('fresh cookies', 'http error 401', 'http error 403', 'login required', 'not available', 'certificate verify')):
        return False
    return any(x in message for x in ('timed out', 'timeout', '10054', 'connection reset',
        'forcibly closed', 'closed connection', 'http error 429', 'http error 502',
        'http error 503', 'http error 504'))


def extract_with_retry(ydl, url, *, download, on_retry=None):
    for attempt in range(3):
        try:
            return ydl.extract_info(url, download=download)
        except Exception as exc:
            if attempt == 2 or not transient_error(exc):
                raise
            if on_retry:
                on_retry(attempt + 1)
            time.sleep(2 ** (attempt + 1))
