@echo off
cd /d "%~dp0"
set "VIDEO_WORKERS=2"
call khoi_dong.bat
