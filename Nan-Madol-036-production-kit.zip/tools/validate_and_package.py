"""Verify current narration, export real private MP3 files, and build reviewable bundles."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import zipfile
import numpy as np
import soundfile as sf

ROOT = Path(__file__).resolve().parents[1]
TARGET_SECONDS = 1338
TARGET_FRAMES = TARGET_SECONDS * 24000
NAMES = {
    'en': ('English — Hoa Kỳ — Andrew', 'United-States-English-Andrew'),
    'vi': ('Việt Nam — Tiếng Việt — Nam Minh', 'Viet-Nam-Tieng-Viet-Nam-Minh'),
    'es': ('Tây Ban Nha — Español', 'Spain-Espanol-Davefx'),
    'fr': ('Pháp — Français', 'France-Francais-Tom'),
    'ja': ('Nhật Bản — 日本語', 'Japan-Nihongo-M1'),
    'ko': ('Hàn Quốc — 한국어', 'South-Korea-Hangugeo-M1'),
    'de': ('Đức — Deutsch', 'Germany-Deutsch-Thorsten'),
    'it': ('Ý — Italiano', 'Italy-Italiano-M1'),
    'pt': ('Bồ Đào Nha — Português', 'Portugal-Portugues-Tugao'),
    'nl': ('Hà Lan — Nederlands', 'Netherlands-Nederlands-Ronnie'),
    'pl': ('Ba Lan — Polski', 'Poland-Polski-MC-Speech'),
    'sv': ('Thụy Điển — Svenska', 'Sweden-Svenska-NST'),
    'da': ('Đan Mạch — Dansk', 'Denmark-Dansk-Talesyntese'),
    'fi': ('Phần Lan — Suomi', 'Finland-Suomi-Harri'),
    'no': ('Na Uy — Norsk', 'Norway-Norsk-Talesyntese'),
    'cs': ('Séc — Čeština', 'Czechia-Cestina-Jirka'),
    'hmn': ('H’Mông Trắng — nữ female-3', 'Tieng-Hmong-Trang-Nu-female-3'),
}

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        while b := f.read(1024*1024): h.update(b)
    return h.hexdigest()

def save(path, obj):
    Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=2)+'\n')

def main():
    profiles = json.loads((ROOT/'VOICE_PROFILES.json').read_text())
    assert len(profiles['profiles']) == 17
    assert sum(p['gender']=='Male' for p in profiles['profiles']) == 16
    assert next(p for p in profiles['profiles'] if p['language']=='hmn')['gender']=='Female'
    profile_map = {p['language']:p for p in profiles['profiles']}
    assert profile_map['en']['voice_id']=='en-US-AndrewNeural'
    assert profile_map['vi']['voice_id']=='vi-VN-NamMinhNeural'
    assert profile_map['hmn']['voice_id']=='hmong-female-3'
    scenes = json.loads((ROOT/'scenes.json').read_text())
    assert len(scenes)==70 and sum(s['used_seconds'] for s in scenes)==TARGET_SECONDS
    assert sum(s['reserve_only'] for s in scenes)==3
    assert [n for s in scenes for n in s['voice_cues']]==list(range(1,135))
    prompt_files=sorted((ROOT/'prompts').glob('prompt-*.txt'))
    assert len(prompt_files)==7
    prompt_numbers=[]
    for p in prompt_files:
        parts=p.read_text(encoding='utf-8-sig').strip().split('\n\n')
        assert len(parts)==10,p
        for part in parts:
            prompt_numbers.append(int(re.match(r'(\d+)\.',part).group(1)))
            assert all(t in part for t in ['20-second','NO CHILDREN','NO AUDIO','NO SPEECH','KHÔNG CÓ HÌNH TRẺ EM','KHÔNG CÓ ÂM THANH, KHÔNG LỜI NÓI'])
    assert prompt_numbers==list(range(1,71))
    exports=ROOT/'downloads'
    exports.mkdir(exist_ok=True)
    result=[]
    for code,(label,stem) in NAMES.items():
        rows=json.loads((ROOT/f'scripts/{code}.json').read_text())
        assert len(rows)==134 and rows[-1]['start_seconds']+rows[-1]['duration_seconds']==1338
        srt=(ROOT/f'scripts/{code}.srt').read_text(encoding='utf-8-sig')
        assert srt.count(' --> ')==134 and '00:22:10,000 --> 00:22:18,000' in srt
        report=json.loads((ROOT/f'audio/{code}-report.json').read_text())
        assert report['status']=='created_pending_listening_review',(code,report['status'])
        assert report['voice_id']==profile_map[code]['voice_id']
        expected_hash=hashlib.sha256(json.dumps({'voice':report['voice_id'],'engine':report['engine'],'rows':rows},sort_keys=True,ensure_ascii=False).encode()).hexdigest()
        assert report['config_hash']==expected_hash,(code,'stale script/audio')
        assert len(report['segments'])==134
        for row,segment in zip(rows,report['segments']):
            assert row['text']==segment['text'] and row['scene']==segment['scene']
            assert segment['fitted_seconds']==row['duration_seconds']
            assert not segment['word_truncation']
            assert segment['speech_window_seconds']/segment['tempo'] <= row['duration_seconds']-.349
            assert segment['tempo']<=1.3,(code,segment['scene'],'too fast')
        assert report['decoded_samples']==TARGET_FRAMES and report['decoded_seconds']==TARGET_SECONDS
        source=ROOT/'audio'/report['mp3'];master=ROOT/'audio'/report['flac']
        assert sha(source)==report['mp3_sha256'] and sha(master)==report['flac_sha256']
        info=sf.info(master)
        assert info.frames==TARGET_FRAMES and info.samplerate==24000 and info.channels==1
        peak,nonzero_slots,frames=0.,0,0
        for block in sf.blocks(master,blocksize=240000,dtype='float32'):
            assert np.isfinite(block).all()
            local_peak=float(np.max(np.abs(block)))
            assert local_peak>.001,(code,'silent cue')
            peak=max(peak,local_peak);nonzero_slots+=1;frames+=len(block)
        assert frames==TARGET_FRAMES and nonzero_slots==134 and peak<.999
        target=exports/f'{stem}-22m18s.mp3'
        if target.exists():
            assert sha(target)==report['mp3_sha256'],target
        else: os.link(source,target)
        result.append(dict(language=code,label=label,voice_id=report['voice_id'],gender=profile_map[code]['gender'],
                           file='downloads/'+target.name,bytes=target.stat().st_size,sha256=report['mp3_sha256'],
                           decoded_samples=TARGET_FRAMES,decoded_seconds=TARGET_SECONDS,sample_rate=24000,channels=1,
                           narration_cues=134,non_silent_cues=134,lossless_sample_peak=round(peak,6),
                           max_tempo=round(max(x['tempo'] for x in report['segments']),6)))
        print(json.dumps({'verified':code,'seconds':1338,'non_silent_cues':134}),flush=True)
    created=datetime.now(timezone.utc).isoformat()
    manifest=dict(episode=36,topic='Nan Madol: A City Built above Water',created_at_utc=created,
                  seconds=1338,voices=17,prompt_count=70,prompt_txt_files=7,main_scenes=67,reserve_scenes=3,
                  full_native_speaker_review=False,published=False,files=result)
    save(ROOT/'DELIVERY_MANIFEST.json',manifest)
    save(ROOT/'validation/final-delivery.json',dict(status='passed',seconds=1338,decoded_samples_per_mp3=TARGET_FRAMES,
         matched_scripts=17,matched_voice_profiles=17,non_silent_cues_per_track=134,prompt_guards_passed=70,
         limitations=['No full native-speaker listening review for all languages.','UNESCO primary webpage blocked in this environment; see research notes.']))
    lines=['# Tải tập 36 — Nan Madol — 22:18','',
           'Đã tạo 17 MP3 thật, mỗi bản giải mã đúng **1.338 giây = 22:18**, mono 24 kHz. English Andrew là bản chính; Nam Minh cho tiếng Việt; H’Mông Trắng dùng nữ female-3. Các giọng còn lại là nam.','',
           'Các liên kết dưới đây trỏ tới tệp trong workspace của cuộc trò chuyện; không phải link phát hành công khai.','',
           '## Tải gộp','',
           '[17 MP3 — ZIP]({R}/Nan-Madol-036-17-voices-22m18s.zip)  \n[Trọn kịch bản, phụ đề và tài liệu — ZIP]({R}/Nan-Madol-036-production-kit.zip)  \n[70 prompt, 7 TXT — ZIP]({R}/70-prompts-7-txt.zip)'.format(R=ROOT),'',
           '## MP3 riêng theo ngôn ngữ','',
           '| Ngôn ngữ | Giọng | Tải MP3 |','|---|---|---|']
    for item in result:
        lines.append(f"| {item['label']} | {item['voice_id']} | [22:18]({ROOT/item['file']}) |")
    lines += ['', '## Kịch bản và dựng','',
              f'[Kịch bản chính có timecode]({ROOT}/KICH-BAN-CHINH.md) · [Kịch bản Anh]({ROOT}/scripts/en.txt) · [Kịch bản Việt]({ROOT}/scripts/vi.txt) · [Bảng cảnh và lời]({ROOT}/scene-voice-edit.csv)',
              f'[Hướng dẫn dựng]({ROOT}/EDITING-GUIDE.md) · [5 tiêu đề và 5 prompt thumbnail]({ROOT}/titles-thumbnails/5-TIEU-DE-VA-THUMBNAIL.md)',
              f'[Phân tích video nguồn]({ROOT}/source-analysis/PHAN-TICH-VIDEO-NGUON.md) · [Hồ sơ 17 giọng dùng lại]({ROOT}/VOICE_PROFILES.json)',
              '', '67 cảnh chính: 66 × 20 giây + 18 giây cuối = 22:18. Prompt 68–70 chỉ dự phòng. Mỗi TXT có đúng 10 prompt; mọi prompt cấm trẻ em, âm thanh và lời nói.',
              '', 'MP3 được kiểm tra số mẫu giải mã; phần hiển thị container có thể dư vài phần nghìn giây do khung MP3. Không cắt từ để ép thời lượng. Mỗi ngôn ngữ có TXT, JSON cue và SRT riêng trong bộ production kit.',
              '', 'Đã kiểm tra kỹ thuật và rà nội dung; chưa có nghe duyệt đầy đủ bởi người bản ngữ cho cả 17 bản, đặc biệt H’Mông Trắng. Trang nguồn UNESCO bị chặn trong môi trường; giới hạn đối chiếu được ghi rõ trong tài liệu nghiên cứu.']
    readme='\n'.join(lines)+'\n'
    (ROOT/'README.md').write_text(readme)
    (ROOT/'README-PORTABLE.md').write_text(readme.replace(str(ROOT)+'/', './'))
    with zipfile.ZipFile(ROOT/'Nan-Madol-036-17-voices-22m18s.zip','w',zipfile.ZIP_STORED,allowZip64=True) as z:
        z.write(ROOT/'README-PORTABLE.md','README.md')
        z.write(ROOT/'DELIVERY_MANIFEST.json','DELIVERY_MANIFEST.json')
        for item in result:z.write(ROOT/item['file'],item['file'])
    with zipfile.ZipFile(ROOT/'Nan-Madol-036-production-kit.zip','w',zipfile.ZIP_DEFLATED) as z:
        for directory in ['scripts','tools','prompts','research','titles-thumbnails','source-analysis']:
            for p in sorted((ROOT/directory).rglob('*')):
                if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ['.pyc','.mp4','.wav']:
                    z.write(p,str(p.relative_to(ROOT)))
        for name in ['README-PORTABLE.md','VOICE_PROFILES.json','EDITING-GUIDE.md','KICH-BAN-CHINH.md','scene-voice-edit.csv','scenes.json','DELIVERY_MANIFEST.json','validation/final-delivery.json','validation/edge-voices.json','validation/english-asr-spot-check.json']:
            p=ROOT/name
            if p.exists():z.write(p,name)
        for p in sorted((ROOT/'audio').glob('*-report.json')):z.write(p,str(p.relative_to(ROOT)))
    for name in ['70-prompts-7-txt.zip','Nan-Madol-036-17-voices-22m18s.zip','Nan-Madol-036-production-kit.zip']:
        with zipfile.ZipFile(ROOT/name) as z:assert z.testzip() is None,name
    checks=[f"{item['sha256']}  {item['file']}" for item in result]
    checks += [f'{sha(p)}  {p.name}' for p in sorted(ROOT.glob('*.zip'))]
    (ROOT/'SHA256SUMS.txt').write_text('\n'.join(checks)+'\n')
    state=json.loads((ROOT/'PRODUCTION_STATE.json').read_text())
    state.update(status='complete_pending_native_listening_review',mp3_count=17,completed_at_utc=created,private_download_index='README.md')
    save(ROOT/'PRODUCTION_STATE.json',state)
    print(json.dumps({'status':'complete','mp3s':17,'seconds_each':1338,'prompts':70,'txt_files':7,'published':False}),flush=True)

if __name__=='__main__':main()
