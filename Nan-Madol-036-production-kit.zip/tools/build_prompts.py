"""Build the user's reduced set: 70 prompts, 20-second clips, 7 TXT files."""
import csv
import json
from pathlib import Path
import zipfile
ROOT = Path(__file__).resolve().parents[1]

def clock(seconds):
    h, r = divmod(seconds, 3600)
    m, s = divmod(r, 60)
    return f'{h:02d}:{m:02d}:{s:02d}'

def main():
    en = json.loads((ROOT/'scripts/en.json').read_text())
    vi = json.loads((ROOT/'scripts/vi.json').read_text())
    cameras = [line.split('\t', 1) for line in (ROOT/'prompts/camera-20s.tsv').read_text().splitlines() if line.strip()]
    assert len(cameras) == 70
    rows, paragraphs = [], []
    for n, (number, camera) in enumerate(cameras, 1):
        assert int(number) == n
        reserve = n > 67
        start = (n-1)*20 if not reserve else None
        duration = 18 if n == 67 else (20 if not reserve else 0)
        cues = en[(n-1)*2:n*2] if not reserve else []
        context = ' '.join(r['text'] for r in cues)
        if reserve:
            role = 'RESERVE REPLACEMENT ONLY. Replace a matching scene if needed; never append to the 22:18 film.'
        else:
            role = f"MAIN SCENE {n:02d}; timeline {clock(start)}–{clock(start+duration)}; narration cues {2*n-1:03d}–{2*n:03d}."
            if n == 67: role += ' Generate 20 seconds; use only seconds 0–18 for the final scene.'
        paragraph = (f'{n}. {role} Generate one coherent 20-second 16:9 documentary-inspired video clip, suitable for 4K output. '
                     'LOCATION: Nan Madol beside Temwen, southeastern Pohnpei, Federated States of Micronesia. '
                     'Use plausible dark prismatic basalt beams, crosswise courses, coral-rubble artificial islets on shallow coastal reef, tropical palms and mangrove margins. '
                     + (f'NARRATIVE CONTEXT ONLY, never display or speak these words: {context} ' if context else '')
                     + 'CAMERA AND ACTION: '+camera+' '
                     'Keep one physically coherent location or one clearly illustrative model; no montage, abrupt camera teleportation or unrelated scene changes. '
                     'Establish for about 4 seconds, develop the reveal for 12 seconds, settle for the last 4 seconds. '
                     'Models and geological animations are illustrative reconstructions, not excavated evidence, exact surveyed maps or actual historical footage. '
                     'VIDEO KHÔNG CÓ HÌNH TRẺ EM; ABSOLUTELY NO CHILDREN, BABIES OR TEENAGERS anywhere, including backgrounds; every human must be visibly adult, age 25 or older. '
                     'VIDEO KHÔNG CÓ ÂM THANH, KHÔNG LỜI NÓI; SILENT VIDEO: NO AUDIO, NO SPEECH, NO SPOKEN WORDS, NO MUSIC, NO SOUND EFFECTS, NO LIP-SYNC. '
                     'No on-screen text, subtitles, logos or watermarks. No flying stones, aliens, underwater palaces, Atlantis imagery, European canals, Egyptian pyramids, invented inscriptions, treasure, opened graves or human remains. '
                     'No climbing walls, touching masonry, entering restricted spaces, fabricated ritual performances or unsafe lifting. Respect local people and protected heritage.')
        paragraphs.append(paragraph)
        rows.append(dict(prompt=n,reserve_only=reserve,start_seconds=start,used_seconds=duration,
                         generated_seconds=20,voice_cues=[r['scene'] for r in cues],narration_en=context,camera=camera))
    assert sum(r['used_seconds'] for r in rows)==1338
    for b in range(7):
        (ROOT/f'prompts/prompt-{b+1:02d}.txt').write_text('\n\n'.join(paragraphs[b*10:b*10+10])+'\n',encoding='utf-8-sig')
    (ROOT/'scenes.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
    with (ROOT/'scene-voice-edit.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.writer(f)
        writer.writerow(['prompt','role','start','end','used_seconds','voice_cues','voice_en','voice_vi','camera'])
        for r in rows:
            n=r['prompt'];a=r['start_seconds']
            writer.writerow([n,'RESERVE' if r['reserve_only'] else 'MAIN',clock(a) if a is not None else '',
                             clock(a+r['used_seconds']) if a is not None else '',r['used_seconds'],
                             ','.join(map(str,r['voice_cues'])),r['narration_en'],
                             ' '.join(x['text'] for x in vi[(n-1)*2:n*2]) if not r['reserve_only'] else '',r['camera']])
    with zipfile.ZipFile(ROOT/'70-prompts-7-txt.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted((ROOT/'prompts').glob('prompt-*.txt')):z.write(p,p.name)
    print({'prompts':70,'txt_files':7,'main_scenes':67,'reserve_scenes':3,'seconds':1338})

if __name__=='__main__':main()
