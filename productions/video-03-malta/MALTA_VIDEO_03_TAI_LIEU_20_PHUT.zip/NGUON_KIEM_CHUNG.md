# Nguồn kiểm chứng — Malta

Tra cứu ngày10/11/2026. Kịch bản và ví dụ là cách diễn giải mới, không đọc lại nguyên văn paper. Các niên đại24ka,31.6ka,14ka là giá trị xấp xỉ. Không lấy ngày đăng bản manuscript trên PMC làm ngày công bố nghiên cứu.

- **S01: Raghavan et al., Nature, online 20 Nov 2013; issue 2 Jan 2014** — https://pmc.ncbi.nlm.nih.gov/articles/PMC4105016/
  MA-1 khoảng 24.000 năm; mẫu xương cánh tay; bảo quản Hermitage; quan hệ autosomal và các giới hạn mô hình. DOI10.1038/nature12736. Không dùng đây làm bằng chứng một chuyến đi hoặc tổ tiên trực tiếp từ đứa trẻ.

- **S02: Lbova, Evolutionary Human Sciences, 2021** — https://www.cambridge.org/core/journals/evolutionary-human-sciences/article/siberian-paleolithic-site-of-malta-a-unique-source-for-the-study-of-childhood-archaeology/F28C70119125FDB885150D66BFC11146
  Bối cảnh Malta, tuổi trẻ khoảng3–4, đồ vật và diễn giải về tuổi thơ. Diễn giải trang phục/tôn giáo/địa vị còn tranh luận; không biến giả thuyết thành cảnh quay chứng cứ.

- **S03: Sikora et al., Nature, 2019** — https://pmc.ncbi.nlm.nih.gov/articles/PMC7617447/
  Yana31.6ka, ANS và quan hệ ANE/Malta, lịch sử phức tạp. DOI10.1038/s41586-019-1279-z. Không đồng nhất Yana,Malta hay dân tộc hiện nay.

- **S04: Yu et al., Cell, 2020** — https://doi.org/10.1016/j.cell.2020.04.037
  Ust-Kyahta-3 khoảng14ka và quan hệ với các nhóm tổ tiên người châu Mỹ; không phải cha/mẹ trực tiếp của mọi cộng đồng.

- **S05: Max Planck Institute, research report, 20 May 2020** — https://www.shh.mpg.de/1702918/oldest-connection-with-native-americans-identified-near-lake-baikal-in-siberia
  Giải thích mẫu răng và địa lý đi cùng S04, không tính là kiểm chứng độc lập mới.

- **S06: Dabney, Meyer, Paabo, Ancient DNA Damage, 2013** — https://pmc.ncbi.nlm.nih.gov/articles/PMC3685887/
  Phân mảnh, hư hại hoá học và xác thực. DOI10.1101/cshperspect.a012567. Graphic không thay cho phép đo thật.

- **S07: NHGRI, DNA Fact Sheet** — https://www.genome.gov/about-genomics/fact-sheets/Deoxyribonucleic-Acid-Fact-Sheet
  Nguyên lý di truyền và bộ gene; giải thích độc lập bằng minh hoạ.

- **S08: NHGRI, Autosome** — https://www.genome.gov/genetics-glossary/Autosome
  Phân biệt autosome và nhánh đơn hệ.

- **S09: NHGRI, Mitochondrial DNA** — https://www.genome.gov/genetics-glossary/Mitochondrial-DNA
  mtDNA theo mẹ trong cách giải thích thông thường, không đại diện toàn bộ tổ tiên.

- **S10: NHGRI, Crossing Over** — https://www.genome.gov/genetics-glossary/Crossing-Over
  Tái tổ hợp khi hình thành giao tử; mô hình dây/ribbon chỉ là sơ đồ.

- **S11: NHGRI, Genetic Ancestry** — https://www.genome.gov/genetics-glossary/Genetic-Ancestry
  Quan hệ tổ tiên sinh học khác quốc tịch, văn hoá và tuyến đi chính xác.

- **S12: NPS, About Beringia** — https://www.nps.gov/subjects/beringia/about.htm
  Bối cảnh địa lý và bathymetry tham chiếu. Không lấy mốc cũ trên trang làm ngày đầu con người vào châu Mỹ.

- **S13: NPS, Nature and Science of Beringia** — https://www.nps.gov/subjects/beringia/nature.htm
  Đất nối khi mực biển thấp; cảnh quan có khác biệt địa phương, không phải toàn bộ phủ băng.

- **S14: Alpaslan-Roodenberg et al., Nature, 2021** — https://pmc.ncbi.nlm.nih.gov/articles/PMC7612683/
  Bối cảnh đạo đức nghiên cứu di hài/người liên quan; không tuyên bố nghiên cứu hiện tại đã có một chứng nhận không được kiểm chứng.

- **S15: Texas A&M, coauthor research report, 20 Nov 2013** — https://stories.tamu.edu/news/2013/11/20/boys-skeleton-in-siberia-raises-new-questions-about-first-americans/
  Lịch sử nghiên cứu, mẫu xương, hiện vật; bài báo cáo có cách nói mạnh hơn paper, kịch bản dùng kết luận dè dặt của nghiên cứu gốc.

- **S16: Nguồn video do người dùng cung cấp** — https://github.com/seotro95/seotro/releases/tag/video
  Chỉ tham chiếu cách kể và dựng. SHA256f1a8659dbccd4db12a79e3c18ea2e1fe08f46f7a03c42bc2250f454f69eff70c. Không dùng làm nguồn khoa học cho Malta.

