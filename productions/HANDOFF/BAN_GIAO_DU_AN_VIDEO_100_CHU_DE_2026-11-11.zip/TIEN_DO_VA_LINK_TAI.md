# Tiến độ và link tải

Các kết quả bên dưới được ghi trong hồ sơ đã lưu. Không suy đoán mọi tập1–19đã hoàn thành. Chi tiết100tập trong SERIES/SERIES_STATE.json.

## Chủ đề1 — Beringia: vùng đất từng nối châu Á với châu Mỹ đã biến mất thế nào?

- [Video hoàn chỉnh](https://github.com/seotro95/seotro/releases/download/beringia-video-01-final-20min/BERINGIA_01_EN_FINAL_20m_720p.mp4)
- [17voice](https://github.com/seotro95/seotro/releases/download/beringia-video-01-final-20min/BERINGIA_01_17_VOICES.zip)
- [Dự án dựng](https://github.com/seotro95/seotro/releases/download/beringia-video-01-final-20min/BERINGIA_01_EDIT_PROJECT.zip)

## Chủ đề2 — White Sands: những dấu chân cổ đã thay đổi mốc thời gian con người ở châu Mỹ.

- [Video hoàn chỉnh](https://github.com/seotro95/seotro/releases/download/white-sands-video-02-final-22min/WHITE_SANDS_02_EN_FINAL_22m_720p.mp4)
- [17voice](https://github.com/seotro95/seotro/releases/download/white-sands-video-02-22min/WHITE_SANDS_02_17_VOICES_22m.zip)
- [Dự án dựng](https://github.com/seotro95/seotro/releases/download/white-sands-video-02-final-22min/WHITE_SANDS_02_EDIT_PROJECT.zip)

## Chủ đề3 — Đứa trẻ Mal'ta và mối liên hệ bất ngờ giữa Siberia với tổ tiên người châu Mỹ.

- [Video hoàn chỉnh](https://github.com/seotro95/seotro/releases/download/malta-video-03-final-20min/MALTA_03_EN_FINAL_20m_720p.mp4)
- [17voice](https://github.com/seotro95/seotro/releases/download/malta-video-03-20min/MALTA_03_17_VOICES_TEN_QUOC_GIA.zip)
- [Hồ sơ giọng](https://github.com/seotro95/seotro/releases/download/malta-video-03-20min/MALTA_03_HO_SO_GIONG_TEN_QUOC_GIA.zip)
- [Dự án dựng](https://github.com/seotro95/seotro/releases/download/malta-video-03-final-20min/MALTA_03_EDIT_PROJECT.zip)

## Chủ đề4 — Yana: Two Teeth and the Ancient Northern World

- [Video hoàn chỉnh](https://github.com/seotro95/seotro/releases/download/yana-video-04-final-23min/YANA_04_EN_FINAL_23m_720p.mp4)
- [17voice](https://github.com/seotro95/seotro/releases/download/yana-video-04-23min/YANA_04_17_VOICES_TEN_QUOC_GIA.zip)
- [Hồ sơ giọng](https://github.com/seotro95/seotro/releases/download/yana-video-04-23min/YANA_04_HO_SO_GIONG_TEN_QUOC_GIA.zip)
- [Dự án dựng](https://github.com/seotro95/seotro/releases/download/yana-video-04-final-23min/YANA_04_EDIT_PROJECT.zip)

## Chủ đề6 — Denisova: The People Hidden in a Fragment

- [Video hoàn chỉnh](https://github.com/seotro95/seotro/releases/download/denisova-video-06-final-21min/DENISOVA_06_EN_FINAL_21m_720p.mp4)
- [17voice](https://github.com/seotro95/seotro/releases/download/denisova-video-06-21min/DENISOVA_06_17_VOICES_TEN_QUOC_GIA.zip)
- [Hồ sơ giọng](https://github.com/seotro95/seotro/releases/download/denisova-video-06-21min/DENISOVA_06_HO_SO_GIONG_TEN_QUOC_GIA.zip)
- [Dự án dựng](https://github.com/seotro95/seotro/releases/download/denisova-video-06-final-21min/DENISOVA_06_EDIT_PROJECT.zip)

## Chủ đề8 — Baishiya: The Survival Story Hidden in Broken Bones

- [Video hoàn chỉnh](https://github.com/seotro95/seotro/releases/download/baishiya-video-08-final-22m20s/BAISHIYA_08_EN_FINAL_22m20s_720p.mp4)
- [17voice](https://github.com/seotro95/seotro/releases/download/baishiya-video-08-22m20s/BAISHIYA_08_17_VOICES_TEN_QUOC_GIA.zip)
- [Hồ sơ giọng](https://github.com/seotro95/seotro/releases/download/baishiya-video-08-22m20s/BAISHIYA_08_HO_SO_GIONG_TEN_QUOC_GIA.zip)
- [Dự án dựng](https://github.com/seotro95/seotro/releases/download/baishiya-video-08-final-22m20s/BAISHIYA_08_EDIT_PROJECT.zip)

## Chủ đề19 — Kostenki: The House That Remains a Question

- [Video hoàn chỉnh](https://github.com/seotro95/seotro/releases/download/kostenki-video-19-final-20m15s/KOSTENKI_19_EN_FINAL_20m15s_720p.mp4)
- [17voice](https://github.com/seotro95/seotro/releases/download/kostenki-video-19-20m15s/KOSTENKI_19_17_VOICES_TEN_QUOC_GIA.zip)
- [Hồ sơ giọng](https://github.com/seotro95/seotro/releases/download/kostenki-video-19-20m15s/KOSTENKI_19_HO_SO_GIONG_TEN_QUOC_GIA.zip)
- [Dự án dựng](https://github.com/seotro95/seotro/releases/download/kostenki-video-19-final-20m15s/KOSTENKI_19_EDIT_PROJECT.zip)
- [Mở đầu30giây](https://github.com/seotro95/seotro/releases/download/kostenki-video-19-final-20m15s/KOSTENKI_19_OPENING_30s.mp4)
- [5tiêu đề/thumbnail](https://github.com/seotro95/seotro/releases/download/kostenki-video-19-final-20m15s/KOSTENKI_19_TITLES_THUMBNAILS.txt)
- [Kịch bản/prompt](https://github.com/seotro95/seotro/releases/download/kostenki-video-19-20m15s/KOSTENKI_VIDEO_19_TAI_LIEU_20m15s.zip)

Các MP4/MP3/model lớn không nằm trong ZIP bàn giao;dùng link trên để tải khi cần. Link cũ ngoài tập19được lấy từ trạng thái đã lưu,không tải lại toàn bộ trong lượt đóng gói này.
