# Nguồn kiểm chứng — Yana

Tra cứu ngày10/11/2026. Kịch bản gốc, không dịch lời video nguồn. Niên đại xấp xỉ; phân biệt tuổi mẫu, lịch sử nghiên cứu, mô hình quần thể và ngày cập nhật trang.

- **S01 — Sikora et al., The population history of northeastern Siberia since the Pleistocene (2019)**: https://www.nature.com/articles/s41586-019-1279-z
  DOI: 10.1038/s41586-019-1279-z. Yana genomes and approximately31.6ka; Ancient North Siberians, comparisons with Mal'ta, kinship observations and later northeastern Siberian histories. Research groupings are not modern nations; demographic inference is not a camp census.

- **S02 — Pitulko et al., The Yana RHS site: humans in the Arctic before the last glacial maximum (2004)**: https://pubmed.ncbi.nlm.nih.gov/14704419/
  DOI: 10.1126/science.1085219. Archaeological context, worked rhinoceros horn, mammoth ivory, bone and stone; early radiocarbon ages should not be confused with later calibrated calendar descriptions.

- **S03 — University of Cambridge, DNA from31,000-year-old milk teeth leads to discovery of ancient Siberians (2019)**: https://www.cam.ac.uk/research/news/dna-from-31000-year-old-milk-teeth-leads-to-discovery-of-new-group-of-ancient-siberians?embed=true
  DOI: không áp dụng/chưa ghi. Coauthor institutional report: two milk teeth, site discovered in2001, broader genomic study. Report accompanying S01, not independent confirmation.

- **S04 — Pitulko et al., Evidence from the Yana Palaeolithic site yields clues to mammoth hunting (2013)**: https://www.sciencedirect.com/science/article/pii/S0305440313001957
  DOI: 10.1016/j.jas.2013.05.020. Location, discovery and animal evidence. Do not turn one assemblage or model into an invented witnessed hunt, diet menu or particular biography.

- **S05 — Pitulko and colleagues, The oldest art of the Eurasian Arctic: personal ornaments and symbolic objects from Yana RHS (Antiquity86(333), September2012; publisher web date2015)**: https://www.cambridge.org/core/journals/antiquity/article/abs/oldest-art-of-the-eurasian-arctic-personal-ornaments-and-symbolic-objects-from-yana-rhs-arctic-siberia/5683EA5DA6C26B29C2FB1BFCD947D55A
  DOI: không áp dụng/chưa ghi. Ornaments, pendants, needles and craft. Their existence does not establish exact personal meanings or a complete belief system. Check issue date separately from later publisher web date.

- **S06 — Gilligan et al., Paleolithic eyed needles and the evolution of dress (2024)**: https://doi.org/10.1126/sciadv.adp2887
  DOI: 10.1126/sciadv.adp2887. Sewing technology and the interpretive connection to clothing. Not a preserved complete Yana garment or a known individual maker.

- **S07 — Late Pleistocene and Early Holocene climate changes and human habitation in arctic Western Beringia (2020)**: https://www.sciencedirect.com/science/article/pii/S1040618220301798
  DOI: không áp dụng/chưa ghi. Changing steppe/tundra settings, fauna and variable environments. No single climate reconstruction represents every date or locality.

- **S08 — Clark et al., The Last Glacial Maximum (2009)**: https://pubs.usgs.gov/publication/70036965
  DOI: 10.1126/science.1172873. Glacial chronology: Yana's approximately31.6ka record predates the major LGM interval. Do not label all ancient northern ground as glacier.

- **S09 — Dabney, Meyer and Paabo, Ancient DNA Damage (2013)**: https://pmc.ncbi.nlm.nih.gov/articles/PMC3685887/
  DOI: 10.1101/cshperspect.a012567. Fragmentation, chemical damage, contamination and authentication limits. Diagrams illustrate mechanisms, not a visual diagnostic or actual Yana result.

- **S10 — NHGRI, DNA Sequencing Fact Sheet (current public educational page)**: https://www.genome.gov/about-genomics/fact-sheets/DNA-Sequencing-Fact-Sheet
  DOI: không áp dụng/chưa ghi. General sequencing concepts; sequencing is not a recording of memories or ancient speech.

- **S11 — NHGRI, Human Genomic Variation (current public educational page)**: https://www.genome.gov/about-genomics/educational-resources/fact-sheets/human-genomic-variation
  DOI: không áp dụng/chưa ghi. General inherited differences and the role of comparisons across positions. No invented measured sequence or percentage.

- **S12 — NHGRI, Crossing Over (current public educational glossary)**: https://www.genome.gov/genetics-glossary/Crossing-Over
  DOI: không áp dụng/chưa ghi. Recombination; ribbons and notebooks are explicitly teaching analogies, not literal molecular procedures.

- **S13 — MedlinePlus Genetics, Genetic ancestry testing (current NIH educational page)**: https://medlineplus.gov/genetics/understanding/dtcgenetictesting/ancestrytesting/
  DOI: không áp dụng/chưa ghi. Reference comparisons, differing ancestry histories and limitations of genetic ancestry. Consumer ancestry examples are not presented as the laboratory protocol for Yana.

- **S14 — Raghavan et al., Upper Palaeolithic Siberian genome reveals dual ancestry of Native Americans (online2013; Nature issue2014)**: https://pmc.ncbi.nlm.nih.gov/articles/PMC4105016/
  DOI: 10.1038/nature12736. Mal'ta approximately24ka and its role as a related ancient sample. Not direct descent from a sampled individual or proof of an exact journey.

- **S15 — National Park Service, About Beringia (current public geographic context)**: https://www.nps.gov/subjects/beringia/about.htm
  DOI: không áp dụng/chưa ghi. Broad exposed land connection and shifting coastlines. Source bathymetry illustration about21,000BP is not an exact31,600-year shoreline or a demonstrated personal route.

- **S16 — Alpaslan-Roodenberg et al., Ethics of DNA research on human remains: five globally applicable guidelines (2021)**: https://pmc.ncbi.nlm.nih.gov/articles/PMC7612683/
  DOI: 10.1038/s41586-021-04008-x. Care, sampling, documentation and communication; no claim that an illustrative meeting or specimen case proves an actual permission process.

- **S17 — National Park Service, Beringia nature and science (current public context)**: https://www.nps.gov/subjects/beringia/nature.htm
  DOI: không áp dụng/chưa ghi. Environmental and archaeological context of the northern connection. Do not equate its physical existence with a dated migration into all the Americas.

- **S18 — Natural Earth1:110m land and lake geometry (public-domain geographic dataset)**: https://github.com/nvkelso/natural-earth-vector
  DOI: không áp dụng/chưa ghi. Modern generalised geographic orientation, not elevation, a measured palaeoshore or surveyed site coordinates. Preserve complete polygon rings when shifting longitude.

- **S19 — User-supplied source video, video.c.a.toi.mp4 (reference supplied by user)**: https://github.com/seotro95/seotro/releases/tag/video
  DOI: không áp dụng/chưa ghi. Narrative/editing style only. SHA-256: f1a8659dbccd4db12a79e3c18ea2e1fe08f46f7a03c42bc2250f454f69eff70c. Original Russian narration, approximately21:03. No original footage, voice or text copied into the new script.
