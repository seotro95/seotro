@echo off
call "%~dp0Khoi-dong.cmd" --install
exit /b %errorlevel%
