@echo off
setlocal
chcp 65001 >nul
set "PYTHONUTF8=1"
set "PYTHON_MANAGER_AUTOMATIC_INSTALL=0"
set "PYLAUNCHER_ALLOW_INSTALL="
set "MODE=--launch"
if /I "%~1"=="--check" set "MODE=--check"
call :refresh_path
if /I "%~1"=="--install" call :install_missing
call :find_python
if defined PYTHON_CMD goto run

echo [THIEU] May chua co Python 3 hoac Windows khong tim thay Python.
echo Mo Cai-dat.cmd de cai Python. Neu khong co winget, cai tu python.org.
set "RESULT=1"
goto finish

:run
%PYTHON_CMD% "%~dp0check_install.py" %MODE%
set "RESULT=%errorlevel%"
goto finish

:install_missing
where winget.exe >nul 2>nul
if errorlevel 1 (
  echo [THIEU] Winget. Cai hoac cap nhat App Installer trong Microsoft Store.
  echo Co the xem HUONG-DAN.txt de cai thu cong.
  set "MODE=--check"
  exit /b 1
)
call :find_python
if not defined PYTHON_CMD goto install_python
%PYTHON_CMD% -c "import tkinter; import sys; sys.exit(sys.version_info < (3, 8))" >nul 2>nul
if not errorlevel 1 goto check_ffmpeg

:install_python
echo Dang cai Python 3.12...
winget install --id Python.Python.3.12 --exact --source winget
call :refresh_path

:check_ffmpeg
ffmpeg.exe -version >nul 2>nul
if errorlevel 1 goto install_ffmpeg
ffprobe.exe -version >nul 2>nul
if errorlevel 1 goto install_ffmpeg
ffmpeg.exe -hide_banner -encoders 2>nul | findstr /R /C:" libx264 " >nul
if not errorlevel 1 goto check_ocr

:install_ffmpeg
echo Dang cai FFmpeg...
winget install --id Gyan.FFmpeg --exact --source winget
call :refresh_path

:check_ocr
tesseract.exe --list-langs 2>nul | findstr /X /C:"eng" >nul
if not errorlevel 1 exit /b 0
if exist "%ProgramFiles%\Tesseract-OCR\tesseract.exe" (
  "%ProgramFiles%\Tesseract-OCR\tesseract.exe" --list-langs 2>nul | findstr /X /C:"eng" >nul
  if not errorlevel 1 exit /b 0
)
if exist "%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe" (
  "%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe" --list-langs 2>nul | findstr /X /C:"eng" >nul
  if not errorlevel 1 exit /b 0
)
echo Dang cai Tesseract OCR de doc ten game...
winget install --id UB-Mannheim.TesseractOCR --exact --source winget
call :refresh_path
exit /b 0

:find_python
set "PYTHON_CMD="
where py.exe >nul 2>nul
if errorlevel 1 goto try_python
py.exe -3 -c "import tkinter; import sys; sys.exit(sys.version_info < (3, 8))" >nul 2>nul
if not errorlevel 1 (
  set "PYTHON_CMD=py.exe -3"
  exit /b 0
)
py.exe -3.12 -c "import tkinter" >nul 2>nul
if not errorlevel 1 (
  set "PYTHON_CMD=py.exe -3.12"
  exit /b 0
)
py.exe -3 -c "import sys" >nul 2>nul
if not errorlevel 1 set "PYTHON_CMD=py.exe -3"

:try_python
where python.exe >nul 2>nul
if errorlevel 1 exit /b 0
python.exe -c "import tkinter; import sys; sys.exit(sys.version_info < (3, 8))" >nul 2>nul
if not errorlevel 1 (
  set "PYTHON_CMD=python.exe"
  exit /b 0
)
if defined PYTHON_CMD exit /b 0
python.exe -c "import sys; sys.exit(sys.version_info.major != 3)" >nul 2>nul
if not errorlevel 1 set "PYTHON_CMD=python.exe"
exit /b 0

:refresh_path
for /F "usebackq delims=" %%P in (`powershell.exe -NoProfile -Command "[Environment]::GetEnvironmentVariable('Path','Machine') + ';' + [Environment]::GetEnvironmentVariable('Path','User')"`) do set "PATH=%LOCALAPPDATA%\Microsoft\WinGet\Links;%ProgramFiles%\WinGet\Links;%%P;%PATH%"
exit /b 0

:finish
echo.
pause
exit /b %RESULT%
