"""Kiểm tra các thành phần cần để mở công cụ và dựng MP4."""
from pathlib import Path
import os
import platform
import re
import runpy
import shutil
import subprocess
import sys

BASE = Path(__file__).resolve().parent


def configure():
    # Ưu tiên thư viện kéo thả đi cùng bản tải xuống.
    sys.path.insert(0, str(BASE / "vendor"))
    if os.name == "nt" and not shutil.which("tesseract"):
        for key in ("ProgramFiles", "ProgramFiles(x86)", "LOCALAPPDATA"):
            directory = os.environ.get(key)
            if directory:
                root = Path(directory)
                folder = root / ("Programs" if key == "LOCALAPPDATA" else "") / "Tesseract-OCR"
                if (folder / "tesseract.exe").is_file():
                    os.environ["PATH"] = str(folder) + os.pathsep + os.environ.get("PATH", "")
                    break


def command_output(*args):
    try:
        result = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                timeout=10, check=True)
    except (OSError, subprocess.SubprocessError):
        return None
    return result.stdout.decode("utf-8", errors="replace")


def check():
    print("KIỂM TRA CÔNG CỤ DỰNG VIDEO")
    print("Hệ điều hành: {}".format(platform.system()))
    python_ok = sys.version_info >= (3, 8)
    print("[{}] Python {}".format("OK" if python_ok else "THIẾU", platform.python_version()))
    if not python_ok:
        print("  Cần Python 3.8 trở lên. Khuyến nghị Python 3.12.")

    gui_ok = False
    if python_ok:
        try:
            import tkinter
        except ImportError:
            print("[THIẾU] Tkinter. Trên Windows, bật mục Tcl/Tk trong bộ cài Python.")
        else:
            print("[OK] Tkinter")
            try:
                from tkinterdnd2 import DND_FILES, TkinterDnD
                window = TkinterDnD.Tk()
                try:
                    window.withdraw()
                    window.drop_target_register(DND_FILES)
                    window.update_idletasks()
                    gui_ok = True
                    print("[OK] Thư viện kéo thả đã nạp.")
                finally:
                    window.destroy()
            except (ImportError, RuntimeError, tkinter.TclError):
                print("[THIẾU] Không mở được cửa sổ kéo thả.")
                print("  Hãy giải nén lại cả ZIP và chạy trong phiên Windows có giao diện.")

    ffmpeg = command_output("ffmpeg", "-version")
    ffprobe = command_output("ffprobe", "-version")
    encoders = command_output("ffmpeg", "-hide_banner", "-encoders") if ffmpeg else None
    h264 = bool(encoders and re.search(r"^\s*V\S*\s+libx264\s", encoders, re.MULTILINE))
    print("[OK] " + ffmpeg.splitlines()[0] if ffmpeg else "[THIẾU] FFmpeg trong PATH")
    print("[OK] " + ffprobe.splitlines()[0] if ffprobe else "[THIẾU] FFprobe trong PATH")
    if ffmpeg:
        print("[OK] Bộ mã hóa libx264" if h264 else "[THIẾU] Bản FFmpeg có bộ mã hóa libx264")
    if not (ffmpeg and ffprobe and h264) and os.name == "nt":
        print("  Có thể cài bản FFmpeg đầy đủ bằng winget install --id Gyan.FFmpeg -e")
        print("  Mở lại cửa sổ kiểm tra sau khi cài.")

    languages = command_output("tesseract", "--list-langs")
    if languages and "eng" in languages.splitlines():
        print("[OK] Tesseract OCR và dữ liệu tiếng Anh")
    else:
        print("[TÙY CHỌN] Chưa thấy Tesseract OCR có dữ liệu tiếng Anh.")
        print("  Bạn vẫn có thể dựng video và chọn tên game hoặc thể loại bằng tay.")

    ready = python_ok and gui_ok and ffmpeg and ffprobe and h264
    print("\nKết quả: " + ("Đủ thành phần để mở công cụ." if ready else "Cần xử lý các dòng [THIẾU]."))
    return bool(ready)


if __name__ == "__main__":
    configure()
    if not check():
        sys.exit(1)
    if "--launch" in sys.argv:
        app = BASE / "auto_edit.py"
        sys.argv = [str(app)]
        runpy.run_path(str(app), run_name="__main__")
