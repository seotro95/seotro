@echo off
call "%~dp0Khoi-dong.cmd" --check
exit /b %errorlevel%
